((buffer-size . 5504) (buffer-checksum . "374e046088d01c78531beccd5e68e5fc01a2f4dc"))
((emacs-buffer-undo-list nil ("  }
" . 3107) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3109) . -4) ((marker . 3107) . -3) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker* . 3107) . 2) ((marker* . 3107) . 2) ((marker . 3108) . -3) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) ((marker . 3107) . -2) 3109 nil ("}
" . 3107) ((marker . 3107) . -1) ((marker . 3109) . -2) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) ((marker . 3107) . -1) 3108 nil ("    " . -3107) ("    else {
" . 3050) ((marker . 3109) . -11) (t 24622 52280 942744 456000)) (emacs-pending-undo-list (")" . -42511) (42511 . 42512) (")" . -42511) (42511 . 42512) nil (42491 . 42511) (42490 . 42492) (t 24627 61568 382884 432000) nil (18004 . 18006) nil ("1" . -18004) 18005 nil (18000 . 18005) nil ("9" . -18000) ("4" . -18001) ("B" . -18002) ("F" . -18003) ("F" . -18004) ("3" . -18005) 18006 nil (17913 . 17919) nil ("B" . -17913) ("F" . -17914) ("1" . -17915) ("B" . -17916) ("8" . -17917) ("B" . -17918) 17919 (t 24627 61454 573175 998000) nil ("(dashboad-)
" . 42490) 42495 (t 24627 61389 606675 763000) nil ("j" . -18549) 18550 nil (18543 . 18550) nil ("a" . -18543) 18544 nil (18543 . 18544) nil ("C" . -18543) ("C" . -18544) ("5" . -18545) ("6" . -18546) ("0" . -18547) ("8" . -18548) 18549 nil (41651 . 41660) nil (41689 . 41698) nil (42480 . 42482) nil ("a" . -42480) 42481 nil (42480 . 42481) nil ("r" . -42480) ("d" . -42481) ("-" . -42482) 42483 nil (42482 . 42483) nil ("0" . -42482) 42483 nil (42482 . 42483) nil (42482 . 42483) (")" . -42482) (42482 . 42483) nil (")" . -42482) 42483 nil (")" . -42482) (42482 . 42483) (")" . -42482) (42473 . 42483) (42472 . 42474) nil (42471 . 42472) (t 24627 61122 767359 743000) nil (18543 . 18549) nil ("D" . -18543) ("F" . -18544) ("A" . -18545) ("F" . -18546) ("8" . -18547) ("F" . -18548) 18549 nil ("j" . -17919) 17920 nil (17913 . 17920) nil ("D" . -17913) ("C" . -17914) ("8" . -17915) ("C" . -17916) ("C" . -17917) ("3" . -17918) 17919 nil ("zu" . 18368) nil (18368 . 18370) nil (18366 . 18368) nil (18363 . 18366) nil ("@" . -18363) 18364 nil ("(" . -18364) (")" . 18365) nil (18362 . 18366) nil ("D" . -18362) ("0" . -18363) ("B" . -18364) ("F" . -18365) ("8" . -18366) ("F" . -18367) 18368 (t 24627 60939 911289 879000) nil ("
	       " . 37084) nil (37085 . 37093) nil ("	       " . -37085) 37093 nil (37084 . 37093) (t 24627 60939 911289 879000) 37065 nil (nil rear-nonsticky nil 41001 . 41002) ("
" . -41021) (41001 . 41022) 40987 nil ("
(display-time-mode)
" . 41024) (41044 . 41045) (nil rear-nonsticky t 41024 . 41025) nil (nil rear-nonsticky nil 41024 . 41025) ("
" . -41044) (41024 . 41045) 41002 nil ("(display-time-mode)
" . 40285) nil ("
" . 41022) nil (nil rear-nonsticky nil 41022 . 41023) ("
" . -41045) (41022 . 41046) nil ("(display-battery-mode)
" . 40390) 40409 (t 24627 14016 572429 716000) nil (41615 . 41616) 41615 nil ("
" . 41615) nil (41735 . 41736) (")" . -41735) (41730 . 41736) nil (")" . -41730) 41731 nil (41730 . 41731) (")" . -41730) (41730 . 41731) nil (" " . -41730) ("\"" . -41731) ("a" . -41732) ("\"" . -41733) (")" . -41734) 41735 nil (41735 . 41736) nil ("
" . -41735) 41736 nil (41735 . 41736) 41735 nil (41732 . 41733) (41731 . 41733) ("\"" . -41731) (41731 . 41732) nil ("a" . -41731) 41732 nil (41720 . 41732) (41719 . 41721) nil (41718 . 41719) nil (41706 . 41716) nil ("i" . -41706) 41707 nil (41703 . 41707) nil ("s" . -41703) ("/" . -41704) 41705 nil (41694 . 41705) nil ("o" . -41694) 41695 nil (41692 . 41695) nil ("d" . -41692) 41693 nil (41692 . 41693) (41691 . 41693) ("\"" . -41691) (41691 . 41692) nil (41681 . 41691) (41680 . 41682) nil (")" . -41680) ("f" . -41681) ("i" . -41682) ("n" . -41683) 41684 nil (41680 . 41684) (")" . -41680) (41680 . 41681) nil ("*" . -41680) 41681 nil (41680 . 41681) nil ("f" . -41680) 41681 nil (41680 . 41681) nil (41679 . 41680) nil (41634 . 41641) (t 24625 15641 829824 912000) nil (23040 . 23046) nil (23037 . 23040) (23036 . 23038) ("\"" . -23036) (23035 . 23037) nil (22995 . 23035) ("desktop-environment-screenshot-di" . -22995) 23028 nil (23026 . 23028) nil ("p" . -23026) ("a" . -23027) ("r" . -23028) ("t" . -23029) 23030 nil (nil fontified t 23000 . 23030) ("desktop-environment-screenshot" . -22995) (23025 . 23060) 23025 nil ("desktop-environment-scre" . -22995) (23019 . 23049) 23019 nil (23007 . 23019) nil (22990 . 23007) (22989 . 22991) nil (22988 . 22989) nil (2099 . 2100) (t 24621 45498 765205 172000) nil ("(setq js2-missing-semi-one-line-override 1)
" . 30780) 30781 nil (30776 . 30778) nil ("u" . -30776) ("l" . -30777) 30778 nil (30775 . 30778) nil ("1" . -30775) 30776 nil (30734 . 30737) nil ("1" . -30734) 30735 nil (30817 . 30818) nil ("0" . -30817) 30818 nil (30773 . 30774) nil ("0" . -30773) 30774 nil (30734 . 30735) nil ("0" . -30734) 30735 nil (30816 . 30818) nil (30782 . 30816) ("js2-mis" . -30782) 30789 nil (30780 . 30789) nil ("x" . -30780) 30781 nil (30777 . 30781) (30776 . 30778) nil (30775 . 30776) nil ("l" . -30774) 30775 nil (30772 . 30775) nil (30743 . 30772) ("js2-mode-sho" . -30743) 30755 nil (30746 . 30755) nil (30738 . 30746) (30737 . 30739) nil ("9" . -30737) 30738 nil (30737 . 30738) nil (30736 . 30737) nil ("t" . 30734) (30735 . 30736) 30734 nil (30695 . 30696) nil (nil rear-nonsticky nil 30734 . 30735) (nil fontified nil 30695 . 30735) (30695 . 30735) (t 24621 8655 162859 673000) nil ("(setq js2-strict-missing-semi-warning t)" . 30682) (nil rear-nonsticky t 30721 . 30722) nil (nil rear-nonsticky nil 30721 . 30722) (nil fontified nil 30682 . 30722) (30682 . 30722) 30681 (t 24621 8655 162859 673000) nil (22149 . 22156) nil ("C" . -22149) ("a" . -22150) ("l" . -22151) ("e" . -22152) ("n" . -22153) ("d" . -22154) ("a" . -22155) ("r" . -22156) 22157 nil (22170 . 22177) nil ("c" . -22170) ("a" . -22171) ("l" . -22172) ("e" . -22173) ("n" . -22174) ("d" . -22175) ("a" . -22176) ("r" . -22177) 22178 nil (nil rear-nonsticky nil 22179 . 22180) (nil fontified nil 22133 . 22180) (22133 . 22180) nil (nil rear-nonsticky nil 22131 . 22132) (nil fontified nil 22085 . 22132) (22085 . 22132) nil ("(start-process \"Calendar\" nil \"gnome-calendar\")" . 22085) (t 24618 51165 691143 37000) nil (";" . -37176) (";" . -37177) 37178 nil (37234 . 37236) (t 24616 12581 199964 159000) nil (23671 . 23672) nil ("
" . 23724) nil (nil rear-nonsticky nil 23723 . 23724) (nil fontified nil 23671 . 23724) (23671 . 23724) nil ("(undo-fu-session-mode)
(global-undo-fu-session-mode)
" . 23657) (nil fontified t 23657 . 23680) (nil rear-nonsticky t 23709 . 23710) nil ("	   " . 23680) ("	   " . 23714) nil (23714 . 23718) (23680 . 23684) 23656 nil (nil rear-nonsticky nil 23709 . 23710) (nil fontified nil 23657 . 23710) (23657 . 23710) 23656 nil ("(undo-fu-session-mode)
(global-undo-fu-session-mode)
" . 35185) (t 24616 12539 270100 42000) nil ("dafdsaf" . 35299) nil (35299 . 35306) (t . 0) nil (17557 . 18554) ("(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(highlight-indentation-face ((t nil)))
 '(telephone-line-evil-emacs ((t (:inherit telephone-line-evil :background \"#DC8CC3\"))))
 '(telephone-line-evil-god ((t (:inherit telephone-line-evil :background \"#94BFF3\"))))
 '(telephone-line-evil-insert ((t (:inherit telephone-line-evil :background \"#3F5F3F\"))))
 '(telephone-line-evil-motion ((t (:inherit telephone-line-evil :background \"#366060\"))))
 '(telephone-line-evil-normal ((t (:inherit telephone-line-evil :background \"#7C4343\"))))
 '(telephone-line-evil-operator ((t (:inherit telephone-line-evil :background \"#D0BF8F\"))))
 '(telephone-line-evil-replace ((t (:inherit telephone-line-evil :background \"#656555\"))))
 '(telephone-line-evil-visual ((t (:inherit telephone-line-evil :background \"#DFAF8F\")))))" . -17557) (17513 . 17556) (17492 . 17495) (17469 . 17472) (17446 . 17449) (17423 . 17426) (17400 . 17403) (17377 . 17380) (17354 . 17357) (17331 . 17334) (17308 . 17311) (17285 . 17288) (17262 . 17265) (17239 . 17242) (17216 . 17219) (17193 . 17196) (17171 . 17174) (17149 . 17152) (17127 . 17130) ("
" . -17462) (17442 . 17444) (17422 . 17424) (17402 . 17404) (17382 . 17384) (17362 . 17364) (17342 . 17344) (17322 . 17324) (17302 . 17304) (17282 . 17284) (17262 . 17264) (17242 . 17244) (17222 . 17224) (17202 . 17204) (17182 . 17184) (17163 . 17165) (17144 . 17146) (17125 . 17127) (17428 . 17429) (17409 . 17410) ("
" . 17409) (17409 . 17410) (" " . -17409) (17391 . 17392) ("
" . 17391) (17391 . 17392) (" " . -17391) (17373 . 17374) ("
" . 17373) (17373 . 17374) (" " . -17373) (17355 . 17356) ("
" . 17355) (17355 . 17356) (" " . -17355) (17337 . 17338) ("
" . 17337) (17337 . 17338) (" " . -17337) (17319 . 17320) ("
" . 17319) (17319 . 17320) (" " . -17319) (17301 . 17302) ("
" . 17301) (17301 . 17302) (" " . -17301) (17283 . 17284) ("
" . 17283) (17283 . 17284) (" " . -17283) (17265 . 17266) ("
" . 17265) (17265 . 17266) (" " . -17265) (17247 . 17248) ("
" . 17247) (17247 . 17248) (" " . -17247) (17229 . 17230) ("
" . 17229) (17229 . 17230) (" " . -17229) (17211 . 17212) ("
" . 17211) (17211 . 17212) (" " . -17211) (17193 . 17194) ("
" . 17193) (17193 . 17194) (" " . -17193) (17175 . 17176) ("
" . 17175) (17175 . 17176) (" " . -17175) (17158 . 17159) ("
" . 17158) (17158 . 17159) (" " . -17158) (17141 . 17142) ("
" . 17141) (17141 . 17142) (" " . -17141) (17124 . 17125) ("
" . 17124) (17124 . 17125) (" " . -17124) (17102 . 17428) (" " . 17102) (16503 . 17103) ("
" . -16503) (4808 . 16504) (" " . 4808) (4459 . 4809) ("
" . -4459) (4375 . 4460) (" " . 4375) (4188 . 4376) ("
" . -4188) (4102 . 4189) (" " . 4102) (4077 . 4103) ("
" . -4077) (3857 . 4078) (" " . 3857) (3735 . 3858) (3684 . 3687) (3613 . 3616) (3545 . 3548) (3455 . 3458) (3390 . 3393) (3316 . 3319) (3217 . 3220) ("
" . -3714) (3664 . 3666) (3596 . 3598) (3531 . 3533) (3444 . 3446) (3382 . 3384) (3311 . 3313) (3215 . 3217) (3700 . 3701) (3651 . 3652) ("
" . 3651) (3651 . 3652) (" " . -3651) (3585 . 3586) ("
" . 3585) (3585 . 3586) (" " . -3585) (3522 . 3523) ("
" . 3522) (3522 . 3523) (" " . -3522) (3437 . 3438) ("
" . 3437) (3437 . 3438) (" " . -3437) (3377 . 3378) ("
" . 3377) (3377 . 3378) (" " . -3377) (3308 . 3309) ("
" . 3308) (3308 . 3309) (" " . -3308) (3214 . 3215) ("
" . 3214) (3214 . 3215) (" " . -3214) (3134 . 3700) (" " . 3134) (3101 . 3135) (2997 . 3000) ("
" . -3098) (2995 . 2997) (3096 . 3097) (2994 . 2995) ("
" . 2994) (2994 . 2995) (" " . -2994) (2900 . 3096) (" " . 2900) (2097 . 2901) ("
" . -2097) (1884 . 2098) (" " . 1884) (1783 . 1885) (1739 . 1742) (1722 . 1725) (1711 . 1714) (1689 . 1692) (1615 . 1618) ("
" . -1768) (1724 . 1727) (1710 . 1713) (1701 . 1705) (1682 . 1686) (1612 . 1615) (1751 . 1752) (1709 . 1710) (" " . 1709) (1698 . 1699) (" " . -1698) (1693 . 1694) (" " . -1693) (1678 . 1679) (" " . 1678) (1611 . 1612) (" " . 1611) (1594 . 1751) (" " . 1594) (1517 . 1595) ("
" . -1517) (900 . 1518) (" " . 900) (569 . 901) ("
" . -569) (484 . 570) (" " . 484) (456 . 485) ("
" . -456) (388 . 457) (" " . 388) (117 . 389) ("(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(ansi-color-faces-vector
   [default default default italic underline success warning error])
 '(ansi-color-names-vector
   [\"#212526\" \"#ff4b4b\" \"#b4fa70\" \"#fce94f\" \"#729fcf\" \"#e090d7\" \"#8cc4ff\" \"#eeeeec\"])
 '(async-shell-command-buffer 'new-buffer)
 '(company-quickhelp-color-background \"#4F4F4F\")
 '(company-quickhelp-color-foreground \"#DCDCCC\")
 '(confirm-kill-emacs 'yes-or-no-p)
 '(cua-highlight-region-shift-only t)
 '(cua-remap-control-v nil)
 '(cua-remap-control-z nil)
 '(custom-enabled-themes '(zenburn))
 '(custom-safe-themes
   '(\"a27c00821ccfd5a78b01e4f35dc056706dd9ede09a8b90c6955ae6a390eb1c1e\" \"13bfd13e75a5f873db41919fa793c5422bfcd5e1cd78587158c06acbe8e49789\" \"fa2b58bb98b62c3b8cf3b6f02f058ef7827a8e497125de0254f56e373abee088\" \"bffa9739ce0752a37d9b1eee78fc00ba159748f50dc328af4be661484848e476\" \"2074a98e21377af1c50897d4330caca2b719542bcdf9618ed3c1575c99b41363\" \"6343f4d41b209fe8990e3c5f4d2040b359612ef9cd8682f1e1e2a836beba8107\" \"4e5e58e42f6f37920b95a8502f488928b3dab9b6cc03d864e38101ce36ecb968\" \"4639288d273cbd3dc880992e6032f9c817f17c4a91f00f3872009a099f5b3f84\" \"3a58d06b485e0dda454dac9f40884b2677fe9582f34b3f5587b7d75505aa4d09\" default))
 '(custom-theme-directory \"~/.emacs.d/themes\")
 '(display-time-string-forms
   '((propertize
      (concat dayname \" \" day \" \" monthname \" \" 12-hours \":\" minutes \" \"
	      (upcase am-pm)
	      \" \")
      'help-echo
      (format-time-string \"%a, %b %e %Y\" now))))
 '(eclim-executable \"/home/siyer/eclipse/java-2020-12/eclipse/plugins/\")
 '(ede-project-directories
   '(\"/home/siyer/docs/projects/Arduino/Electric_Trombone/Code_2\" \"/home/siyer/docs/projects/Arduino/foot_pedal/code_1\" \"/home/siyer/docs/coding/Python/env/projects/web_automation/delivery-service\" \"/home/siyer\"))
 '(eimp-mogrify-program \"/usr/bin/mogrify\")
 '(ein:jupyter-default-notebook-directory \"~/docs/coding/Python/env\")
 '(ein:jupyter-default-server-command \"~/docs/coding/Python/env/bin/jupyter\")
 '(ein:jupyter-server-command \"~/docs/coding/Python/env/bin/jupyter\")
 '(elpy-rpc-python-command \"~/docs/coding/Python/env/bin/python\")
 '(elpy-rpc-virtualenv-path \"~/docs/coding/Python/env2/\")
 '(evil-move-cursor-back nil)
 '(evil-undo-system \"undo-tree\")
 '(evil-want-fine-undo t)
 '(fci-rule-color \"#383838\")
 '(inferior-lisp-program \"/usr/local/sbcl\")
 '(initial-major-mode 'org-mode)
 '(js3-auto-indent-p t)
 '(lisp-mode-hook '(slime-lisp-mode-hook))
 '(mailcap-user-mime-data '((\"\" \"image/*;
 open -a Preview %s\" nil)))
 '(message-send-mail-function 'message-send-mail-with-sendmail)
 '(newsticker-url-list
   '((\"newyorktimes\" \"https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml\" nil nil nil)
     (\"fullnyt\" \"https://morss.it/https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml\" nil nil nil)))
 '(newsticker-url-list-defaults
   '((\"Debian Security Advisories\" \"http://www.debian.org/security/dsa.en.rdf\")
     (\"Debian Security Advisories - Long format\" \"http://www.debian.org/security/dsa-long.en.rdf\")
     (\"Emacs Wiki\" \"https://www.emacswiki.org/emacs?action=rss\" nil 3600)
     (\"LWN (Linux Weekly News)\" \"https://lwn.net/headlines/rss\")
     (\"Quote of the day\" \"http://feeds.feedburner.com/quotationspage/qotd\" \"07:00\" 86400)
     (\"The Register\" \"https://www.theregister.co.uk/headlines.rss\")
     (\"slashdot\" \"http://rss.slashdot.org/Slashdot/slashdot\" nil 3600)
     (\"Wired News\" \"https://www.wired.com/feed/rss\")))
 '(notmuch-address-internal-completion '(received nil))
 '(notmuch-command \"/usr/bin/notmuch\")
 '(notmuch-hello-sections
   '(notmuch-hello-insert-header notmuch-hello-insert-saved-searches notmuch-hello-insert-search notmuch-hello-insert-recent-searches notmuch-hello-insert-header notmuch-hello-insert-alltags notmuch-hello-insert-footer))
 '(nrepl-message-colors
   '(\"#CC9393\" \"#DFAF8F\" \"#F0DFAF\" \"#7F9F7F\" \"#BFEBBF\" \"#93E0E3\" \"#94BFF3\" \"#DC8CC3\"))
 '(org-agenda-files '(\"~/docs/todo\"))
 '(org-babel-python-command \"python3\")
 '(org-babel-python-mode 'ipython)
 '(org-fontify-whole-heading-line t)
 '(org-html-table-default-attributes
   '(:border \"2\" :cellspacing \"2\" :cellpadding \"6\" :rules \"groups\" :frame \"border\"))
 '(org-indent-indentation-per-level 4)
 '(org-log-done 'note)
 '(org-log-done-with-time nil)
 '(org-pandoc-command \"/usr/bin/pandoc\")
 '(org-startup-align-all-tables t)
 '(org-startup-folded 'content)
 '(org-support-shift-select 'always)
 '(org-trello-current-prefix-keybinding \"C-c o\")
 '(package-check-signature nil)
 '(package-selected-packages
   '(undo-fu undo-fu-session undo-propose undohist undo-tree treemacs-evil powerline-evil evil-org evil-tex thingopt emms xkcd telephone-line pdf-view-restore symon npm-mode goto-line-preview color-identifiers-mode dashboard page-break-lines fish-completion fish-mode volume indium manage-minor-mode elpy python-mode pyvenv dired-git-info define-word sclang-extensions sclang-snippets apples-mode applescript-mode eimp vimish-fold aggressive-indent flycheck-swiftx ob-swift swift-helpful swift-mode swift-playground-mode swift3-mode multi-vterm typit springboard ## rainbow-mode railscasts-reloaded-theme railscasts-theme xref-js2 js-format js-react-redux-yasnippets js2-closure js2-highlight-vars js2-mode json js2-refactor ido-at-point ido-better-flex ido-clever-match ido-complete-space-or-hyphen ido-completing-read+ ido-describe-bindings ido-exit-target ido-flex-with-migemo ido-gnus ido-grid-mode ido-hacks ido-load-library ido-migemo ido-occasional ido-occur ido-select-window ido-skk ido-sort-mtime ido-ubiquitous ido-vertical-mode ido-yes-or-no idomenu ibuffer-git ibuffer-project ibuffer-projectile ibuffer-rcirc ibuffer-sidebar ibuffer-tramp ibuffer-vc vterm vterm-toggle vlf bash-completion conda copyit copyit-pandoc crux dired-atool dired-collapse dired-dups dired-efap dired-explorer dired-filetype-face dired-filter dired-git dired-hacks-utils dired-imenu dired-k dired-launch dired-nav-enhance dired-open dired-quick-sort dired-rainbow dired-recent dired-rmjunk dired-rsync dired-sidebar dired-single dired-subtree dired-toggle dired-toggle-sudo diredfl diredful direnv dirtree dotenv-mode drag-stuff egg ein-mumamo elpygen buffer-flip buffer-manage buffer-move buffer-sets buffer-utils ein mew pandoc pandoc-mode helm-bibtex helm-fd helm-zhihu-daily xwidgete company-anaconda company-ansible company-arduino company-auctex company-axiom company-bibtex company-c-headers company-cabal company-childframe company-coq company-dcd company-dict company-distel company-ebdb company-edbi company-emacs-eclim company-emoji company-erlang company-flow company-flx company-fuzzy company-ghc company-ghci company-glsl company-go company-inf-ruby company-irony company-irony-c-headers company-jedi company-lean company-lsp company-lua company-math company-nand2tetris company-nginx company-ngram company-nixos-options company-php company-phpactor company-plsense company-pollen company-posframe company-prescient company-qml company-quickhelp company-racer company-reftex company-restclient company-rtags company-shell company-solidity company-sourcekit company-statistics company-suggest company-tabnine company-tern company-terraform company-try-hard company-web company-ycm company-ycmd gradle-mode ag cider clojure-mode counsel less-css-mode bongo emms-soundcloud flycheck-ameba flycheck-apertium flycheck-ats2 flycheck-bashate flycheck-cask flycheck-checkbashisms flycheck-checkpatch flycheck-clang-analyzer flycheck-clang-tidy flycheck-clangcheck flycheck-clj-kondo flycheck-clojure flycheck-clolyze flycheck-color-mode-line flycheck-coverity flycheck-credo flycheck-crystal flycheck-css-colorguard flycheck-cstyle flycheck-cython flycheck-d-unittest flycheck-dedukti flycheck-demjsonlint flycheck-dialyxir flycheck-dialyzer flycheck-dogma flycheck-dtrace flycheck-elixir flycheck-elm flycheck-elsa flycheck-ensime flycheck-flawfinder flycheck-flow flycheck-ghcmod flycheck-golangci-lint flycheck-gometalinter flycheck-gradle flycheck-grammalecte flycheck-haskell flycheck-hdevtools flycheck-indicator flycheck-ini-pyinilint flycheck-inline flycheck-irony flycheck-jest flycheck-joker flycheck-julia flycheck-kotlin flycheck-ledger flycheck-lilypond flycheck-liquidhs flycheck-mercury flycheck-mix flycheck-mmark flycheck-mypy flycheck-nim flycheck-nimsuggest flycheck-objc-clang flycheck-ocaml flycheck-package flycheck-pact flycheck-perl6 flycheck-phpstan flycheck-pkg-config flycheck-plantuml flycheck-pony flycheck-popup-tip flycheck-pos-tip flycheck-posframe flycheck-prospector flycheck-purescript flycheck-pycheckers flycheck-pyflakes flycheck-pyre flycheck-rebar3 flycheck-rtags flycheck-rust flycheck-soar flycheck-stack flycheck-status-emoji flycheck-swift flycheck-swift3 flycheck-swiftlint flycheck-tcl flycheck-tip flycheck-title flycheck-vale flycheck-vdm flycheck-xcode flycheck-yamllint flycheck-yang flycheck-ycmd git-auto-commit-mode git-command git-io git-lens git-link git-messenger git-timemachine gitconfig gitconfig-mode github-browse-file github-clone github-elpa github-explorer github-issues github-modern-theme github-notifier github-pullrequest github-review github-search github-stars gitignore-mode gitignore-templates gitlab gitlab-ci-mode gitlab-ci-mode-flycheck gitolite-clone helm helm-R helm-ack helm-ad helm-addressbook helm-ag helm-ag-r helm-aws helm-backup helm-bbdb helm-bibtexkey helm-bind-key helm-bitbucket helm-bm helm-books helm-bundle-show helm-c-moccur helm-c-yasnippet helm-catkin helm-charinfo helm-chrome helm-chrome-control helm-chrome-history helm-chronos helm-cider helm-cider-history helm-circe helm-clojuredocs helm-cmd-t helm-codesearch helm-commandlinefu helm-company helm-core helm-cscope helm-css-scss helm-ctest helm-dash helm-descbinds helm-describe-modes helm-dictionary helm-directory helm-dired-history helm-dired-recent-dirs helm-dirset helm-elscreen helm-emmet helm-emms helm-esa helm-etags-plus helm-evil-markers helm-eww helm-ext helm-exwm helm-file-preview helm-filesets helm-firefox helm-flx helm-flycheck helm-flymake helm-flyspell helm-frame helm-fuz helm-fuzzier helm-fuzzy helm-fuzzy-find helm-ghc helm-ghq helm-ghs helm-git helm-git-files helm-git-grep helm-github-stars helm-gitignore helm-gitlab helm-go-package helm-google helm-grepint helm-growthforecast helm-gtags helm-hatena-bookmark helm-hayoo helm-helm-commands helm-hoogle helm-hunks helm-idris helm-img helm-img-tiqav helm-itunes helm-j-cheatsheet helm-jira helm-js-codemod helm-jstack helm-kythe helm-lastpass helm-lean helm-lib-babel helm-lines helm-lobsters helm-ls-git helm-ls-hg helm-ls-svn helm-lxc helm-make helm-migemo helm-mode-manager helm-mt helm-mu helm-navi helm-nixos-options helm-notmuch helm-open-github helm-org helm-org-rifle helm-orgcard helm-osx-app helm-pages helm-pass helm-perldoc helm-perspeen helm-phpunit helm-posframe helm-proc helm-project-persist helm-projectile helm-prosjekt helm-pt helm-purpose helm-pydoc helm-qiita helm-rage helm-rails helm-rb helm-rdefs helm-recoll helm-rg helm-rhythmbox helm-robe helm-ros helm-rtags helm-rubygems-local helm-rubygems-org helm-safari helm-sage helm-selected helm-sheet helm-slime helm-smex helm-spaces helm-spotify helm-spotify-plus helm-sql-connect helm-swoop helm-system-packages helm-systemd helm-tail helm-taskswitch helm-themes helm-tramp helm-unicode helm-w32-launcher helm-w3m helm-wordnet helm-xcdoc helm-youtube helm-z help-find-org-mode helpful ivy-todo ivy-youtube java-imports jquery-doc js-auto-beautify js-auto-format-mode js-codemod js-import js3-mode jscs json-navigator json-process-client json-reformatter-jq json-rpc json-rpc-server jsonl jsonnet-mode jupyter live-py-mode magit-annex magit-circleci magit-diff-flycheck magit-filenotify magit-find-file magit-gerrit magit-gh-pulls magit-gitflow magit-lfs magit-org-todos magit-p4 magit-rbr magit-reviewboard magit-stgit magit-svn magit-topgit magit-vcsh magithub malinka marcopolo markless markup math-symbols multi multi-compile multi-line multi-project multi-run multi-web-mode multicolumn multifiles multishell neotree oauth oauth2 org-ac org-agenda-property org-alert org-analyzer org-attach-screenshot org-autolist org-beautify-theme org-board org-bookmark-heading org-capture-pop-frame org-cliplink org-clock-convenience org-clock-csv org-clock-today org-commentary org-context org-cua-dwim org-d20 org-dashboard org-doing org-dotemacs org-dp org-drill-table org-dropbox org-easy-img-insert org-edit-latex org-edna org-ehtml org-elisp-help org-emms org-evil org-onenote org-picklink orgalist origami osc osx-browse osx-dictionary osx-lib osx-trash outline-toc outlook outorg ox-asciidoc ox-epub ox-html5slide ox-impress-js ox-ioslide ox-mdx-deck ox-mediawiki ox-minutes ox-nikola ox-pandoc ox-pukiwiki ox-slack ox-slimhtml ox-tufte ox-wk pcmpl-git pcmpl-homebrew pcmpl-pip playerctl poly-org pyenv-mode pyenv-mode-auto pyimport pyimpsort pytest python-cell python-docstring python-environment python-info python-pytest python-switch-quotes python-test python-x scheme-complete search-web sound-wav soundcloud soundklaus ssh ssh-tunnels travis tree-mode treemacs-icons-dired treemacs-magit treepy xcode-mode xcode-project helm-ispell ac-c-headers ac-capf ac-cider ac-clang ac-dcd ac-emacs-eclim ac-emmet ac-emoji ac-etags ac-geiser ac-helm ac-html ac-html-angular ac-html-bootstrap ac-html-csswatcher ac-inf-ruby ac-ispell ac-js2 ac-math ac-octave ac-php ac-php-core ac-sly ace-flyspell ace-isearch ace-jump-buffer ace-jump-helm-line ace-jump-mode ace-jump-zap ace-link ace-mc ace-popup-menu add-hooks anaconda-mode android-env android-mode angular-mode angular-snippets anki-editor anki-mode auto-package-update web-narrow-mode web-mode-edit-element web-completion-data web-beautify use-package-hydra use-package-ensure-system-package use-package-el-get use-package-chords otama orgtbl-show-header orgtbl-join orgtbl-ascii-plot orgtbl-aggregate orgnav orgbox org2web org2jekyll org2issue org2elcomment org-wunderlist org-web-tools org-wc org-trello org-tree-slide org-transform-tree-table org-tracktable org-toodledo org-timeline org-time-budgets org-themis org-tfl org-table-comment org-sync-snippets org-sync org-sticky-header org-starter-swiper org-sql org-snooze org-shoplist org-send-ebook org-seek org-rtm org-rich-yank org-review org-repo-todo org-redmine org-recur org-randomnote org-random-todo org-radiobutton org-protocol-jekyll org-projectile-helm org-preview-html org-present-remote org-pomodoro org-password-manager org-parser org-page org-outlook org-outline-numbering org-octopress org-notebook org-multiple-keymap org-mobile-sync org-mind-map org-lookup-dnd org-listcruncher org-linkany org-link-travis org-link-minor-mode org-kindle org-journal-list org-iv org-if org-grep org-gnome org-fancy-priorities org-bullets evil-visualstar evil-visual-replace evil-visual-mark-mode evil-vimish-fold evil-tutor-ja evil-traces evil-textobj-syntax evil-textobj-line evil-textobj-entire evil-textobj-column evil-textobj-anyblock evil-text-object-python evil-test-helpers evil-terminal-cursor-changer evil-tabs evil-swap-keys evil-string-inflection evil-space evil-smartparens evil-search-highlight-persist evil-ruby-text-objects evil-rsi evil-replace-with-register evil-replace-with-char evil-rails evil-quickscope evil-python-movement evil-paredit evil-owl evil-opener evil-nl-break-undo evil-nerd-commenter evil-multiedit evil-mu4e evil-mc-extras evil-matchit evil-mark-replace evil-magit evil-lispy evil-lisp-state evil-lion evil-ledger evil-leader evil-indent-textobject evil-indent-plus evil-iedit-state evil-goggles evil-god-state evil-fringe-mark evil-find-char-pinyin evil-extra-operator evil-expat evil-exchange evil-ex-shell-command evil-ex-fasd evil-escape evil-embrace evil-ediff evil-easymotion evil-dvorak evil-commentary evil-collection evil-colemak-minimal evil-colemak-basics evil-cleverparens evil-better-visual-line evil-avy evil-args evil-anzu dockerfile-mode docker-compose-mode docker-cli docker-api docker auto-complete-sage auto-complete-rst auto-complete-pcmp auto-complete-nxml auto-complete-exuberant-ctags auto-complete-distel auto-complete-clang-async auto-complete-clang auto-complete-chunk auto-complete-c-headers auto-complete-auctex auto-compile auto-auto-indent))
 '(pandoc-binary \"/usr/bin/pandoc\")
 '(pdf-view-midnight-colors '(\"#DCDCCC\" . \"#383838\"))
 '(python-shell-completion-native-disabled-interpreters '(\"pypy\" \"ipython\" \"python\"))
 '(python-shell-interpreter \"/home/siyer/docs/coding/Python/env/bin/ipython3\")
 '(python-shell-virtualenv-root \"~/docs/coding/Python/env/\")
 '(pyvenv-virtualenvwrapper-python \"~/docs/coding/Python/env/bin/python\")
 '(read-mail-command 'notmuch)
 '(send-mail-function 'mailclient-send-it)
 '(smtpmail-smtp-server \"smtp.gmail.com\")
 '(smtpmail-smtp-service 587)
 '(vc-annotate-background \"#2B2B2B\")
 '(vc-annotate-color-map
   '((20 . \"#BC8383\")
     (40 . \"#CC9393\")
     (60 . \"#DFAF8F\")
     (80 . \"#D0BF8F\")
     (100 . \"#E0CF9F\")
     (120 . \"#F0DFAF\")
     (140 . \"#5F7F5F\")
     (160 . \"#7F9F7F\")
     (180 . \"#8FB28F\")
     (200 . \"#9FC59F\")
     (220 . \"#AFD8AF\")
     (240 . \"#BFEBBF\")
     (260 . \"#93E0E3\")
     (280 . \"#6CA0A3\")
     (300 . \"#7CB8BB\")
     (320 . \"#8CD0D3\")
     (340 . \"#94BFF3\")
     (360 . \"#DC8CC3\")))
 '(vc-annotate-very-old-color \"#DC8CC3\"))" . -117) nil ("-" . -35272) ("s" . -35273) ("e" . -35274) ("s" . -35275) ("s" . -35276) ("i" . -35277) ("o" . -35278) ("n" . -35279) ("-" . -35280) ("m" . -35281) ("o" . -35282) ("d" . -35283) ("e" . -35284) ("-" . -35285) ("h" . -35286) ("o" . -35287) ("o" . -35288) ("k" . -35289) 35290 nil ("dafdafdafs" . 35320) nil (35320 . 35330) nil (35265 . 35290) ("undo-fu" . -35265) 35272 nil (35265 . 35272) nil ("e" . -35239) 35240 nil (35239 . 35240) nil (35212 . 35239) ("global-undo-fu" . -35212) 35226 nil (35215 . 35226) nil ("a" . -35215) 35216 nil (35212 . 35216) (35211 . 35213) nil (35210 . 35211) nil (35189 . 35209) ("undo-fu-mod" . -35189) 35200 nil (35189 . 35200) (35188 . 35190) nil (35187 . 35188) nil ("u" . -35212) ("n" . -35213) ("d" . -35214) ("o" . -35215) ("-" . -35216) ("f" . -35217) ("u" . -35218) ("-" . -35219) 35220 nil (35212 . 35220) ("undo-fu" . -35212) 35219 nil ("-" . -35219) ("m" . -35220) 35221 nil (35220 . 35221) nil ("d" . -35220) ("i" . -35221) ("s" . -35222) ("a" . -35223) ("b" . -35224) ("l" . -35225) ("e" . -35226) ("-" . -35227) ("c" . -35228) ("h" . -35229) ("e" . -35230) ("c" . -35231) ("k" . -35232) ("p" . -35233) ("o" . -35234) ("i" . -35235) ("n" . -35236) ("t" . -35237) 35238) (emacs-undo-equiv-table))