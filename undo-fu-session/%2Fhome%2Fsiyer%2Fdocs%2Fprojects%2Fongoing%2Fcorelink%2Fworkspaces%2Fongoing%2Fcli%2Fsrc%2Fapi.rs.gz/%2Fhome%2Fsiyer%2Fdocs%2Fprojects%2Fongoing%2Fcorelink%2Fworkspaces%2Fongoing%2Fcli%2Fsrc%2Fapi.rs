((buffer-size . 2138) (buffer-checksum . "04f292badc744750c13b795b3a2fd550abf21171"))
((emacs-buffer-undo-list nil ("use std::io;
" . 1) ((marker . 281) . -13) ((marker . 234) . -11) 12 (t 25191 8533 558601 921000)) (emacs-pending-undo-list) (emacs-undo-equiv-table))