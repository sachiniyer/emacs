((buffer-size . 2141) (buffer-checksum . "ea9cc249feffbd18d12b3ce567747b0d922dcac3"))
((emacs-buffer-undo-list nil (1209 . 2009) nil ("
class ServoKit(object):
    default_angle = 90

    def __init__(self, num_ports):
        print(\"Initializing the servo...\")
        self.kit = adafruit_servokit.ServoKit(channels=16)
        self.num_ports = num_ports
        self.resetAll()
        print(\"Initializing complete.\")

    def setAngle(self, port, angle):
        if angle < 0:
            self.kit.servo[port].angle = 0
        elif angle > 180:
            self.kit.servo[port].angle = 180
        else:
            self.kit.servo[port].angle = angle

    def getAngle(self, port):
        return self.kit.servo[port].angle

    def reset(self, port):
        self.kit.servo[port].angle = self.default_angle

    def resetAll(self):
        for i in range(self.num_ports):
            self.kit.servo[i].angle = self.default_angle

" . 1209) ((marker . 1233) . -24) ((marker . 2009) . -799) ((marker . 1730) . -521) ((marker . 1730) . -521) ((marker . 1730) . -521) ((marker . 1730) . -521) ((marker . 1730) . -521) ((marker . 1233) . -24) ((marker . 1233) . -24) ((marker . 2009) . -799) ((marker . 2009) . -799) ((marker . 2010) . -800) ((marker . 2008) . -799) ((marker) . -799) 2008 nil ("import 
" . 1208) ((marker . 2009) . -7) ((marker* . 1208) . 1) ((marker . 1208) . -7) ((marker . 1208) . -7) ((marker . 1208) . -7) ((marker . 1208) . -7) ((marker . 2009) . -7) ((marker . 2009) . -7) ((marker . 2010) . -8) 1215 nil (1212 . 1215) (t 24631 32215 0 0) nil (1208 . 1212) nil (1207 . 1208) nil (2082 . 2083) nil ("/" . -2082) ((marker) . -1) 2083 nil (2082 . 2083) nil ("
" . 2078) ((marker . 2010) . -1) nil ("        time.sleep(.05)
" . 2078) ((marker) . -8) ((marker . 2010) . -24) 2086 nil ("        servoKit.setAngle(1, i)
" . 2078) ((marker) . -8) ((marker) . -8) ((marker . 2010) . -32) 2086 nil ("    for i in range(145,15,-5):
" . 2078) ((marker) . -4) ((marker . 2010) . -31) 2082 nil ("        time.sleep(.05)
" . 2078) ((marker) . -8) ((marker . 2010) . -24) 2086 nil ("        servoKit.setAngle(1, i)
" . 2078) ((marker . 1233) . -8) ((marker . 2009) . -8) ((marker . 2078) . -8) ((marker) . -8) ((marker . 2010) . -32) 2086 nil ("
" . 2078) ((marker . 2010) . -1) nil ("    for i in range(15,145, 5):
" . 2079) ((marker . 2010) . -31) nil ("        servoKit.setAngle(0, i)
" . 2078) ((marker) . -32) ((marker . 2010) . -32) nil ("        time.sleep(.05)
" . 2110) ((marker) . -8) ((marker) . -8) ((marker . 2010) . -24) 2118 nil ("    for i in range(180,0,-5):
" . 2078) ((marker) . -5) ((marker . 2010) . -30) 2083 nil (2053 . 2054) nil ("/" . -2053) ((marker) . -1) ((marker) . -1) ("/" . -2054) ((marker) . -1) ((marker) . -1) (" " . -2055) ((marker) . -1) ((marker) . -1) 2056 nil (2053 . 2056) nil ("    time.sleep(.05)
" . 2077) ((marker) . -4) ((marker . 2010) . -20) ((marker* . 1208) . 16) 2081 nil ("    " . -2081) nil ("    " . -2053) ((marker) . -4) ((marker) . -4) 2057 nil ("    for i in range(0,180, 5):
" . 2049) ((marker) . -4) ((marker . 2010) . -30) 2053 nil ("    print(\"Start test\")
" . 2049) ((marker) . -8) ((marker . 2010) . -24) 2057 (t 24630 53682 0 0) nil ("    " . 2420) ("    " . 1729) (2491 . 2492) 2289 nil ("        servoKit.setAngle(3, i)
" . 2400) ((marker) . -8) ((marker . 2010) . -32) 2408 nil ("        servoKit.setAngle(3, i)
" . 2313) ((marker) . -8) ((marker . 2010) . -32) 2321 nil ("        servoKit.setAngle(2, i)
" . 2225) ((marker) . -8) ((marker) . -8) ((marker . 2010) . -32) 2233 nil ("        servoKit.setAngle(2, i)
" . 2139) ((marker) . -25) ((marker . 2010) . -32) ((marker*) . 7) ((marker) . -26) ((marker*) . 2) ((marker) . -31) 2164 nil ("4" . 2050) (t 24628 21341 0 0) (2051 . 2052) 2050 (t 24628 21341 0 0)) (emacs-pending-undo-list (")" . -2743) (2743 . 2744) (")" . -2743) (2743 . 2744) nil (2742 . 2743) (2722 . 2743) nil (2731 . 2740) nil ("i" . -2731) ((marker) . -1) 2732 nil (2724 . 2732) nil (2723 . 2724) nil (2722 . 2723) nil ("
" . 3522) ((marker) . -1) nil (nil rear-nonsticky nil 3521 . 3522) (nil fontified nil 2722 . 3522) (2722 . 3522) nil ("
class ServoKit(object):
    default_angle = 90

    def __init__(self, num_ports):
        print(\"Initializing the servo...\")
        self.kit = adafruit_servokit.ServoKit(channels=16)
        self.num_ports = num_ports
        self.resetAll()
        print(\"Initializing complete.\")

    def setAngle(self, port, angle):
        if angle < 0:
            self.kit.servo[port].angle = 0
        elif angle > 180:
            self.kit.servo[port].angle = 180
        else:
            self.kit.servo[port].angle = angle

    def getAngle(self, port):
        return self.kit.servo[port].angle

    def reset(self, port):
        self.kit.servo[port].angle = self.default_angle

    def resetAll(self):
        for i in range(self.num_ports):
            self.kit.servo[i].angle = self.default_angle

" . 216) ((marker . 3377) . -799) (nil fontified t 1000 . 1015) (nil fontified t 996 . 1000) (nil fontified t 993 . 996) (nil fontified t 987 . 993) (nil fontified t 974 . 987) (nil fontified t 970 . 974) (nil fontified t 945 . 970) (nil fontified t 941 . 945) (nil fontified t 940 . 941) (nil fontified t 935 . 940) (nil fontified t 934 . 935) (nil fontified t 932 . 934) (nil fontified t 929 . 932) (nil fontified t 926 . 929) (nil fontified t 915 . 926) (nil fontified t 911 . 915) (nil fontified t 910 . 911) (nil fontified t 902 . 910) (nil fontified t 901 . 902) (nil fontified t 898 . 901) (nil fontified t 878 . 898) (nil fontified t 874 . 878) (nil fontified t 871 . 874) (nil fontified t 865 . 871) (nil fontified t 849 . 865) (nil fontified t 845 . 849) (nil fontified t 828 . 845) (nil fontified t 824 . 828) (nil fontified t 823 . 824) (nil fontified t 818 . 823) (nil fontified t 817 . 818) (nil fontified t 814 . 817) (nil fontified t 786 . 814) (nil fontified t 782 . 786) (nil fontified t 781 . 782) (nil fontified t 775 . 781) (nil fontified t 758 . 775) (nil fontified t 754 . 758) (nil fontified t 753 . 754) (nil fontified t 745 . 753) (nil fontified t 744 . 745) (nil fontified t 741 . 744) (nil fontified t 736 . 741) (nil fontified t 727 . 736) (nil fontified t 721 . 727) (nil fontified t 716 . 721) (nil fontified t 705 . 716) (nil fontified t 701 . 705) (nil fontified t 687 . 701) (nil fontified t 683 . 687) (nil fontified t 668 . 683) (nil fontified t 662 . 668) (nil fontified t 646 . 662) (nil fontified t 642 . 646) (nil fontified t 616 . 642) (nil fontified t 612 . 616) (nil fontified t 599 . 612) (nil fontified t 593 . 599) (nil fontified t 577 . 593) (nil fontified t 573 . 577) (nil fontified t 549 . 573) (nil fontified t 547 . 549) (nil fontified t 523 . 547) (nil fontified t 519 . 523) (nil fontified t 518 . 519) (nil fontified t 510 . 518) (nil fontified t 509 . 510) (nil fontified t 506 . 509) (nil fontified t 499 . 506) (nil fontified t 475 . 499) (nil fontified t 474 . 475) (nil fontified t 469 . 474) (nil fontified t 449 . 469) (nil fontified t 445 . 449) (nil fontified t 414 . 445) (nil fontified t 410 . 414) (nil fontified t 355 . 410) (nil fontified t 351 . 355) (nil fontified t 341 . 351) (nil fontified t 314 . 341) (nil fontified t 313 . 314) (nil fontified t 308 . 313) (nil fontified t 286 . 308) (nil fontified t 282 . 286) (nil fontified t 281 . 282) (nil fontified t 273 . 281) (nil fontified t 272 . 273) (nil fontified t 269 . 272) (nil fontified t 258 . 269) (nil fontified t 245 . 258) (nil fontified t 238 . 245) (nil fontified t 232 . 238) (nil fontified t 231 . 232) (nil fontified t 223 . 231) (nil fontified t 222 . 223) (nil fontified t 217 . 222) (nil fontified t 216 . 217) (nil rear-nonsticky t 1015 . 1016) nil (nil rear-nonsticky nil 1015 . 1016) (nil fontified nil 216 . 1016) (216 . 1016) nil (2 . 14) nil ("S" . -2) ((marker) . -1) ((marker) . -1) ("a" . -3) ((marker) . -1) ((marker) . -1) ("c" . -4) ((marker) . -1) ((marker) . -1) ("h" . -5) ((marker) . -1) ("i" . -6) ((marker) . -1) ("n" . -7) ((marker) . -1) 8 nil (1 . 8) nil (1 . 3) nil ("
" . 16) ((marker) . -1) ((marker) . -1) nil ("u" . 17) nil (17 . 18) nil ("u" . -17) ((marker) . -1) 18 nil (17 . 18) nil (16 . 17) 16 nil (2535 . 2575) nil ("# Using globals to simplify sample code
" . 2535) ((marker . 3378) . -18) ((marker . 3614) . -18) ((marker* . 3622) . 21) ((marker . 3614) . -18) ((marker . 3614) . -18) ((marker) . -18) ((marker) . -18) ((marker) . -40) 2553 nil ("# since it is subscribed to that same topic.
" . 201) ((marker . 228) . -44) ((marker) . -45) nil ("# The device should receive those same messages back from the message broker,
" . 201) ((marker) . -78) nil ("# subscribes to a topic, and begins publishing messages to that topic.
" . 201) ((marker) . -71) nil ("# through an MQTT connection. On startup, the device connects to the server,
" . 201) ((marker) . -77) nil ("# This sample uses the Message Broker for AWS IoT to send and receive messages
" . 201) ((marker) . -79) nil ("
" . 1) ((marker) . -1) nil ("# SPDX-License-Identifier: Apache-2.0.
" . 1) ((marker . 2823) . -39) ((marker) . -39) nil ("# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
" . 1) ((marker) . -24) ((marker) . -69) 25 nil (291 . 308) ("adafr" . -291) ((marker) . -5) 296 nil (291 . 296) nil ("s" . -291) ((marker) . -1) ("e" . -292) ((marker) . -1) ("r" . -293) ((marker) . -1) ("v" . -294) ((marker) . -1) ("o" . -295) ((marker) . -1) ("k" . -296) ((marker) . -1) 297 nil (284 . 297) nil ("import adafruit_servo" . 284) ((marker) . -21) nil ("kit" . 305) nil ("


" . 660) ((marker) . -3) ((marker) . -3) nil (660 . 663) nil (305 . 308) nil (284 . 305) nil (283 . 284) nil (272 . 283) nil (271 . 272) nil ("    global received_count
" . 4542) ((marker . 3378) . -16) ((marker) . -26) ((marker) . -16) ((marker) . -26) 4558 nil ("        received_all_event.set()
" . 4568) ((marker) . -8) ((marker) . -33) 4576 nil ("    if received_count == args.count:
" . 4568) ((marker) . -4) ((marker) . -37) 4572 nil ("    received_count += 1
" . 4568) ((marker . 3378) . -15) ((marker) . -15) ((marker) . -24) 4583 nil ("received_count = 0
" . 3090) ((marker . 3378) . -15) ((marker . 3614) . -15) ((marker* . 3622) . 3) ((marker . 3614) . -15) ((marker . 3614) . -15) ((marker) . -15) ((marker) . -19) 3105 (t 24631 33348 0 0) nil ("c" . -1152) ((marker) . -1) ((marker) . -1) ("e" . -1153) ((marker) . -1) ((marker) . -1) ("r" . -1154) ((marker) . -1) ((marker) . -1) ("t" . -1155) ((marker) . -1) ((marker) . -1) ("s" . -1156) ((marker) . -1) ((marker) . -1) ("/" . -1157) ((marker) . -1) 1158 nil ("c" . -1034) ((marker . 3378) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker) . -1) ((marker) . -1) ("e" . -1035) ((marker . 3378) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker) . -1) ((marker) . -1) ("r" . -1036) ((marker . 3378) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker) . -1) ((marker) . -1) ("t" . -1037) ((marker . 3378) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker) . -1) ((marker) . -1) ("s" . -1038) ((marker . 3378) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker) . -1) ((marker) . -1) ("/" . -1039) ((marker . 3378) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker . 3614) . -1) ((marker) . -1) 1040 (t 24631 33309 0 0) nil (1032 . 1033) nil ("r" . 1032) nil ("e" . 1032) nil ("y" . 1032) nil ("i" . 1032) nil ("s" . 1032) nil ("/" . 1032) nil ("e" . 1032) nil ("m" . 1032) nil ("o" . 1032) nil ("h" . 1032) nil ("/" . 1032) nil (1166 . 1167) nil ("r" . 1166) nil ("e" . 1166) nil ("y" . 1166) nil ("i" . 1166) ((marker . 755) . -1) ((marker . 755) . -1) ((marker . 755) . -1) nil ("s" . 1166) nil ("/" . 1166) nil ("e" . 1166) nil ("m" . 1166) nil ("o" . 1166) nil ("h" . 1166) nil ("/" . 1166) nil (1298 . 1299)) (emacs-undo-equiv-table (-10 . -12) (1 . 3) (-16 . -22) (-17 . -21) (-18 . -20) (-22 . -24) (-37 . -41) (-38 . -40) (-36 . -42)))