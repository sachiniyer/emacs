((buffer-size . 2496) (buffer-checksum . "afdd9d7439cc809757e71f7ffcd7f1489081a974"))
((emacs-buffer-undo-list (2496 . 2497) nil (2495 . 2496) ("}" . -2495) (2495 . 2496) nil (907 . 909) (890 . 894) ("  " . 890) (846 . 850) ("  " . 846) (840 . 844) ("  " . 840) (832 . 838) ("    " . 832) (817 . 818) ("      " . 817) (771 . 777) ("    " . 771) (732 . 736) ("  " . 732) (699 . 703) ("  " . 699) (646 . 648) (641 . 643) (625 . 629) ("  " . 625) (619 . 623) ("  " . 619) (611 . 617) ("    " . 611) (600 . 601) ("      " . 600) (551 . 557) ("    " . 551) (512 . 516) ("  " . 512) (479 . 483) ("  " . 479) (414 . 416) (409 . 411) (393 . 397) ("  " . 393) (387 . 391) ("  " . 387) (379 . 385) ("    " . 379) (368 . 369) ("      " . 368) (317 . 323) ("    " . 317) (278 . 282) ("  " . 278) (244 . 248) ("  " . 244) (177 . 179) (148 . 150) ("}" . 147) ((marker* . 2497) . 1) ((marker*) . 1) ((marker) . -1) nil (146 . 148) nil (131 . 146) nil (123 . 131) nil (122 . 123) (t 24672 54662 433471 654000) 102 nil ("
// output operators
ostream& operator<<(ostream& os, const Student& rhs) {
  os << \"Name: \" << rhs.name << endl;
  os << \"Courses: \";
  size_t len = rhs.courses.size();
  for (size_t i = 0; i < len; i++) {
    os << rhs.courses[i]->getName() << \" \";
  }
  os << endl;
  return os;
}

" . 2081) nil (2081 . 2366) nil ("
// output operators
ostream& operator<<(ostream& os, const Student& rhs) {
  os << \"Name: \" << rhs.name << endl;
  os << \"Courses: \";
  size_t len = rhs.courses.size();
  for (size_t i = 0; i < len; i++) {
    os << rhs.courses[i]->getName() << \" \";
  }
  os << endl;
  return os;
}

" . 2081) 2365 nil (1 . 102) nil ("#include \"registrar.h\"
#include <iostream>
#include <string>
#include <vector>

using namespace std;
" . 1) 101 nil ("// student methods
Student::Student(const string& thename) : name(thename) {
}

const string& Student::getName() const {
  return name;
}

bool Student::addCourse(Course* cou) {
  bool okay = true;
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i] == cou) {
      okay = false;
      break;
    }
  }
  if (okay) {
    courses.push_back(cou);
  }
  return okay;
}

void Student::removedFromCourse(Course* cou) {
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i] == cou) {
      courses.erase(courses.begin() + i);
      break;
    }
  }
}
" . 102) 714 nil ("
ostream& operator<<(ostream& os, const Course& rhs) {
  os << \"Name: \" << rhs.name << endl;
  os << \"Students: \";
  size_t len = (rhs.students).size();
  for (size_t i = 0; i < len; i++) {
    os << rhs.students[i]->getName() << \" \";
  }
  os << endl;
  return os;
}

" . 2715) 2983 nil (1 . 103) nil ("#include \"registrar.h\"
#include <iostream>
#include <string>
#include <vector>

using namespace std;
/" . 1) 102 nil ("
// course methods
Course::Course(const string& courseName) : name(courseName){}

const string& Course::getName() const {
  return name;
}

bool Course::addStudent(Student* stu) {
  bool okay = true;
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    if (students[i] == stu) {
      okay = false;
      break;
    }
  }
  if (okay) {
    students.push_back(stu);
  }
  return okay;
}

void Course::removeStudentsFromCourse() {
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    students[i]->removedFromCourse(this);
  }
  students.clear();
}

" . 715) 1301 (t 24672 53072 524545 6000) nil ("std::" . -4166) (4171 . 4171) nil ("std::" . -4028) (4033 . 4033) nil ("std::" . -3855) (3860 . 3860) nil ("std::" . -3835) (3840 . 3840) nil ("std::" . -3813) (3818 . 3818) nil ("std::" . -3658) (3663 . 3663) nil ("std::" . -3591) (3596 . 3596) nil ("std::" . -3571) (3576 . 3576) nil ("std::" . -3549) (3554 . 3554) nil ("std::" . -3389) (3394 . 3394) nil ("std::" . -3323) (3328 . 3328) nil ("std::" . -3303) (3308 . 3308) nil ("std::" . -2799) (2804 . 2804) nil ("std::" . -2389) (2394 . 2394) nil ("std::" . -2352) (2357 . 2357) nil ("std::" . -2083) (2088 . 2088) nil ("std::" . -1829) (1834 . 1834) nil ("std::" . -1611) (1616 . 1616) nil ("std::" . -1386) (1391 . 1391) nil ("std::" . -803) (808 . 808) nil ("std::" . -755) (760 . 760) nil ("std::" . -188) (193 . 193) nil ("std::" . -144) (149 . 149) nil (100 . 101) nil (81 . 100) nil ("  " . -82) (80 . 81) (t 24672 52924 97873 671000) 80 nil ("
" . 4283) nil ("}" . 4283) nil ("  " . 4281) (4268 . 4270) ("    " . 4268) (4249 . 4251) ("    " . 4249) (4245 . 4247) ("    " . 4245) (4215 . 4219) ("      " . 4215) (4178 . 4180) ("    " . 4178) (4147 . 4149) ("    " . 4147) (4125 . 4127) ("    " . 4125) (4106 . 4108) ("    " . 4106) (4102 . 4104) ("    " . 4102) (4073 . 4077) ("      " . 4073) (4036 . 4038) ("    " . 4036) (4015 . 4017) ("    " . 4015) (3978 . 3980) ("    " . 3978) ("  " . -3911) ("  " . 3908) (3895 . 3897) ("    " . 3895) (3876 . 3878) ("    " . 3876) (3872 . 3874) ("    " . 3872) (3828 . 3832) ("      " . 3828) (3791 . 3793) ("    " . 3791) (3756 . 3758) ("    " . 3756) (3735 . 3737) ("    " . 3735) (3692 . 3694) ("    " . 3692) ("  " . -3627) ("  " . 3624) (3611 . 3613) ("    " . 3611) (3592 . 3594) ("    " . 3592) (3588 . 3590) ("    " . 3588) (3543 . 3547) ("      " . 3543) (3506 . 3508) ("    " . 3506) (3468 . 3470) ("    " . 3468) (3446 . 3448) ("    " . 3446) (3403 . 3405) ("    " . 3403) ("  " . -3339) ("  " . 3318) ("  " . 3314) (3294 . 3296) ("    " . 3294) (3275 . 3277) ("    " . 3275) (3271 . 3273) ("    " . 3271) (3247 . 3251) ("      " . 3247) (3210 . 3212) ("    " . 3210) (3185 . 3187) ("    " . 3185) (3181 . 3183) ("    " . 3181) (3158 . 3162) ("      " . 3158) (3121 . 3123) ("    " . 3121) (3090 . 3092) ("    " . 3090) ("  " . -3064) ("  " . 3061) (3046 . 3048) ("    " . 3046) (3008 . 3010) ("    " . 3008) (2987 . 2989) ("    " . 2987) (2945 . 2947) ("    " . 2945) (2941 . 2943) ("    " . 2941) (2923 . 2927) ("      " . 2923) (2894 . 2896) ("    " . 2894) (2857 . 2859) ("    " . 2857) ("  " . -2795) ("  " . 2792) (2775 . 2777) ("    " . 2775) (2727 . 2731) ("      " . 2727) (2679 . 2681) ("    " . 2679) (2627 . 2631) ("      " . 2627) (2582 . 2584) ("    " . 2582) (2578 . 2580) ("    " . 2578) (2560 . 2564) ("      " . 2560) (2510 . 2516) ("	" . 2510) (2457 . 2459) ("    " . 2457) (2442 . 2444) ("    " . 2442) (2399 . 2409) ("					" . 2399) ("  " . -2329) ("  " . 2326) (2311 . 2313) ("    " . 2311) (2267 . 2269) ("    " . 2267) (2263 . 2265) ("    " . 2263) (2257 . 2261) ("      " . 2257) (2237 . 2243) ("	" . 2237) (2192 . 2196) ("      " . 2192) (2155 . 2157) ("    " . 2155) (2123 . 2125) ("    " . 2123) ("  " . -2066) ("  " . 2063) (2048 . 2050) ("    " . 2048) (2006 . 2008) ("    " . 2006) (2002 . 2004) ("    " . 2002) (1996 . 2000) ("      " . 1996) (1976 . 1982) ("	" . 1976) (1932 . 1936) ("      " . 1932) (1895 . 1897) ("    " . 1895) (1864 . 1866) ("    " . 1864) ("  " . -1808) ("  " . 1805) (1791 . 1793) ("    " . 1791) (1787 . 1789) ("    " . 1787) (1781 . 1785) ("      " . 1781) (1765 . 1771) ("	" . 1765) (1718 . 1722) ("      " . 1718) (1681 . 1683) ("    " . 1681) (1650 . 1652) ("    " . 1650) ("  " . -1582) ("  " . 1579) (1565 . 1567) ("    " . 1565) (1561 . 1563) ("    " . 1561) (1555 . 1559) ("      " . 1555) (1539 . 1545) ("	" . 1539) (1490 . 1494) ("      " . 1490) (1453 . 1455) ("    " . 1453) (1421 . 1423) ("    " . 1421) ("  " . -1351) ("  " . -1324) ("  " . 1303) ("  " . 1300) (1280 . 1282) ("      " . 1280) (1276 . 1278) ("      " . 1276) (1234 . 1238) ("      " . 1234) (1197 . 1199) ("    " . 1197) (1165 . 1167) ("    " . 1165) ("  " . -1123) ("  " . 1120) (1105 . 1107) ("    " . 1105) (1101 . 1103) ("    " . 1101) (1072 . 1076) ("      " . 1072) (1058 . 1060) ("    " . 1058) (1054 . 1056) ("    " . 1054) (1048 . 1052) ("      " . 1048) (1035 . 1041) ("	" . 1035) (1015 . 1021) ("	" . 1015) (985 . 989) ("      " . 985) (948 . 950) ("    " . 948) (916 . 918) ("    " . 916) (896 . 898) ("    " . 896) ("  " . -856) ("  " . 853) (838 . 840) ("    " . 838) ("  " . -793) ("  " . -725) ("  " . 707) ("  " . 704) (700 . 702) ("    " . 700) (694 . 698) ("      " . 694) (681 . 687) ("	" . 681) (639 . 645) ("	" . 639) (610 . 614) ("      " . 610) (573 . 575) ("    " . 573) (542 . 544) ("    " . 542) ("  " . -495) ("  " . 492) (477 . 479) ("    " . 477) (473 . 475) ("    " . 473) (445 . 449) ("      " . 445) (431 . 433) ("    " . 431) (427 . 429) ("    " . 427) (421 . 425) ("      " . 421) (408 . 414) ("	" . 408) (388 . 394) ("	" . 388) (359 . 363) ("      " . 359) (322 . 324) ("    " . 322) (291 . 293) ("    " . 291) (271 . 273) ("    " . 271) ("  " . -232) ("  " . 229) (214 . 216) ("    " . 214) ("  " . -168) ("  " . 165) ("  " . -102) ("namespace BrooklynPoly {
" . 81) 87 (t 24672 52707 629643 337000) nil ("endl" . -4528) (4532 . 4541) nil ("endl" . -4373) (4377 . 4386) nil ("endl" . -4125) (4129 . 4138) nil ("endl" . -3953) (3957 . 3966) nil ("endl" . -3821) (3825 . 3834) nil ("endl" . -3644) (t 24672 52676 916749 869000) (3648 . 3657) (t 24672 52676 916749 869000) nil (4 . 6) nil ("l" . -4) ("c" . -5) 6 (t 24672 52654 650730 781000) nil ("
" . 23) nil (23 . 24) (t 24672 52654 650730 781000) 6 nil (1317 . 1323) ("	" . -1317) (1278 . 1282) ("      " . 1278) (1366 . 1372) ("    " . -1366) ("    xu
" . 1278) 1283 nil (1283 . 1284) (1364 . 1370) ("    " . 1364) (1325 . 1326) ("      " . 1325) (1284 . 1290) ("    " . -1284) (1282 . 1283) nil (1277 . 1282) 1244 nil ("
" . 24) (t 24672 52538 967851 471000) nil ("using namespace std;
" . 82) (t 24672 52441 35521 3000) nil (4547 . 4548) 4474 nil (4546 . 4547) ("}" . -4546) (4546 . 4547) nil (2196 . 2200) ("  " . 2196) (2152 . 2156) ("  " . 2152) (2146 . 2150) ("  " . 2146) (2138 . 2144) ("    " . 2138) (2123 . 2124) ("      " . 2123) (2077 . 2083) ("    " . 2077) (2038 . 2042) ("  " . 2038) (2005 . 2009) ("  " . 2005) (1947 . 1949) (1942 . 1944) (1926 . 1930) ("  " . 1926) (1920 . 1924) ("  " . 1920) (1912 . 1918) ("    " . 1912) (1901 . 1902) ("      " . 1901) (1852 . 1858) ("    " . 1852) (1813 . 1817) ("  " . 1813) (1780 . 1784) ("  " . 1780) (1710 . 1712) (1705 . 1707) (1689 . 1693) ("  " . 1689) (1683 . 1687) ("  " . 1683) (1675 . 1681) ("    " . 1675) (1664 . 1665) ("      " . 1664) (1613 . 1619) ("    " . 1613) (1574 . 1578) ("  " . 1574) (1540 . 1544) ("  " . 1540) (1468 . 1470) (1439 . 1441) (1416 . 1418) (1411 . 1413) (1389 . 1393) ("  " . 1389) (1383 . 1387) ("  " . 1383) (1339 . 1345) ("    " . 1339) (1300 . 1304) ("  " . 1300) (1266 . 1270) ("  " . 1266) (1222 . 1224) (1217 . 1219) (1200 . 1204) ("  " . 1200) (1194 . 1198) ("  " . 1194) (1163 . 1169) ("    " . 1163) (1147 . 1151) ("  " . 1147) (1141 . 1145) ("  " . 1141) (1133 . 1139) ("    " . 1133) (1125 . 1126) ("      " . 1125) (1110 . 1111) ("      " . 1110) (1078 . 1084) ("    " . 1078) (1039 . 1043) ("  " . 1039) (1005 . 1009) ("  " . 1005) (983 . 987) ("  " . 983) (941 . 943) (936 . 938) (919 . 923) ("  " . 919) (872 . 874) (802 . 804) (782 . 784) (777 . 779) (771 . 775) ("  " . 771) (763 . 769) ("    " . 763) (755 . 756) ("      " . 755) (718 . 719) ("      " . 718) (687 . 693) ("    " . 687) (648 . 652) ("  " . 648) (615 . 619) ("  " . 615) (566 . 568) (561 . 563) (544 . 548) ("  " . 544) (538 . 542) ("  " . 538) (508 . 514) ("    " . 508) (492 . 496) ("  " . 492) (486 . 490) ("  " . 486) (478 . 484) ("    " . 478) (470 . 471) ("      " . 470) (455 . 456) ("      " . 455) (424 . 430) ("    " . 424) (385 . 389) ("  " . 385) (352 . 356) ("  " . 352) (330 . 334) ("  " . 330) (289 . 291) (284 . 286) (267 . 271) ("  " . 267) (219 . 221) (214 . 216) (149 . 151) (128 . 130) ("}" . 127) nil (126 . 128) nil (108 . 126) nil ("p" . -108) ("c" . -109) ("a" . -110) 111 nil (103 . 111) nil (102 . 103) (t 24672 52271 757393 111000) 101 nil (13 . 22) nil ("i" . -13) ("g" . -14) ("s" . -15) ("t" . -16) ("r" . -17) 18 nil (11 . 18) (11 . 12) (nil syntax-table nil 11 . 12) (nil syntax-table (1) 10 . 11) (10 . 11) ("\"" . -10) (nil syntax-table nil 11 . 12) (nil syntax-table (1) 10 . 11) (2 . 11) nil (1 . 2) nil (1 . 3) nil (77 . 78) nil (64 . 77) nil ("a" . -64) ("n" . -65) 66 nil (58 . 66) nil (57 . 58) 57 nil ("using namespace std;
" . 58) 78 nil (77 . 78) nil (59 . 77) ("  " . -60) (58 . 59) (t 24672 52179 121132 197000) nil ("
" . 4374) 4333 nil ("}" . 4374) nil (2026 . 2028) ("    " . 2026) (1984 . 1986) ("    " . 1984) (1980 . 1982) ("    " . 1980) (1974 . 1978) ("      " . 1974) (1954 . 1960) ("	" . 1954) (1910 . 1914) ("      " . 1910) (1873 . 1875) ("    " . 1873) (1842 . 1844) ("    " . 1842) ("  " . -1786) ("  " . 1783) (1769 . 1771) ("    " . 1769) (1765 . 1767) ("    " . 1765) (1759 . 1763) ("      " . 1759) (1743 . 1749) ("	" . 1743) (1696 . 1700) ("      " . 1696) (1659 . 1661) ("    " . 1659) (1628 . 1630) ("    " . 1628) ("  " . -1560) ("  " . 1557) (1543 . 1545) ("    " . 1543) (1539 . 1541) ("    " . 1539) (1533 . 1537) ("      " . 1533) (1517 . 1523) ("	" . 1517) (1468 . 1472) ("      " . 1468) (1431 . 1433) ("    " . 1431) (1399 . 1401) ("    " . 1399) ("  " . -1329) ("  " . -1302) ("  " . 1281) ("  " . 1278) (1258 . 1260) ("    " . 1258) (1254 . 1256) ("    " . 1254) (1212 . 1216) ("      " . 1212) (1175 . 1177) ("    " . 1175) (1143 . 1145) ("    " . 1143) ("  " . -1101) ("  " . 1098) (1083 . 1085) ("    " . 1083) (1079 . 1081) ("    " . 1079) (1050 . 1054) ("      " . 1050) (1036 . 1038) ("    " . 1036) (1032 . 1034) ("    " . 1032) (1026 . 1030) ("      " . 1026) (1013 . 1019) ("	" . 1013) (993 . 999) ("	" . 993) (963 . 967) ("      " . 963) (926 . 928) ("    " . 926) (894 . 896) ("    " . 894) (874 . 876) ("    " . 874) ("  " . -834) ("  " . 831) (816 . 818) ("    " . 816) ("  " . -771) ("  " . -703) ("  " . 685) ("  " . 682) (678 . 680) ("    " . 678) (672 . 676) ("      " . 672) (659 . 665) ("	" . 659) (617 . 623) ("	" . 617) (588 . 592) ("      " . 588) (551 . 553) ("    " . 551) (520 . 522) ("    " . 520) ("  " . -473) ("  " . 470) (455 . 457) ("    " . 455) (451 . 453) ("    " . 451) (423 . 427) ("      " . 423) (409 . 411) ("    " . 409) (405 . 407) ("    " . 405) (399 . 403) ("      " . 399) (386 . 392) ("	" . 386) (366 . 372) ("	" . 366) (337 . 341) ("      " . 337) (300 . 302) ("    " . 300) (269 . 271) ("    " . 269) (249 . 251) ("    " . 249) ("  " . -210) ("  " . 207) (192 . 194) ("    " . 192) ("  " . -146) ("  " . 143) ("  " . -80) ("namespace BrooklynPoly {
" . 59) (t 24670 7793 559070 607000) nil (4503 . 4504) nil (4502 . 4503) ("}" . -4502) (4502 . 4503) nil (4498 . 4500) (4483 . 4487) ("  " . 4483) (4467 . 4471) ("  " . 4467) (4461 . 4465) ("  " . 4461) (4429 . 4435) ("    " . 4429) (4390 . 4394) ("  " . 4390) (4357 . 4361) ("  " . 4357) (4333 . 4337) ("  " . 4333) (4317 . 4321) ("  " . 4317) (4311 . 4315) ("  " . 4311) (4280 . 4286) ("    " . 4280) (4241 . 4245) ("  " . 4241) (4218 . 4222) ("  " . 4218) (4179 . 4183) ("  " . 4179) (4110 . 4112) (4105 . 4107) (4090 . 4094) ("  " . 4090) (4074 . 4078) ("  " . 4074) (4068 . 4072) ("  " . 4068) (4022 . 4028) ("    " . 4022) (3983 . 3987) ("  " . 3983) (3946 . 3950) ("  " . 3946) (3923 . 3927) ("  " . 3923) (3883 . 3887) ("  " . 3883) (3816 . 3818) (3811 . 3813) (3796 . 3800) ("  " . 3796) (3780 . 3784) ("  " . 3780) (3774 . 3778) ("  " . 3774) (3727 . 3733) ("    " . 3727) (3688 . 3692) ("  " . 3688) (3648 . 3652) ("  " . 3648) (3624 . 3628) ("  " . 3624) (3584 . 3588) ("  " . 3584) (3518 . 3520) (3495 . 3497) (3489 . 3491) (3467 . 3471) ("  " . 3467) (3446 . 3450) ("  " . 3446) (3440 . 3444) ("  " . 3440) (3414 . 3420) ("    " . 3414) (3375 . 3379) ("  " . 3375) (3348 . 3352) ("  " . 3348) (3342 . 3346) ("  " . 3342) (3317 . 3323) ("    " . 3317) (3278 . 3282) ("  " . 3278) (3245 . 3249) ("  " . 3245) (3217 . 3219) (3212 . 3214) (3195 . 3199) ("  " . 3195) (3155 . 3159) ("  " . 3155) (3132 . 3136) ("  " . 3132) (3088 . 3092) ("  " . 3088) (3082 . 3086) ("  " . 3082) (3062 . 3068) ("    " . 3062) (3031 . 3035) ("  " . 3031) (2992 . 2996) ("  " . 2992) (2928 . 2930) (2923 . 2925) (2904 . 2908) ("  " . 2904) (2854 . 2860) ("    " . 2854) (2804 . 2808) ("  " . 2804) (2750 . 2756) ("    " . 2750) (2703 . 2707) ("  " . 2703) (2697 . 2701) ("  " . 2697) (2677 . 2683) ("    " . 2677) (2632 . 2633) ("      " . 2632) (2577 . 2581) ("  " . 2577) (2560 . 2564) ("  " . 2560) (2522 . 2527) ("				      " . 2522) (2450 . 2452) (2445 . 2447) (2428 . 2432) ("  " . 2428) (2382 . 2386) ("  " . 2382) (2376 . 2380) ("  " . 2376) (2368 . 2374) ("    " . 2368) (2353 . 2354) ("      " . 2353) (2306 . 2312) ("    " . 2306) (2267 . 2271) ("  " . 2267) (2233 . 2237) ("  " . 2233) (2174 . 2176) (2169 . 2171) (2152 . 2156) ("  " . 2152) (2108 . 2112) ("  " . 2108) (2102 . 2106) ("  " . 2102) (2094 . 2100) ("    " . 2094) (2079 . 2080) ("      " . 2079) (2033 . 2039) ("    " . 2033) (1994 . 1998) ("  " . 1994) (1961 . 1965) ("  " . 1961) (1903 . 1905) (1898 . 1900) (1882 . 1886) ("  " . 1882) (1876 . 1880) ("  " . 1876) (1868 . 1874) ("    " . 1868) (1857 . 1858) ("      " . 1857) (1808 . 1814) ("    " . 1808) (1769 . 1773) ("  " . 1769) (1736 . 1740) ("  " . 1736) (1666 . 1668) (1661 . 1663) (1645 . 1649) ("  " . 1645) (1639 . 1643) ("  " . 1639) (1631 . 1637) ("    " . 1631) (1620 . 1621) ("      " . 1620) (1569 . 1575) ("    " . 1569) (1530 . 1534) ("  " . 1530) (1496 . 1500) ("  " . 1496) (1424 . 1426) (1395 . 1397) (1372 . 1374) (1367 . 1369) (1345 . 1349) ("  " . 1345) (1339 . 1343) ("  " . 1339) (1295 . 1301) ("    " . 1295) (1256 . 1260) ("  " . 1256) (1222 . 1226) ("  " . 1222) (1178 . 1180) (1173 . 1175) (1156 . 1160) ("  " . 1156) (1150 . 1154) ("  " . 1150) (1119 . 1125) ("    " . 1119) (1103 . 1107) ("  " . 1103) (1097 . 1101) ("  " . 1097) (1089 . 1095) ("    " . 1089) (1081 . 1082) ("      " . 1081) (1066 . 1067) ("      " . 1066) (1034 . 1040) ("    " . 1034) (995 . 999) ("  " . 995) (961 . 965) ("  " . 961) (939 . 943) ("  " . 939) (897 . 899) (892 . 894) (875 . 879) ("  " . 875) (828 . 830) (758 . 760) (738 . 740) (733 . 735) (727 . 731) ("  " . 727) (719 . 725) ("    " . 719) (711 . 712) ("      " . 711) (674 . 675) ("      " . 674) (643 . 649) ("    " . 643) (604 . 608) ("  " . 604) (571 . 575) ("  " . 571) (522 . 524) (517 . 519) (500 . 504) ("  " . 500) (494 . 498) ("  " . 494) (464 . 470) ("    " . 464) (448 . 452) ("  " . 448) (442 . 446) ("  " . 442) (434 . 440) ("    " . 434) (426 . 427) ("      " . 426) (411 . 412) ("      " . 411) (380 . 386) ("    " . 380) (341 . 345) ("  " . 341) (308 . 312) ("  " . 308) (286 . 290) ("  " . 286) (245 . 247) (240 . 242) (223 . 227) ("  " . 223) (175 . 177) (170 . 172) (105 . 107) (84 . 86) ("}" . 83) nil (82 . 84) nil (77 . 82) nil (" " . -77) 78 nil (70 . 78) nil ("o" . -70) 71 nil (69 . 71) nil (63 . 69) nil ("p" . -63) 64 nil (59 . 64) nil ("using namespace BrooklynPoly;
" . 58) 83 (t 24670 7651 135610 684000) nil (nil fontified t 3928 . 3935) (nil face font-lock-type-face 3928 . 3935) (nil fontified t 3923 . 3928) ("ostream" . -3923) (3930 . 3942) nil (nil fontified t 3909 . 3910) (nil c-type c-decl-id-start 3909 . 3910) (nil face font-lock-type-face 3909 . 3910) (nil fontified t 3903 . 3909) (nil face font-lock-type-face 3903 . 3909) ("ostream" . -3898) (3905 . 3917) nil (nil fontified t 3654 . 3661) (nil face font-lock-type-face 3654 . 3661) (nil fontified t 3649 . 3654) ("ostream" . -3649) (3656 . 3668) nil (nil fontified t 3635 . 3636) (nil c-type c-decl-id-start 3635 . 3636) (nil face font-lock-type-face 3635 . 3636) (nil fontified t 3629 . 3635) (nil face font-lock-type-face 3629 . 3635) ("ostream" . -3624) (3631 . 3643) nil (nil fontified t 3376 . 3383) (nil face font-lock-type-face 3376 . 3383) (nil fontified t 3371 . 3376) ("ostream" . -3371) (3378 . 3390) nil (nil fontified t 3357 . 3358) (nil c-type c-decl-id-start 3357 . 3358) (nil face font-lock-type-face 3357 . 3358) (nil fontified t 3352 . 3357) (nil face font-lock-type-face 3352 . 3357) (nil c-is-sws t 3351 . 3352) (nil fontified t 3351 . 3352) (nil face font-lock-type-face 3351 . 3352) ("ostream" . -3346) (3353 . 3365) nil (nil fontified t 2846 . 2848) (nil face font-lock-type-face 2846 . 2848) (nil fontified t 2842 . 2846) (nil face font-lock-type-face 2842 . 2846) ("string" . -2837) (2843 . 2854) nil (nil fontified t 2427 . 2433) (nil face font-lock-type-face 2427 . 2433) ("string" . -2422) (2428 . 2439) nil (nil fontified t 2385 . 2391) (nil face font-lock-type-face 2385 . 2391) ("string" . -2380) (2386 . 2397) nil (nil fontified t 2111 . 2117) (nil face font-lock-type-face 2111 . 2117) ("string" . -2106) (2112 . 2123) nil (nil face font-lock-type-face 1852 . 1858) (nil fontified t 1852 . 1858) ("string" . -1847) (1853 . 1864) nil (nil fontified t 1629 . 1635) (nil face font-lock-type-face 1629 . 1635) ("string" . -1624) (1630 . 1641) nil (nil fontified t 1399 . 1405) (nil face font-lock-type-face 1399 . 1405) ("string" . -1394) (1400 . 1411) nil (nil fontified t 816 . 817) (nil c-type c-decl-id-start 816 . 817) (nil face font-lock-type-face 816 . 817) (nil fontified t 811 . 816) (nil face font-lock-type-face 811 . 816) ("string" . -806) (812 . 823) nil (nil fontified t 758 . 764) (nil face font-lock-type-face 758 . 764) ("string" . -753) (759 . 770) nil (nil fontified t 191 . 192) (nil c-type c-decl-id-start 191 . 192) (nil face font-lock-type-face 191 . 192) (nil fontified t 186 . 191) (nil face font-lock-type-face 186 . 191) ("string" . -181) (187 . 198) nil (nil fontified t 137 . 143) (nil face font-lock-type-face 137 . 143) ("string" . -132) (138 . 149) nil ("using namespace std;
" . 88) (t 24670 7485 522101 356000) nil ("
" . 57) nil ("
" . 57) nil (nil rear-nonsticky nil 56 . 57) (nil fontified nil 40 . 57) (nil fontified nil 39 . 40) (nil fontified nil 22 . 39) (nil fontified nil 21 . 22) (nil fontified nil 2 . 21) (nil fontified nil 1 . 2) (1 . 57) nil (1 . 4) nil ("
" . 30) nil (30 . 31) 1 nil (51 . 52) nil (50 . 51) nil (48 . 50) nil ("d" . -48) 49 nil (48 . 49) nil ("d" . -48) ("d" . -49) (";" . -50) 51 nil (50 . 51) nil (31 . 50) nil (30 . 31) (t 24670 7324 615208 835000) 1 nil (30 . 31) 30 nil (29 . 30) nil (28 . 29) nil (";" . -28) 29 nil (28 . 29) nil (20 . 28) nil (12 . 20) nil ("a" . -12) 13 nil (1 . 13) nil ("s" . -1) ("u" . -2) 3 nil (1 . 3) (t 24670 6988 817636 3000) nil (2496 . 2500) ("      " . 2496) (2447 . 2449) ("	" . 2447) 1 nil (nil rear-nonsticky nil 4087 . 4088) (nil fontified nil 1 . 4088) (1 . 4088) nil ("
// student methods
Student::Student(const string& thename) : name(thename) {
}

const string& Student::getName() const {
  return name;
}

bool Student::addCourse(Course* cou) {
  bool okay = true;
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i] == cou) {
      okay = false;
    }
  }
  if (okay) {
    courses.push_back(cou);
  }
  return okay;
}

void Student::removedFromCourse(Course* cou) {
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i] == cou) {
      courses.erase(courses.begin() + i);
      break;
    }
  }
}

// course methods
Course::Course(const string& courseName) : name(courseName){}

const string& Course::getName() const {
  return name;
}

bool Course::addStudent(Student* stu) {
  bool okay = true;
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    if (students[i] == stu) {
      okay = false;
    }
  }
  if (okay) {
    students.push_back(stu);
  }
  return okay;
}

void Course::removeStudentsFromCourse() {
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    students[i]->removedFromCourse(this);
  }
  students.clear();
}

// registrar methods
Registrar::Registrar() {}

size_t Registrar::findStudent(const string& studentName) const {
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    if (students[i]->getName() == studentName) {
      return i;
    }
  }
  return 0;
}

size_t Registrar::findCourse(const string& courseName) const {
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i]->getName() == courseName) {
      return i;
    }
  }
  return 0;
}

bool Registrar::addCourse(const string& couname) {
  courses.push_back(new Course(couname));
  return true;
}

bool Registrar::addStudent(const string& stuname) {
  students.push_back(new Student(stuname));
  return true;
}

bool Registrar::enrollStudentInCourse(const string& studentName,
				      const string& courseName) {
  courses[findCourse(courseName)]->
    addStudent(students[findStudent(studentName)]);
  students[findStudent(studentName)]->
    addCourse(courses[findCourse(courseName)]);
  return true;
}

bool Registrar::cancelCourse(const string& courseName) {
  size_t i = findCourse(courseName);
  courses[i]->removeStudentsFromCourse();
  delete courses[i];
  courses.erase(courses.begin() + i);
  return true;
}

void Registrar::purge() {
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    delete courses[i];
  }
  len = students.size();
  for (size_t i = 0; i < len; i++) {
    delete students[i];
  }
  courses.clear();
  students.clear();
}


// output operators

ostream& operator<<(ostream& os, const Course& rhs) {
  os << \"Name: \" << rhs.name << endl;
  os << \"Students: \";
  size_t len = (rhs.students).size();
  for (size_t i = 0; i < len; i++) {
    os << rhs.students[i]->getName() << \" \";
  }
  os << endl;
  return os;
}

ostream& operator<<(ostream& os, const Student& rhs) {
  os << \"Name: \" << rhs.name << endl;
  os << \"Courses: \";
  size_t len = rhs.courses.size();
  for (size_t i = 0; i < len; i++) {
    os << rhs.courses[i]->getName() << \" \";
  }
  os << endl;
  return os;
}

ostream& operator<<(ostream& os, const Registrar& rhs) {
  size_t len = (rhs.courses).size();
  os << \"Courses: \";
  for (size_t i = 0; i < len; i++) {
    os << *(rhs.courses[i]);
  }
  os << endl;
  os << \"Students: \";
  len = (rhs.students).size();
  for (size_t i = 0; i < len; i++) {
    os << *(rhs.students[i]);
  }
  os << endl;
  return os;
}
" . 1) 3560 (t 24670 5424 560277 758000) nil (2170 . 2172) (2031 . 2035) ("      " . 2031) (1995 . 1997) ("    " . 1995) 1 nil (nil rear-nonsticky nil 3561 . 3562) (nil fontified nil 1 . 3562) (1 . 3562) (t . -1)) (emacs-pending-undo-list (1 . 102) nil ("#include \"registrar.h\"
#include <iostream>
#include <string>
#include <vector>

using namespace std;
" . 1) ((marker . 62) . -61) ((marker . 79) . -78) ((marker . 996) . -100) ((marker* . 101) . 1) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 2143) . -100) ((marker . 4) . -3) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 43) . -42) ((marker . 80) . -79) ((marker . 80) . -79) ((marker . 102) . -101) ((marker . 80) . -79) ((marker . 80) . -79) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 996) . -80) ((marker . 996) . -100) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 102) . -101) ((marker . 996) . -80) ((marker . 1033) . -101) ((marker) . -100) 101 nil ("// student methods
Student::Student(const string& thename) : name(thename) {
}

const string& Student::getName() const {
  return name;
}

bool Student::addCourse(Course* cou) {
  bool okay = true;
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i] == cou) {
      okay = false;
      break;
    }
  }
  if (okay) {
    courses.push_back(cou);
  }
  return okay;
}

void Student::removedFromCourse(Course* cou) {
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i] == cou) {
      courses.erase(courses.begin() + i);
      break;
    }
  }
}
" . 102) ((marker . 996) . -612) ((marker . 102) . -178) ((marker . 2143) . -612) ((marker . 102) . -124) ((marker . 102) . -19) ((marker . 102) . -9) ((marker . 102) . -19) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 102) . -613) ((marker . 996) . -612) ((marker . 996) . -611) ((marker . 1033) . -613) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker . 102) . -18) ((marker) . -613) ((marker) . -612) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -19) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -77) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -79) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -80) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -121) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -136) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -138) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -139) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -178) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -198) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -229) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -266) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -295) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -315) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -328) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -334) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -338) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -352) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -380) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -384) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -399) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -401) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -402) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -449) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -480) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -517) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -546) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -588) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -601) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -607) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker . 102) . -611) ((marker) . -611) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker . 102) . -612) ((marker) . -612) 714 nil ("
ostream& operator<<(ostream& os, const Course& rhs) {
  os << \"Name: \" << rhs.name << endl;
  os << \"Students: \";
  size_t len = (rhs.students).size();
  for (size_t i = 0; i < len; i++) {
    os << rhs.students[i]->getName() << \" \";
  }
  os << endl;
  return os;
}

" . 2715) ((marker . 996) . -268) ((marker . 2143) . -93) ((marker . 2143) . -268) ((marker . 2143) . -1) ((marker . 996) . -239) ((marker . 996) . -268) ((marker . 996) . -268) ((marker . 1033) . -269) ((marker) . -268) 2983 nil (1 . 103) nil ("#include \"registrar.h\"
#include <iostream>
#include <string>
#include <vector>

using namespace std;
/" . 1) ((marker . 79) . -22) ((marker . 996) . -101) ((marker* . 101) . 2) ((marker . 102) . -101) ((marker . 2143) . -101) ((marker . 4) . -3) ((marker . 102) . -101) ((marker . 43) . -42) ((marker . 80) . -79) ((marker . 80) . -79) ((marker . 80) . -79) ((marker . 80) . -79) ((marker . 996) . -101) ((marker . 996) . -101) ((marker) . -101) 102 nil ("
// course methods
Course::Course(const string& courseName) : name(courseName){}

const string& Course::getName() const {
  return name;
}

bool Course::addStudent(Student* stu) {
  bool okay = true;
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    if (students[i] == stu) {
      okay = false;
      break;
    }
  }
  if (okay) {
    students.push_back(stu);
  }
  return okay;
}

void Course::removeStudentsFromCourse() {
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    students[i]->removedFromCourse(this);
  }
  students.clear();
}

" . 715) ((marker . 996) . -586) ((marker . 2143) . -586) ((marker . 1) . -200) ((marker . 996) . -586) ((marker . 996) . -586) ((marker . 1033) . -587) ((marker) . -587) ((marker) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker . 102) . -584) ((marker) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker . 102) . -586) ((marker) . -586) 1301 (t 24672 53072 524545 6000) nil ("std::" . -4166) (4171 . 4171) nil ("std::" . -4028) (4033 . 4033) nil ("std::" . -3855) (3860 . 3860) nil ("std::" . -3835) (3840 . 3840) nil ("std::" . -3813) (3818 . 3818) nil ("std::" . -3658) (3663 . 3663) nil ("std::" . -3591) (3596 . 3596) nil ("std::" . -3571) (3576 . 3576) nil ("std::" . -3549) (3554 . 3554) nil ("std::" . -3389) (3394 . 3394) nil ("std::" . -3323) (3328 . 3328) nil ("std::" . -3303) (3308 . 3308) nil ("std::" . -2799) (2804 . 2804) nil ("std::" . -2389) (2394 . 2394) nil ("std::" . -2352) (2357 . 2357) nil ("std::" . -2083) (2088 . 2088) nil ("std::" . -1829) (1834 . 1834) nil ("std::" . -1611) (1616 . 1616) nil ("std::" . -1386) (1391 . 1391) nil ("std::" . -803) (808 . 808) nil ("std::" . -755) (760 . 760) nil ("std::" . -188) (193 . 193) nil ("std::" . -144) (149 . 149) nil (100 . 101) nil (81 . 100) nil ("  " . -82) (80 . 81) (t 24672 52924 97873 671000) 80 nil ("
" . 4283) ((marker . 1033) . -1) nil ("}" . 4283) ((marker*) . 1) ((marker) . -1) nil ("  " . 4281) (4268 . 4270) ("    " . 4268) (4249 . 4251) ("    " . 4249) (4245 . 4247) ("    " . 4245) (4215 . 4219) ("      " . 4215) (4178 . 4180) ("    " . 4178) (4147 . 4149) ("    " . 4147) (4125 . 4127) ("    " . 4125) (4106 . 4108) ("    " . 4106) (4102 . 4104) ("    " . 4102) (4073 . 4077) ("      " . 4073) (4036 . 4038) ("    " . 4036) (4015 . 4017) ("    " . 4015) (3978 . 3980) ("    " . 3978) ("  " . -3911) ("  " . 3908) (3895 . 3897) ("    " . 3895) (3876 . 3878) ("    " . 3876) (3872 . 3874) ("    " . 3872) (3828 . 3832) ("      " . 3828) (3791 . 3793) ("    " . 3791) (3756 . 3758) ("    " . 3756) (3735 . 3737) ("    " . 3735) (3692 . 3694) ("    " . 3692) ("  " . -3627) ("  " . 3624) (3611 . 3613) ("    " . 3611) (3592 . 3594) ("    " . 3592) (3588 . 3590) ("    " . 3588) (3543 . 3547) ("      " . 3543) (3506 . 3508) ("    " . 3506) (3468 . 3470) ("    " . 3468) (3446 . 3448) ("    " . 3446) (3403 . 3405) ("    " . 3403) ("  " . -3339) ("  " . 3318) ("  " . 3314) (3294 . 3296) ("    " . 3294) (3275 . 3277) ("    " . 3275) (3271 . 3273) ("    " . 3271) (3247 . 3251) ("      " . 3247) (3210 . 3212) ("    " . 3210) (3185 . 3187) ("    " . 3185) (3181 . 3183) ("    " . 3181) (3158 . 3162) ("      " . 3158) (3121 . 3123) ("    " . 3121) (3090 . 3092) ("    " . 3090) ("  " . -3064) ("  " . 3061) (3046 . 3048) ("    " . 3046) (3008 . 3010) ("    " . 3008) (2987 . 2989) ("    " . 2987) (2945 . 2947) ("    " . 2945) (2941 . 2943) ("    " . 2941) (2923 . 2927) ("      " . 2923) (2894 . 2896) ("    " . 2894) (2857 . 2859) ("    " . 2857) ("  " . -2795) ("  " . 2792) (2775 . 2777) ("    " . 2775) (2727 . 2731) ("      " . 2727) (2679 . 2681) ("    " . 2679) (2627 . 2631) ("      " . 2627) (2582 . 2584) ("    " . 2582) (2578 . 2580) ("    " . 2578) (2560 . 2564) ("      " . 2560) (2510 . 2516) ("	" . 2510) (2457 . 2459) ("    " . 2457) (2442 . 2444) ("    " . 2442) (2399 . 2409) ("					" . 2399) ("  " . -2329) ("  " . 2326) (2311 . 2313) ("    " . 2311) (2267 . 2269) ("    " . 2267) (2263 . 2265) ("    " . 2263) (2257 . 2261) ("      " . 2257) (2237 . 2243) ("	" . 2237) (2192 . 2196) ("      " . 2192) (2155 . 2157) ("    " . 2155) (2123 . 2125) ("    " . 2123) ("  " . -2066) ("  " . 2063) (2048 . 2050) ("    " . 2048) (2006 . 2008) ("    " . 2006) (2002 . 2004) ("    " . 2002) (1996 . 2000) ("      " . 1996) (1976 . 1982) ("	" . 1976) (1932 . 1936) ("      " . 1932) (1895 . 1897) ("    " . 1895) (1864 . 1866) ("    " . 1864) ("  " . -1808) ("  " . 1805) (1791 . 1793) ("    " . 1791) (1787 . 1789) ("    " . 1787) (1781 . 1785) ("      " . 1781) (1765 . 1771) ("	" . 1765) (1718 . 1722) ("      " . 1718) (1681 . 1683) ("    " . 1681) (1650 . 1652) ("    " . 1650) ("  " . -1582) ("  " . 1579) (1565 . 1567) ("    " . 1565) (1561 . 1563) ("    " . 1561) (1555 . 1559) ("      " . 1555) (1539 . 1545) ("	" . 1539) (1490 . 1494) ("      " . 1490) (1453 . 1455) ("    " . 1453) (1421 . 1423) ("    " . 1421) ("  " . -1351) ("  " . -1324) ("  " . 1303) ("  " . 1300) (1280 . 1282) ("      " . 1280) (1276 . 1278) ("      " . 1276) (1234 . 1238) ("      " . 1234) (1197 . 1199) ("    " . 1197) (1165 . 1167) ("    " . 1165) ("  " . -1123) ("  " . 1120) (1105 . 1107) ("    " . 1105) (1101 . 1103) ("    " . 1101) (1072 . 1076) ("      " . 1072) (1058 . 1060) ("    " . 1058) (1054 . 1056) ("    " . 1054) (1048 . 1052) ("      " . 1048) (1035 . 1041) ("	" . 1035) (1015 . 1021) ("	" . 1015) (985 . 989) ("      " . 985) (948 . 950) ("    " . 948) (916 . 918) ("    " . 916) (896 . 898) ("    " . 896) ("  " . -856) ("  " . 853) (838 . 840) ("    " . 838) ("  " . -793) ("  " . -725) ("  " . 707) ("  " . 704) (700 . 702) ("    " . 700) (694 . 698) ("      " . 694) (681 . 687) ("	" . 681) (639 . 645) ("	" . 639) (610 . 614) ("      " . 610) (573 . 575) ("    " . 573) (542 . 544) ("    " . 542) ("  " . -495) ("  " . 492) (477 . 479) ("    " . 477) (473 . 475) ("    " . 473) (445 . 449) ("      " . 445) (431 . 433) ("    " . 431) (427 . 429) ("    " . 427) (421 . 425) ("      " . 421) (408 . 414) ("	" . 408) (388 . 394) ("	" . 388) (359 . 363) ("      " . 359) (322 . 324) ("    " . 322) (291 . 293) ("    " . 291) (271 . 273) ("    " . 271) ("  " . -232) ("  " . 229) (214 . 216) ("    " . 214) ("  " . -168) ("  " . 165) ("  " . -102) ("namespace BrooklynPoly {
" . 81) ((marker . 996) . -24) ((marker . 2143) . -6) ((marker . 2143) . -24) ((marker . 2143) . -6) ((marker . 1033) . -25) 87 (t 24672 52707 629643 337000) nil ("endl" . -4528) (4532 . 4541) nil ("endl" . -4373) (4377 . 4386) nil ("endl" . -4125) (4129 . 4138) nil ("endl" . -3953) (3957 . 3966) nil ("endl" . -3821) (3825 . 3834) nil ("endl" . -3644) (t 24672 52676 916749 869000) (3648 . 3657) (t 24672 52676 916749 869000) nil (4 . 6) nil ("l" . -4) ((marker . 996) . -1) ((marker) . -1) ((marker . 2143) . -1) ((marker . 2143) . -1) ((marker . 2143) . -1) ("c" . -5) ((marker . 996) . -1) ((marker) . -1) ((marker . 2143) . -1) ((marker . 2143) . -1) ((marker . 2143) . -1) 6 (t 24672 52654 650730 781000) nil ("
" . 23) ((marker) . -1) ((marker . 996) . -1) nil (23 . 24) (t 24672 52654 650730 781000) 6 nil (1317 . 1323) ("	" . -1317) (1278 . 1282) ("      " . 1278) ((marker* . 101) . 6) ((marker) . -6) (1366 . 1372) ("    " . -1366) ("    xu
" . 1278) ((marker* . 101) . 1) ((marker) . -5) ((marker) . -5) ((marker . 1033) . -7) 1283 nil (1283 . 1284) (1364 . 1370) ("    " . 1364) (1325 . 1326) ("      " . 1325) (1284 . 1290) ("    " . -1284) (1282 . 1283) nil (1277 . 1282) 1244 nil ("
" . 24) ((marker . 2143) . -1) ((marker . 1033) . -1) (t 24672 52538 967851 471000) nil ("using namespace std;
" . 82) ((marker . 1033) . -21) (t 24672 52441 35521 3000) nil (4547 . 4548) 4474 nil (4546 . 4547) ("}" . -4546) (4546 . 4547) nil (2196 . 2200) ("  " . 2196) (2152 . 2156) ("  " . 2152) (2146 . 2150) ("  " . 2146) (2138 . 2144) ("    " . 2138) (2123 . 2124) ("      " . 2123) (2077 . 2083) ("    " . 2077) (2038 . 2042) ("  " . 2038) (2005 . 2009) ("  " . 2005) (1947 . 1949) (1942 . 1944) (1926 . 1930) ("  " . 1926) (1920 . 1924) ("  " . 1920) (1912 . 1918) ("    " . 1912) (1901 . 1902) ("      " . 1901) (1852 . 1858) ("    " . 1852) (1813 . 1817) ("  " . 1813) (1780 . 1784) ("  " . 1780) (1710 . 1712) (1705 . 1707) (1689 . 1693) ("  " . 1689) (1683 . 1687) ("  " . 1683) (1675 . 1681) ("    " . 1675) (1664 . 1665) ("      " . 1664) (1613 . 1619) ("    " . 1613) (1574 . 1578) ("  " . 1574) (1540 . 1544) ("  " . 1540) (1468 . 1470) (1439 . 1441) (1416 . 1418) (1411 . 1413) (1389 . 1393) ("  " . 1389) (1383 . 1387) ("  " . 1383) (1339 . 1345) ("    " . 1339) (1300 . 1304) ("  " . 1300) (1266 . 1270) ("  " . 1266) (1222 . 1224) (1217 . 1219) (1200 . 1204) ("  " . 1200) (1194 . 1198) ("  " . 1194) (1163 . 1169) ("    " . 1163) (1147 . 1151) ("  " . 1147) (1141 . 1145) ("  " . 1141) (1133 . 1139) ("    " . 1133) (1125 . 1126) ("      " . 1125) (1110 . 1111) ("      " . 1110) (1078 . 1084) ("    " . 1078) (1039 . 1043) ("  " . 1039) (1005 . 1009) ("  " . 1005) (983 . 987) ("  " . 983) (941 . 943) (936 . 938) (919 . 923) ("  " . 919) (872 . 874) (802 . 804) (782 . 784) (777 . 779) (771 . 775) ("  " . 771) (763 . 769) ("    " . 763) (755 . 756) ("      " . 755) (718 . 719) ("      " . 718) (687 . 693) ("    " . 687) (648 . 652) ("  " . 648) (615 . 619) ("  " . 615) (566 . 568) (561 . 563) (544 . 548) ("  " . 544) (538 . 542) ("  " . 538) (508 . 514) ("    " . 508) (492 . 496) ("  " . 492) (486 . 490) ("  " . 486) (478 . 484) ("    " . 478) (470 . 471) ("      " . 470) (455 . 456) ("      " . 455) (424 . 430) ("    " . 424) (385 . 389) ("  " . 385) (352 . 356) ("  " . 352) (330 . 334) ("  " . 330) (289 . 291) (284 . 286) (267 . 271) ("  " . 267) (219 . 221) (214 . 216) (149 . 151) (128 . 130) ("}" . 127) ((marker* . 101) . 1) ((marker*) . 1) ((marker) . -1) nil (126 . 128) nil (108 . 126) nil ("p" . -108) ("c" . -109) ("a" . -110) 111 nil (103 . 111) nil (102 . 103) (t 24672 52271 757393 111000) 101 nil (13 . 22) nil ("i" . -13) ((marker) . -1) ("g" . -14) ((marker) . -1) ("s" . -15) ((marker) . -1) ("t" . -16) ((marker) . -1) ("r" . -17) ((marker) . -1) 18 nil (11 . 18) (11 . 12) (nil syntax-table nil 11 . 12) (nil syntax-table (1) 10 . 11) (10 . 11) ("\"" . -10) (nil syntax-table nil 11 . 12) (nil syntax-table (1) 10 . 11) (2 . 11) nil (1 . 2) nil (1 . 3) nil (77 . 78) nil (64 . 77) nil ("a" . -64) ((marker) . -1) ("n" . -65) ((marker) . -1) 66 nil (58 . 66) nil (57 . 58) 57 nil ("using namespace std;
" . 58) ((marker) . -20) ((marker) . -20) ((marker . 1033) . -21) ((marker* . 101) . 1) 78 nil (77 . 78) nil (59 . 77) ("  " . -60) (58 . 59) (t 24672 52179 121132 197000) nil ("
" . 4374) ((marker) . -1) 4333 nil ("}" . 4374) ((marker*) . 1) ((marker) . -1) nil (2026 . 2028) ("    " . 2026) (1984 . 1986) ("    " . 1984) (1980 . 1982) ("    " . 1980) (1974 . 1978) ("      " . 1974) (1954 . 1960) ("	" . 1954) (1910 . 1914) ("      " . 1910) (1873 . 1875) ("    " . 1873) (1842 . 1844) ("    " . 1842) ("  " . -1786) ("  " . 1783) (1769 . 1771) ("    " . 1769) (1765 . 1767) ("    " . 1765) (1759 . 1763) ("      " . 1759) (1743 . 1749) ("	" . 1743) (1696 . 1700) ("      " . 1696) (1659 . 1661) ("    " . 1659) (1628 . 1630) ("    " . 1628) ("  " . -1560) ("  " . 1557) (1543 . 1545) ("    " . 1543) (1539 . 1541) ("    " . 1539) (1533 . 1537) ("      " . 1533) (1517 . 1523) ("	" . 1517) (1468 . 1472) ("      " . 1468) (1431 . 1433) ("    " . 1431) (1399 . 1401) ("    " . 1399) ("  " . -1329) ("  " . -1302) ("  " . 1281) ("  " . 1278) (1258 . 1260) ("    " . 1258) (1254 . 1256) ("    " . 1254) (1212 . 1216) ("      " . 1212) (1175 . 1177) ("    " . 1175) (1143 . 1145) ("    " . 1143) ("  " . -1101) ("  " . 1098) (1083 . 1085) ("    " . 1083) (1079 . 1081) ("    " . 1079) (1050 . 1054) ("      " . 1050) (1036 . 1038) ("    " . 1036) (1032 . 1034) ("    " . 1032) (1026 . 1030) ("      " . 1026) (1013 . 1019) ("	" . 1013) (993 . 999) ("	" . 993) (963 . 967) ("      " . 963) (926 . 928) ("    " . 926) (894 . 896) ("    " . 894) (874 . 876) ("    " . 874) ("  " . -834) ("  " . 831) (816 . 818) ("    " . 816) ("  " . -771) ("  " . -703) ("  " . 685) ("  " . 682) (678 . 680) ("    " . 678) (672 . 676) ("      " . 672) (659 . 665) ("	" . 659) (617 . 623) ("	" . 617) (588 . 592) ("      " . 588) (551 . 553) ("    " . 551) (520 . 522) ("    " . 520) ("  " . -473) ("  " . 470) (455 . 457) ("    " . 455) (451 . 453) ("    " . 451) (423 . 427) ("      " . 423) (409 . 411) ("    " . 409) (405 . 407) ("    " . 405) (399 . 403) ("      " . 399) (386 . 392) ("	" . 386) (366 . 372) ("	" . 366) (337 . 341) ("      " . 337) (300 . 302) ("    " . 300) (269 . 271) ("    " . 269) (249 . 251) ("    " . 249) ("  " . -210) ("  " . 207) (192 . 194) ("    " . 192) ("  " . -146) ("  " . 143) ("  " . -80) ("namespace BrooklynPoly {
" . 59) ((marker . 1033) . -25) (t 24670 7793 559070 607000) nil (4503 . 4504) nil (4502 . 4503) ("}" . -4502) (4502 . 4503) nil (4498 . 4500) (4483 . 4487) ("  " . 4483) (4467 . 4471) ("  " . 4467) (4461 . 4465) ("  " . 4461) (4429 . 4435) ("    " . 4429) (4390 . 4394) ("  " . 4390) (4357 . 4361) ("  " . 4357) (4333 . 4337) ("  " . 4333) (4317 . 4321) ("  " . 4317) (4311 . 4315) ("  " . 4311) (4280 . 4286) ("    " . 4280) (4241 . 4245) ("  " . 4241) (4218 . 4222) ("  " . 4218) (4179 . 4183) ("  " . 4179) (4110 . 4112) (4105 . 4107) (4090 . 4094) ("  " . 4090) (4074 . 4078) ("  " . 4074) (4068 . 4072) ("  " . 4068) (4022 . 4028) ("    " . 4022) (3983 . 3987) ("  " . 3983) (3946 . 3950) ("  " . 3946) (3923 . 3927) ("  " . 3923) (3883 . 3887) ("  " . 3883) (3816 . 3818) (3811 . 3813) (3796 . 3800) ("  " . 3796) (3780 . 3784) ("  " . 3780) (3774 . 3778) ("  " . 3774) (3727 . 3733) ("    " . 3727) (3688 . 3692) ("  " . 3688) (3648 . 3652) ("  " . 3648) (3624 . 3628) ("  " . 3624) (3584 . 3588) ("  " . 3584) (3518 . 3520) (3495 . 3497) (3489 . 3491) (3467 . 3471) ("  " . 3467) (3446 . 3450) ("  " . 3446) (3440 . 3444) ("  " . 3440) (3414 . 3420) ("    " . 3414) (3375 . 3379) ("  " . 3375) (3348 . 3352) ("  " . 3348) (3342 . 3346) ("  " . 3342) (3317 . 3323) ("    " . 3317) (3278 . 3282) ("  " . 3278) (3245 . 3249) ("  " . 3245) (3217 . 3219) (3212 . 3214) (3195 . 3199) ("  " . 3195) (3155 . 3159) ("  " . 3155) (3132 . 3136) ("  " . 3132) (3088 . 3092) ("  " . 3088) (3082 . 3086) ("  " . 3082) (3062 . 3068) ("    " . 3062) (3031 . 3035) ("  " . 3031) (2992 . 2996) ("  " . 2992) (2928 . 2930) (2923 . 2925) (2904 . 2908) ("  " . 2904) (2854 . 2860) ("    " . 2854) (2804 . 2808) ("  " . 2804) (2750 . 2756) ("    " . 2750) (2703 . 2707) ("  " . 2703) (2697 . 2701) ("  " . 2697) (2677 . 2683) ("    " . 2677) (2632 . 2633) ("      " . 2632) (2577 . 2581) ("  " . 2577) (2560 . 2564) ("  " . 2560) (2522 . 2527) ("				      " . 2522) (2450 . 2452) (2445 . 2447) (2428 . 2432) ("  " . 2428) (2382 . 2386) ("  " . 2382) (2376 . 2380) ("  " . 2376) (2368 . 2374) ("    " . 2368) (2353 . 2354) ("      " . 2353) (2306 . 2312) ("    " . 2306) (2267 . 2271) ("  " . 2267) (2233 . 2237) ("  " . 2233) (2174 . 2176) (2169 . 2171) (2152 . 2156) ("  " . 2152) (2108 . 2112) ("  " . 2108) (2102 . 2106) ("  " . 2102) (2094 . 2100) ("    " . 2094) (2079 . 2080) ("      " . 2079) (2033 . 2039) ("    " . 2033) (1994 . 1998) ("  " . 1994) (1961 . 1965) ("  " . 1961) (1903 . 1905) (1898 . 1900) (1882 . 1886) ("  " . 1882) (1876 . 1880) ("  " . 1876) (1868 . 1874) ("    " . 1868) (1857 . 1858) ("      " . 1857) (1808 . 1814) ("    " . 1808) (1769 . 1773) ("  " . 1769) (1736 . 1740) ("  " . 1736) (1666 . 1668) (1661 . 1663) (1645 . 1649) ("  " . 1645) (1639 . 1643) ("  " . 1639) (1631 . 1637) ("    " . 1631) (1620 . 1621) ("      " . 1620) (1569 . 1575) ("    " . 1569) (1530 . 1534) ("  " . 1530) (1496 . 1500) ("  " . 1496) (1424 . 1426) (1395 . 1397) (1372 . 1374) (1367 . 1369) (1345 . 1349) ("  " . 1345) (1339 . 1343) ("  " . 1339) (1295 . 1301) ("    " . 1295) (1256 . 1260) ("  " . 1256) (1222 . 1226) ("  " . 1222) (1178 . 1180) (1173 . 1175) (1156 . 1160) ("  " . 1156) (1150 . 1154) ("  " . 1150) (1119 . 1125) ("    " . 1119) (1103 . 1107) ("  " . 1103) (1097 . 1101) ("  " . 1097) (1089 . 1095) ("    " . 1089) (1081 . 1082) ("      " . 1081) (1066 . 1067) ("      " . 1066) (1034 . 1040) ("    " . 1034) (995 . 999) ("  " . 995) (961 . 965) ("  " . 961) (939 . 943) ("  " . 939) (897 . 899) (892 . 894) (875 . 879) ("  " . 875) (828 . 830) (758 . 760) (738 . 740) (733 . 735) (727 . 731) ("  " . 727) (719 . 725) ("    " . 719) (711 . 712) ("      " . 711) (674 . 675) ("      " . 674) (643 . 649) ("    " . 643) (604 . 608) ("  " . 604) (571 . 575) ("  " . 571) (522 . 524) (517 . 519) (500 . 504) ("  " . 500) (494 . 498) ("  " . 494) (464 . 470) ("    " . 464) (448 . 452) ("  " . 448) (442 . 446) ("  " . 442) (434 . 440) ("    " . 434) (426 . 427) ("      " . 426) (411 . 412) ("      " . 411) (380 . 386) ("    " . 380) (341 . 345) ("  " . 341) (308 . 312) ("  " . 308) (286 . 290) ("  " . 286) (245 . 247) (240 . 242) (223 . 227) ("  " . 223) (175 . 177) (170 . 172) (105 . 107) (84 . 86) ("}" . 83) nil (82 . 84) nil (77 . 82) nil (" " . -77) 78 nil (70 . 78) nil ("o" . -70) 71 nil (69 . 71) nil (63 . 69) nil ("p" . -63) 64 nil (59 . 64) nil ("using namespace BrooklynPoly;
" . 58) 83 (t 24670 7651 135610 684000) nil (nil fontified t 3928 . 3935) (nil face font-lock-type-face 3928 . 3935) (nil fontified t 3923 . 3928) ("ostream" . -3923) (3930 . 3942) nil (nil fontified t 3909 . 3910) (nil c-type c-decl-id-start 3909 . 3910) (nil face font-lock-type-face 3909 . 3910) (nil fontified t 3903 . 3909) (nil face font-lock-type-face 3903 . 3909) ("ostream" . -3898) (3905 . 3917) nil (nil fontified t 3654 . 3661) (nil face font-lock-type-face 3654 . 3661) (nil fontified t 3649 . 3654) ("ostream" . -3649) (3656 . 3668) nil (nil fontified t 3635 . 3636) (nil c-type c-decl-id-start 3635 . 3636) (nil face font-lock-type-face 3635 . 3636) (nil fontified t 3629 . 3635) (nil face font-lock-type-face 3629 . 3635) ("ostream" . -3624) (3631 . 3643) nil (nil fontified t 3376 . 3383) (nil face font-lock-type-face 3376 . 3383) (nil fontified t 3371 . 3376) ("ostream" . -3371) (3378 . 3390) nil (nil fontified t 3357 . 3358) (nil c-type c-decl-id-start 3357 . 3358) (nil face font-lock-type-face 3357 . 3358) (nil fontified t 3352 . 3357) (nil face font-lock-type-face 3352 . 3357) (nil c-is-sws t 3351 . 3352) (nil fontified t 3351 . 3352) (nil face font-lock-type-face 3351 . 3352) ("ostream" . -3346) (3353 . 3365) nil (nil fontified t 2846 . 2848) (nil face font-lock-type-face 2846 . 2848) (nil fontified t 2842 . 2846) (nil face font-lock-type-face 2842 . 2846) ("string" . -2837) (2843 . 2854) nil (nil fontified t 2427 . 2433) (nil face font-lock-type-face 2427 . 2433) ("string" . -2422) (2428 . 2439) nil (nil fontified t 2385 . 2391) (nil face font-lock-type-face 2385 . 2391) ("string" . -2380) (2386 . 2397) nil (nil fontified t 2111 . 2117) (nil face font-lock-type-face 2111 . 2117) ("string" . -2106) (2112 . 2123) nil (nil face font-lock-type-face 1852 . 1858) (nil fontified t 1852 . 1858) ("string" . -1847) (1853 . 1864) nil (nil fontified t 1629 . 1635) (nil face font-lock-type-face 1629 . 1635) ("string" . -1624) (1630 . 1641) nil (nil fontified t 1399 . 1405) (nil face font-lock-type-face 1399 . 1405) ("string" . -1394) (1400 . 1411) nil (nil fontified t 816 . 817) (nil c-type c-decl-id-start 816 . 817) (nil face font-lock-type-face 816 . 817) (nil fontified t 811 . 816) (nil face font-lock-type-face 811 . 816) ("string" . -806) (812 . 823) nil (nil fontified t 758 . 764) (nil face font-lock-type-face 758 . 764) ("string" . -753) (759 . 770) nil (nil fontified t 191 . 192) (nil c-type c-decl-id-start 191 . 192) (nil face font-lock-type-face 191 . 192) (nil fontified t 186 . 191) (nil face font-lock-type-face 186 . 191) ("string" . -181) (187 . 198) nil (nil fontified t 137 . 143) (nil face font-lock-type-face 137 . 143) ("string" . -132) (138 . 149) nil ("using namespace std;
" . 88) (t 24670 7485 522101 356000) nil ("
" . 57) nil ("
" . 57) nil (nil rear-nonsticky nil 56 . 57) (nil fontified nil 40 . 57) (nil fontified nil 39 . 40) (nil fontified nil 22 . 39) (nil fontified nil 21 . 22) (nil fontified nil 2 . 21) (nil fontified nil 1 . 2) (1 . 57) nil (1 . 4) nil ("
" . 30) nil (30 . 31) 1 nil (51 . 52) nil (50 . 51) nil (48 . 50) nil ("d" . -48) 49 nil (48 . 49) nil ("d" . -48) ("d" . -49) (";" . -50) 51 nil (50 . 51) nil (31 . 50) nil (30 . 31) (t 24670 7324 615208 835000) 1 nil (30 . 31) 30 nil (29 . 30) nil (28 . 29) nil (";" . -28) 29 nil (28 . 29) nil (20 . 28) nil (12 . 20) nil ("a" . -12) 13 nil (1 . 13) nil ("s" . -1) ("u" . -2) 3 nil (1 . 3) (t 24670 6988 817636 3000) nil (2496 . 2500) ("      " . 2496) (2447 . 2449) ("	" . 2447) 1 nil (nil rear-nonsticky nil 4087 . 4088) (nil fontified nil 1 . 4088) (1 . 4088) nil ("
// student methods
Student::Student(const string& thename) : name(thename) {
}

const string& Student::getName() const {
  return name;
}

bool Student::addCourse(Course* cou) {
  bool okay = true;
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i] == cou) {
      okay = false;
    }
  }
  if (okay) {
    courses.push_back(cou);
  }
  return okay;
}

void Student::removedFromCourse(Course* cou) {
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i] == cou) {
      courses.erase(courses.begin() + i);
      break;
    }
  }
}

// course methods
Course::Course(const string& courseName) : name(courseName){}

const string& Course::getName() const {
  return name;
}

bool Course::addStudent(Student* stu) {
  bool okay = true;
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    if (students[i] == stu) {
      okay = false;
    }
  }
  if (okay) {
    students.push_back(stu);
  }
  return okay;
}

void Course::removeStudentsFromCourse() {
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    students[i]->removedFromCourse(this);
  }
  students.clear();
}

// registrar methods
Registrar::Registrar() {}

size_t Registrar::findStudent(const string& studentName) const {
  size_t len = students.size();
  for (size_t i = 0; i < len; i++) {
    if (students[i]->getName() == studentName) {
      return i;
    }
  }
  return 0;
}

size_t Registrar::findCourse(const string& courseName) const {
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    if (courses[i]->getName() == courseName) {
      return i;
    }
  }
  return 0;
}

bool Registrar::addCourse(const string& couname) {
  courses.push_back(new Course(couname));
  return true;
}

bool Registrar::addStudent(const string& stuname) {
  students.push_back(new Student(stuname));
  return true;
}

bool Registrar::enrollStudentInCourse(const string& studentName,
				      const string& courseName) {
  courses[findCourse(courseName)]->
    addStudent(students[findStudent(studentName)]);
  students[findStudent(studentName)]->
    addCourse(courses[findCourse(courseName)]);
  return true;
}

bool Registrar::cancelCourse(const string& courseName) {
  size_t i = findCourse(courseName);
  courses[i]->removeStudentsFromCourse();
  delete courses[i];
  courses.erase(courses.begin() + i);
  return true;
}

void Registrar::purge() {
  size_t len = courses.size();
  for (size_t i = 0; i < len; i++) {
    delete courses[i];
  }
  len = students.size();
  for (size_t i = 0; i < len; i++) {
    delete students[i];
  }
  courses.clear();
  students.clear();
}


// output operators

ostream& operator<<(ostream& os, const Course& rhs) {
  os << \"Name: \" << rhs.name << endl;
  os << \"Students: \";
  size_t len = (rhs.students).size();
  for (size_t i = 0; i < len; i++) {
    os << rhs.students[i]->getName() << \" \";
  }
  os << endl;
  return os;
}

ostream& operator<<(ostream& os, const Student& rhs) {
  os << \"Name: \" << rhs.name << endl;
  os << \"Courses: \";
  size_t len = rhs.courses.size();
  for (size_t i = 0; i < len; i++) {
    os << rhs.courses[i]->getName() << \" \";
  }
  os << endl;
  return os;
}

ostream& operator<<(ostream& os, const Registrar& rhs) {
  size_t len = (rhs.courses).size();
  os << \"Courses: \";
  for (size_t i = 0; i < len; i++) {
    os << *(rhs.courses[i]);
  }
  os << endl;
  os << \"Students: \";
  len = (rhs.students).size();
  for (size_t i = 0; i < len; i++) {
    os << *(rhs.students[i]);
  }
  os << endl;
  return os;
}
" . 1) 3560 (t 24670 5424 560277 758000) nil (2170 . 2172) (2031 . 2035) ("      " . 2031) (1995 . 1997) ("    " . 1995) 1 nil (nil rear-nonsticky nil 3561 . 3562) (nil fontified nil 1 . 3562) (1 . 3562) (t . -1)) (emacs-undo-equiv-table (-45 . -47) (-1 . -3) (-5 . -7) (8 . -1)))