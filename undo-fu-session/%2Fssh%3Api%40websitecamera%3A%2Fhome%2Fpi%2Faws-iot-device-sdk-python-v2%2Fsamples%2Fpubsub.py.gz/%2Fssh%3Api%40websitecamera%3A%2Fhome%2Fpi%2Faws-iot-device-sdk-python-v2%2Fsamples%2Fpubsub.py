((buffer-size . 8793) (buffer-checksum . "78d8c43e241816da3c5fbecab84827379195e097"))
((emacs-buffer-undo-list nil (22 . 23) nil (nil rear-nonsticky nil 21 . 22) (nil fontified nil 1 . 22) (1 . 22) nil (1 . 2) (t 24631 34270 0 0) nil (3645 . 3646) ("\"" . -3645) (3645 . 3646) nil ("\"" . -3652) ((marker) . -1) 3653 nil (3651 . 3653) ("\"" . -3651) (3651 . 3652) (t 24631 34184 0 0) nil (5334 . 5335) ("a" . 5334) nil (5334 . 5337) (t 24631 34136 0 0) nil ("all" . 5334) ((marker* . 3676) . 2) nil (5334 . 5337) (t 24631 34136 0 0) nil (";" . 5336) nil (5336 . 5337) (")" . -5335) (5335 . 5336) (")" . -5335) (5335 . 5336) (5320 . 5336) nil (5315 . 5320) nil (3808 . 3810) nil (3803 . 3808) nil (3735 . 3742) nil (3652 . 3653) (")" . -3652) (3652 . 3653) nil (")" . -3640) ((marker) . -1) ((marker*) . 1) ((marker) . -1) 3641 nil (3636 . 3641) nil ("]" . -3647) (3647 . 3648) ("]" . -3647) (3647 . 3648) nil ("}" . -3647) ((marker) . -1) ((marker*) . 1) ((marker) . -1) 3648 nil (3647 . 3648) ("}" . -3647) (3641 . 3648) (3640 . 3642) nil (3627 . 3640) nil (3622 . 3627) nil ("+" . -3765) ((marker) . -1) ("5" . -3766) ((marker) . -1) 3767 nil ("+" . -3704) ((marker) . -1) (" " . -3705) ((marker) . -1) 3706 nil (3704 . 3706) nil ("+" . -3704) ((marker) . -1) ((marker) . -1) ("5" . -3705) ((marker) . -1) ((marker) . -1) 3706 nil (3704 . 3706) nil (3765 . 3767) nil ("0" . 3763) (3764 . 3765) 3763 nil ("1" . 3702) (3703 . 3704) 3702 nil (")" . -3764) (3764 . 3765) (")" . -3764) (3763 . 3765) (3745 . 3764) nil ("S" . -3745) ((marker) . -1) 3746 nil (3742 . 3746) (3741 . 3743) nil ("1" . 3650) (3651 . 3652) 3650 nil ("1" . 3682) ((marker* . 23) . 1) nil (3681 . 3682) nil (3737 . 3741) nil ("b" . -3737) ((marker) . -1) 3738 nil (3724 . 3738) nil (3715 . 3724) nil (3710 . 3715) nil ("    " . -3710) ((marker) . -4) 3714 nil (3705 . 3714) nil (")" . -3704) (3704 . 3705) (")" . -3704) (3704 . 3705) (")" . -3703) (3703 . 3704) (")" . -3703) (3702 . 3704) (3689 . 3703) nil ("k" . -3689) ((marker) . -1) 3690 nil (3688 . 3690) nil (3681 . 3688) (3672 . 3682) nil (3663 . 3672) nil (3654 . 3663) nil (3653 . 3654) nil (3647 . 3648) nil (3649 . 3650) (3648 . 3650) ("\"" . -3648) (3648 . 3649) nil (3636 . 3637) ("\"" . -3636) ("'" . 3636) (3637 . 3638) 3636 nil (3643 . 3644) ("\"" . -3643) ("'" . 3643) (3644 . 3645) 3643 nil ("'" . -3648) ((marker) . -1) ((marker) . -1) ("1" . -3649) ((marker) . -1) ((marker) . -1) ("'" . -3650) ((marker) . -1) ((marker) . -1) 3651 nil ("'" . -3650) (3650 . 3651) ("'" . -3650) (3649 . 3651) (3648 . 3650) ("'" . -3648) (3645 . 3649) nil ("=" . -3645) ((marker) . -1) (" " . -3646) ((marker) . -1) 3647 nil (3645 . 3647) nil ("]" . -3644) (3644 . 3645) ("]" . -3644) (3644 . 3645) ("'" . -3643) (3643 . 3644) ("'" . -3643) (3637 . 3644) (3636 . 3638) ("'" . -3636) (3636 . 3637) nil ("m" . -3636) ((marker) . -1) ("o" . -3637) ((marker) . -1) ("t" . -3638) ((marker) . -1) ("o" . -3639) ((marker) . -1) 3640 nil (3636 . 3640) (3631 . 3637) (3627 . 3632) nil (3622 . 3627) (t 24631 33899 0 0) nil (3614 . 3621) nil (3596 . 3615) nil ("j" . -3596) ((marker) . -1) ("s" . -3597) ((marker) . -1) ("o" . -3598) ((marker) . -1) ("n" . -3599) ((marker) . -1) ("." . -3600) ((marker) . -1) 3601 nil (3596 . 3601) nil (3591 . 3596) nil (223 . 226) nil ("a" . -223) ((marker) . -1) ("s" . -224) ((marker) . -1) 225 nil (218 . 225) nil ("r" . -218) ((marker) . -1) ("o" . -219) ((marker) . -1) 220 nil (215 . 220) nil (214 . 215) nil (")" . -4957) (4957 . 4958) (")" . -4957) (4950 . 4958) (4944 . 4951) nil (4939 . 4944) nil (3590 . 3597) (3589 . 3591) nil (3584 . 3589) nil (3579 . 3584) nil (3578 . 3579) (")" . -3577) (3577 . 3578) (")" . -3577) (3570 . 3578) (3569 . 3571) nil (" " . -3569) ((marker) . -1) 3570 nil (3569 . 3570) nil (3564 . 3569) nil ("m" . -3564) ((marker) . -1) ((marker) . -1) ("o" . -3565) ((marker) . -1) ((marker) . -1) ("v" . -3566) ((marker) . -1) ((marker) . -1) ("e" . -3567) ((marker) . -1) ((marker) . -1) 3568 nil (3560 . 3568) nil (3559 . 3562) nil ("
" . 3433) ((marker . 24) . -1) nil ("
" . 3498) ((marker . 24) . -1) nil (3560 . 3561) 3538 nil ("
" . 3365) ((marker . 24) . -1) nil (nil rear-nonsticky nil 3365 . 3366) (nil fontified nil 2549 . 3366) (2549 . 3366) nil ("
# ServoKit class
class ServoKit(object):
    default_angle = 90

    def __init__(self, num_ports):
        print(\"Initializing the servo...\")
        self.kit = adafruit_servokit.ServoKit(channels=16)
        self.num_ports = num_ports
        self.resetAll()
        print(\"Initializing complete.\")

    def setAngle(self, port, angle):
        if angle < 0:
            self.kit.servo[port].angle = 0
        elif angle > 180:
            self.kit.servo[port].angle = 180
        else:
            self.kit.servo[port].angle = angle

    def getAngle(self, port):
        return self.kit.servo[port].angle

    def reset(self, port):
        self.kit.servo[port].angle = self.default_angle

    def resetAll(self):
        for i in range(self.num_ports):
            self.kit.servo[i].angle = self.default_angle

" . 2745) ((marker . 1) . -816) ((marker . 3674) . -816) ((marker . 21) . -816) ((marker) . -759) ((marker) . -816) ((marker . 1) . -816) ((marker . 24) . -817) ((marker) . -816) 3561 nil (2722 . 2745) nil ("servoKit = ServoKit(2)
" . 2722) ((marker* . 23) . 1) ((marker) . -22) ((marker) . -22) ((marker . 24) . -23) 2744 nil (")" . -2743) (2743 . 2744) (")" . -2743) (2743 . 2744) nil (2742 . 2743) (2722 . 2743) nil (2731 . 2740) nil ("i" . -2731) ((marker) . -1) 2732 nil (2724 . 2732) nil (2723 . 2724) nil (2722 . 2723) nil ("
" . 3522) ((marker . 24) . -1) nil (nil rear-nonsticky nil 3521 . 3522) (nil fontified nil 2722 . 3522) (2722 . 3522) nil ("
class ServoKit(object):
    default_angle = 90

    def __init__(self, num_ports):
        print(\"Initializing the servo...\")
        self.kit = adafruit_servokit.ServoKit(channels=16)
        self.num_ports = num_ports
        self.resetAll()
        print(\"Initializing complete.\")

    def setAngle(self, port, angle):
        if angle < 0:
            self.kit.servo[port].angle = 0
        elif angle > 180:
            self.kit.servo[port].angle = 180
        else:
            self.kit.servo[port].angle = angle

    def getAngle(self, port):
        return self.kit.servo[port].angle

    def reset(self, port):
        self.kit.servo[port].angle = self.default_angle

    def resetAll(self):
        for i in range(self.num_ports):
            self.kit.servo[i].angle = self.default_angle

" . 216) ((marker . 21) . -799) (nil fontified t 1000 . 1015) (nil fontified t 996 . 1000) (nil fontified t 993 . 996) (nil fontified t 987 . 993) (nil fontified t 974 . 987) (nil fontified t 970 . 974) (nil fontified t 945 . 970) (nil fontified t 941 . 945) (nil fontified t 940 . 941) (nil fontified t 935 . 940) (nil fontified t 934 . 935) (nil fontified t 932 . 934) (nil fontified t 929 . 932) (nil fontified t 926 . 929) (nil fontified t 915 . 926) (nil fontified t 911 . 915) (nil fontified t 910 . 911) (nil fontified t 902 . 910) (nil fontified t 901 . 902) (nil fontified t 898 . 901) (nil fontified t 878 . 898) (nil fontified t 874 . 878) (nil fontified t 871 . 874) (nil fontified t 865 . 871) (nil fontified t 849 . 865) (nil fontified t 845 . 849) (nil fontified t 828 . 845) (nil fontified t 824 . 828) (nil fontified t 823 . 824) (nil fontified t 818 . 823) (nil fontified t 817 . 818) (nil fontified t 814 . 817) (nil fontified t 786 . 814) (nil fontified t 782 . 786) (nil fontified t 781 . 782) (nil fontified t 775 . 781) (nil fontified t 758 . 775) (nil fontified t 754 . 758) (nil fontified t 753 . 754) (nil fontified t 745 . 753) (nil fontified t 744 . 745) (nil fontified t 741 . 744) (nil fontified t 736 . 741) (nil fontified t 727 . 736) (nil fontified t 721 . 727) (nil fontified t 716 . 721) (nil fontified t 705 . 716) (nil fontified t 701 . 705) (nil fontified t 687 . 701) (nil fontified t 683 . 687) (nil fontified t 668 . 683) (nil fontified t 662 . 668) (nil fontified t 646 . 662) (nil fontified t 642 . 646) (nil fontified t 616 . 642) (nil fontified t 612 . 616) (nil fontified t 599 . 612) (nil fontified t 593 . 599) (nil fontified t 577 . 593) (nil fontified t 573 . 577) (nil fontified t 549 . 573) (nil fontified t 547 . 549) (nil fontified t 523 . 547) (nil fontified t 519 . 523) (nil fontified t 518 . 519) (nil fontified t 510 . 518) (nil fontified t 509 . 510) (nil fontified t 506 . 509) (nil fontified t 499 . 506) (nil fontified t 475 . 499) (nil fontified t 474 . 475) (nil fontified t 469 . 474) (nil fontified t 449 . 469) (nil fontified t 445 . 449) (nil fontified t 414 . 445) (nil fontified t 410 . 414) (nil fontified t 355 . 410) (nil fontified t 351 . 355) (nil fontified t 341 . 351) (nil fontified t 314 . 341) (nil fontified t 313 . 314) (nil fontified t 308 . 313) (nil fontified t 286 . 308) (nil fontified t 282 . 286) (nil fontified t 281 . 282) (nil fontified t 273 . 281) (nil fontified t 272 . 273) (nil fontified t 269 . 272) (nil fontified t 258 . 269) (nil fontified t 245 . 258) (nil fontified t 238 . 245) (nil fontified t 232 . 238) (nil fontified t 231 . 232) (nil fontified t 223 . 231) (nil fontified t 222 . 223) (nil fontified t 217 . 222) (nil fontified t 216 . 217) (nil rear-nonsticky t 1015 . 1016) nil (nil rear-nonsticky nil 1015 . 1016) (nil fontified nil 216 . 1016) (216 . 1016) nil (2 . 14) nil ("S" . -2) ((marker) . -1) ((marker) . -1) ("a" . -3) ((marker) . -1) ((marker) . -1) ("c" . -4) ((marker) . -1) ((marker) . -1) ("h" . -5) ((marker) . -1) ("i" . -6) ((marker) . -1) ("n" . -7) ((marker) . -1) 8 nil (1 . 8) nil (1 . 3) nil ("
" . 16) ((marker) . -1) ((marker . 1) . -1) nil ("u" . 17) nil (17 . 18) nil ("u" . -17) ((marker) . -1) 18 nil (17 . 18) nil (16 . 17) 16 nil (2535 . 2575) nil ("# Using globals to simplify sample code
" . 2535) ((marker . 1) . -18) ((marker . 3674) . -18) ((marker* . 3676) . 21) ((marker . 3674) . -18) ((marker . 3674) . -18) ((marker) . -18) ((marker) . -18) ((marker . 24) . -40) 2553 nil ("# since it is subscribed to that same topic.
" . 201) ((marker . 251) . -44) ((marker . 24) . -45) nil ("# The device should receive those same messages back from the message broker,
" . 201) ((marker . 24) . -78) nil ("# subscribes to a topic, and begins publishing messages to that topic.
" . 201) ((marker . 24) . -71) nil ("# through an MQTT connection. On startup, the device connects to the server,
" . 201) ((marker . 24) . -77) nil ("# This sample uses the Message Broker for AWS IoT to send and receive messages
" . 201) ((marker . 24) . -79) nil ("
" . 1) ((marker . 24) . -1) nil ("# SPDX-License-Identifier: Apache-2.0.
" . 1) ((marker . 2846) . -39) ((marker . 24) . -39) nil ("# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
" . 1) ((marker) . -24) ((marker . 24) . -69) 25 nil (291 . 308) ("adafr" . -291) ((marker) . -5) 296 nil (291 . 296) nil ("s" . -291) ((marker) . -1) ("e" . -292) ((marker) . -1) ("r" . -293) ((marker) . -1) ("v" . -294) ((marker) . -1) ("o" . -295) ((marker) . -1) ("k" . -296) ((marker) . -1) 297 nil (284 . 297) nil ("import adafruit_servo" . 284) ((marker) . -21) nil ("kit" . 305) nil ("


" . 660) ((marker) . -3) ((marker . 1) . -3) nil (660 . 663) nil (305 . 308) nil (284 . 305) nil (283 . 284) nil (272 . 283) nil (271 . 272) nil ("    global received_count
" . 4542) ((marker . 1) . -16) ((marker) . -26) ((marker) . -16) ((marker . 24) . -26) 4558 nil ("        received_all_event.set()
" . 4568) ((marker) . -8) ((marker . 24) . -33) 4576 nil ("    if received_count == args.count:
" . 4568) ((marker) . -4) ((marker . 24) . -37) 4572 nil ("    received_count += 1
" . 4568) ((marker . 1) . -15) ((marker) . -15) ((marker . 24) . -24) 4583 nil ("received_count = 0
" . 3090) ((marker . 1) . -15) ((marker . 3674) . -15) ((marker* . 3676) . 3) ((marker . 3674) . -15) ((marker . 3674) . -15) ((marker) . -15) ((marker . 24) . -19) 3105 (t 24631 33348 0 0) nil ("c" . -1152) ((marker) . -1) ((marker) . -1) ("e" . -1153) ((marker) . -1) ((marker) . -1) ("r" . -1154) ((marker) . -1) ((marker) . -1) ("t" . -1155) ((marker) . -1) ((marker) . -1) ("s" . -1156) ((marker) . -1) ((marker) . -1) ("/" . -1157) ((marker) . -1) 1158 nil ("c" . -1034) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("e" . -1035) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("r" . -1036) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("t" . -1037) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("s" . -1038) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("/" . -1039) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) 1040 (t 24631 33309 0 0) nil (1032 . 1033) nil ("r" . 1032) nil ("e" . 1032) nil ("y" . 1032) nil ("i" . 1032) nil ("s" . 1032) nil ("/" . 1032) nil ("e" . 1032) nil ("m" . 1032) nil ("o" . 1032) nil ("h" . 1032) nil ("/" . 1032) nil (1166 . 1167) nil ("r" . 1166) nil ("e" . 1166) nil ("y" . 1166) nil ("i" . 1166) ((marker . 778) . -1) ((marker . 778) . -1) ((marker . 778) . -1) nil ("s" . 1166) nil ("/" . 1166) nil ("e" . 1166) nil ("m" . 1166) nil ("o" . 1166) nil ("h" . 1166) nil ("/" . 1166) nil (1298 . 1299)) (emacs-pending-undo-list (";" . 5336) nil (5336 . 5337) (")" . -5335) (5335 . 5336) (")" . -5335) (5335 . 5336) (5320 . 5336) nil (5315 . 5320) nil (3808 . 3810) nil (3803 . 3808) nil (3735 . 3742) nil (3652 . 3653) (")" . -3652) (3652 . 3653) nil (")" . -3640) ((marker) . -1) ((marker*) . 1) ((marker) . -1) 3641 nil (3636 . 3641) nil ("]" . -3647) (3647 . 3648) ("]" . -3647) (3647 . 3648) nil ("}" . -3647) ((marker) . -1) ((marker*) . 1) ((marker) . -1) 3648 nil (3647 . 3648) ("}" . -3647) (3641 . 3648) (3640 . 3642) nil (3627 . 3640) nil (3622 . 3627) nil ("+" . -3765) ((marker) . -1) ("5" . -3766) ((marker) . -1) 3767 nil ("+" . -3704) ((marker) . -1) (" " . -3705) ((marker) . -1) 3706 nil (3704 . 3706) nil ("+" . -3704) ((marker) . -1) ((marker) . -1) ("5" . -3705) ((marker) . -1) ((marker) . -1) 3706 nil (3704 . 3706) nil (3765 . 3767) nil ("0" . 3763) (3764 . 3765) 3763 nil ("1" . 3702) (3703 . 3704) 3702 nil (")" . -3764) (3764 . 3765) (")" . -3764) (3763 . 3765) (3745 . 3764) nil ("S" . -3745) ((marker) . -1) 3746 nil (3742 . 3746) (3741 . 3743) nil ("1" . 3650) (3651 . 3652) 3650 nil ("1" . 3682) ((marker* . 23) . 1) nil (3681 . 3682) nil (3737 . 3741) nil ("b" . -3737) ((marker) . -1) 3738 nil (3724 . 3738) nil (3715 . 3724) nil (3710 . 3715) nil ("    " . -3710) ((marker) . -4) 3714 nil (3705 . 3714) nil (")" . -3704) (3704 . 3705) (")" . -3704) (3704 . 3705) (")" . -3703) (3703 . 3704) (")" . -3703) (3702 . 3704) (3689 . 3703) nil ("k" . -3689) ((marker) . -1) 3690 nil (3688 . 3690) nil (3681 . 3688) (3672 . 3682) nil (3663 . 3672) nil (3654 . 3663) nil (3653 . 3654) nil (3647 . 3648) nil (3649 . 3650) (3648 . 3650) ("\"" . -3648) (3648 . 3649) nil (3636 . 3637) ("\"" . -3636) ("'" . 3636) (3637 . 3638) 3636 nil (3643 . 3644) ("\"" . -3643) ("'" . 3643) (3644 . 3645) 3643 nil ("'" . -3648) ((marker) . -1) ((marker) . -1) ("1" . -3649) ((marker) . -1) ((marker) . -1) ("'" . -3650) ((marker) . -1) ((marker) . -1) 3651 nil ("'" . -3650) (3650 . 3651) ("'" . -3650) (3649 . 3651) (3648 . 3650) ("'" . -3648) (3645 . 3649) nil ("=" . -3645) ((marker) . -1) (" " . -3646) ((marker) . -1) 3647 nil (3645 . 3647) nil ("]" . -3644) (3644 . 3645) ("]" . -3644) (3644 . 3645) ("'" . -3643) (3643 . 3644) ("'" . -3643) (3637 . 3644) (3636 . 3638) ("'" . -3636) (3636 . 3637) nil ("m" . -3636) ((marker) . -1) ("o" . -3637) ((marker) . -1) ("t" . -3638) ((marker) . -1) ("o" . -3639) ((marker) . -1) 3640 nil (3636 . 3640) (3631 . 3637) (3627 . 3632) nil (3622 . 3627) (t 24631 33899 0 0) nil (3614 . 3621) nil (3596 . 3615) nil ("j" . -3596) ((marker) . -1) ("s" . -3597) ((marker) . -1) ("o" . -3598) ((marker) . -1) ("n" . -3599) ((marker) . -1) ("." . -3600) ((marker) . -1) 3601 nil (3596 . 3601) nil (3591 . 3596) nil (223 . 226) nil ("a" . -223) ((marker) . -1) ("s" . -224) ((marker) . -1) 225 nil (218 . 225) nil ("r" . -218) ((marker) . -1) ("o" . -219) ((marker) . -1) 220 nil (215 . 220) nil (214 . 215) nil (")" . -4957) (4957 . 4958) (")" . -4957) (4950 . 4958) (4944 . 4951) nil (4939 . 4944) nil (3590 . 3597) (3589 . 3591) nil (3584 . 3589) nil (3579 . 3584) nil (3578 . 3579) (")" . -3577) (3577 . 3578) (")" . -3577) (3570 . 3578) (3569 . 3571) nil (" " . -3569) ((marker) . -1) 3570 nil (3569 . 3570) nil (3564 . 3569) nil ("m" . -3564) ((marker) . -1) ((marker) . -1) ("o" . -3565) ((marker) . -1) ((marker) . -1) ("v" . -3566) ((marker) . -1) ((marker) . -1) ("e" . -3567) ((marker) . -1) ((marker) . -1) 3568 nil (3560 . 3568) nil (3559 . 3562) nil ("
" . 3433) ((marker . 24) . -1) nil ("
" . 3498) ((marker . 24) . -1) nil (3560 . 3561) 3538 nil ("
" . 3365) ((marker . 24) . -1) nil (nil rear-nonsticky nil 3365 . 3366) (nil fontified nil 2549 . 3366) (2549 . 3366) nil ("
# ServoKit class
class ServoKit(object):
    default_angle = 90

    def __init__(self, num_ports):
        print(\"Initializing the servo...\")
        self.kit = adafruit_servokit.ServoKit(channels=16)
        self.num_ports = num_ports
        self.resetAll()
        print(\"Initializing complete.\")

    def setAngle(self, port, angle):
        if angle < 0:
            self.kit.servo[port].angle = 0
        elif angle > 180:
            self.kit.servo[port].angle = 180
        else:
            self.kit.servo[port].angle = angle

    def getAngle(self, port):
        return self.kit.servo[port].angle

    def reset(self, port):
        self.kit.servo[port].angle = self.default_angle

    def resetAll(self):
        for i in range(self.num_ports):
            self.kit.servo[i].angle = self.default_angle

" . 2745) ((marker . 1) . -816) ((marker . 3674) . -816) ((marker . 21) . -816) ((marker) . -759) ((marker) . -816) ((marker . 1) . -816) ((marker . 24) . -817) ((marker) . -816) 3561 nil (2722 . 2745) nil ("servoKit = ServoKit(2)
" . 2722) ((marker* . 23) . 1) ((marker) . -22) ((marker) . -22) ((marker . 24) . -23) 2744 nil (")" . -2743) (2743 . 2744) (")" . -2743) (2743 . 2744) nil (2742 . 2743) (2722 . 2743) nil (2731 . 2740) nil ("i" . -2731) ((marker) . -1) 2732 nil (2724 . 2732) nil (2723 . 2724) nil (2722 . 2723) nil ("
" . 3522) ((marker . 24) . -1) nil (nil rear-nonsticky nil 3521 . 3522) (nil fontified nil 2722 . 3522) (2722 . 3522) nil ("
class ServoKit(object):
    default_angle = 90

    def __init__(self, num_ports):
        print(\"Initializing the servo...\")
        self.kit = adafruit_servokit.ServoKit(channels=16)
        self.num_ports = num_ports
        self.resetAll()
        print(\"Initializing complete.\")

    def setAngle(self, port, angle):
        if angle < 0:
            self.kit.servo[port].angle = 0
        elif angle > 180:
            self.kit.servo[port].angle = 180
        else:
            self.kit.servo[port].angle = angle

    def getAngle(self, port):
        return self.kit.servo[port].angle

    def reset(self, port):
        self.kit.servo[port].angle = self.default_angle

    def resetAll(self):
        for i in range(self.num_ports):
            self.kit.servo[i].angle = self.default_angle

" . 216) ((marker . 21) . -799) (nil fontified t 1000 . 1015) (nil fontified t 996 . 1000) (nil fontified t 993 . 996) (nil fontified t 987 . 993) (nil fontified t 974 . 987) (nil fontified t 970 . 974) (nil fontified t 945 . 970) (nil fontified t 941 . 945) (nil fontified t 940 . 941) (nil fontified t 935 . 940) (nil fontified t 934 . 935) (nil fontified t 932 . 934) (nil fontified t 929 . 932) (nil fontified t 926 . 929) (nil fontified t 915 . 926) (nil fontified t 911 . 915) (nil fontified t 910 . 911) (nil fontified t 902 . 910) (nil fontified t 901 . 902) (nil fontified t 898 . 901) (nil fontified t 878 . 898) (nil fontified t 874 . 878) (nil fontified t 871 . 874) (nil fontified t 865 . 871) (nil fontified t 849 . 865) (nil fontified t 845 . 849) (nil fontified t 828 . 845) (nil fontified t 824 . 828) (nil fontified t 823 . 824) (nil fontified t 818 . 823) (nil fontified t 817 . 818) (nil fontified t 814 . 817) (nil fontified t 786 . 814) (nil fontified t 782 . 786) (nil fontified t 781 . 782) (nil fontified t 775 . 781) (nil fontified t 758 . 775) (nil fontified t 754 . 758) (nil fontified t 753 . 754) (nil fontified t 745 . 753) (nil fontified t 744 . 745) (nil fontified t 741 . 744) (nil fontified t 736 . 741) (nil fontified t 727 . 736) (nil fontified t 721 . 727) (nil fontified t 716 . 721) (nil fontified t 705 . 716) (nil fontified t 701 . 705) (nil fontified t 687 . 701) (nil fontified t 683 . 687) (nil fontified t 668 . 683) (nil fontified t 662 . 668) (nil fontified t 646 . 662) (nil fontified t 642 . 646) (nil fontified t 616 . 642) (nil fontified t 612 . 616) (nil fontified t 599 . 612) (nil fontified t 593 . 599) (nil fontified t 577 . 593) (nil fontified t 573 . 577) (nil fontified t 549 . 573) (nil fontified t 547 . 549) (nil fontified t 523 . 547) (nil fontified t 519 . 523) (nil fontified t 518 . 519) (nil fontified t 510 . 518) (nil fontified t 509 . 510) (nil fontified t 506 . 509) (nil fontified t 499 . 506) (nil fontified t 475 . 499) (nil fontified t 474 . 475) (nil fontified t 469 . 474) (nil fontified t 449 . 469) (nil fontified t 445 . 449) (nil fontified t 414 . 445) (nil fontified t 410 . 414) (nil fontified t 355 . 410) (nil fontified t 351 . 355) (nil fontified t 341 . 351) (nil fontified t 314 . 341) (nil fontified t 313 . 314) (nil fontified t 308 . 313) (nil fontified t 286 . 308) (nil fontified t 282 . 286) (nil fontified t 281 . 282) (nil fontified t 273 . 281) (nil fontified t 272 . 273) (nil fontified t 269 . 272) (nil fontified t 258 . 269) (nil fontified t 245 . 258) (nil fontified t 238 . 245) (nil fontified t 232 . 238) (nil fontified t 231 . 232) (nil fontified t 223 . 231) (nil fontified t 222 . 223) (nil fontified t 217 . 222) (nil fontified t 216 . 217) (nil rear-nonsticky t 1015 . 1016) nil (nil rear-nonsticky nil 1015 . 1016) (nil fontified nil 216 . 1016) (216 . 1016) nil (2 . 14) nil ("S" . -2) ((marker) . -1) ((marker) . -1) ("a" . -3) ((marker) . -1) ((marker) . -1) ("c" . -4) ((marker) . -1) ((marker) . -1) ("h" . -5) ((marker) . -1) ("i" . -6) ((marker) . -1) ("n" . -7) ((marker) . -1) 8 nil (1 . 8) nil (1 . 3) nil ("
" . 16) ((marker) . -1) ((marker . 1) . -1) nil ("u" . 17) nil (17 . 18) nil ("u" . -17) ((marker) . -1) 18 nil (17 . 18) nil (16 . 17) 16 nil (2535 . 2575) nil ("# Using globals to simplify sample code
" . 2535) ((marker . 1) . -18) ((marker . 3674) . -18) ((marker* . 3676) . 21) ((marker . 3674) . -18) ((marker . 3674) . -18) ((marker) . -18) ((marker) . -18) ((marker . 24) . -40) 2553 nil ("# since it is subscribed to that same topic.
" . 201) ((marker . 251) . -44) ((marker . 24) . -45) nil ("# The device should receive those same messages back from the message broker,
" . 201) ((marker . 24) . -78) nil ("# subscribes to a topic, and begins publishing messages to that topic.
" . 201) ((marker . 24) . -71) nil ("# through an MQTT connection. On startup, the device connects to the server,
" . 201) ((marker . 24) . -77) nil ("# This sample uses the Message Broker for AWS IoT to send and receive messages
" . 201) ((marker . 24) . -79) nil ("
" . 1) ((marker . 24) . -1) nil ("# SPDX-License-Identifier: Apache-2.0.
" . 1) ((marker . 2846) . -39) ((marker . 24) . -39) nil ("# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
" . 1) ((marker) . -24) ((marker . 24) . -69) 25 nil (291 . 308) ("adafr" . -291) ((marker) . -5) 296 nil (291 . 296) nil ("s" . -291) ((marker) . -1) ("e" . -292) ((marker) . -1) ("r" . -293) ((marker) . -1) ("v" . -294) ((marker) . -1) ("o" . -295) ((marker) . -1) ("k" . -296) ((marker) . -1) 297 nil (284 . 297) nil ("import adafruit_servo" . 284) ((marker) . -21) nil ("kit" . 305) nil ("


" . 660) ((marker) . -3) ((marker . 1) . -3) nil (660 . 663) nil (305 . 308) nil (284 . 305) nil (283 . 284) nil (272 . 283) nil (271 . 272) nil ("    global received_count
" . 4542) ((marker . 1) . -16) ((marker) . -26) ((marker) . -16) ((marker . 24) . -26) 4558 nil ("        received_all_event.set()
" . 4568) ((marker) . -8) ((marker . 24) . -33) 4576 nil ("    if received_count == args.count:
" . 4568) ((marker) . -4) ((marker . 24) . -37) 4572 nil ("    received_count += 1
" . 4568) ((marker . 1) . -15) ((marker) . -15) ((marker . 24) . -24) 4583 nil ("received_count = 0
" . 3090) ((marker . 1) . -15) ((marker . 3674) . -15) ((marker* . 3676) . 3) ((marker . 3674) . -15) ((marker . 3674) . -15) ((marker) . -15) ((marker . 24) . -19) 3105 (t 24631 33348 0 0) nil ("c" . -1152) ((marker) . -1) ((marker) . -1) ("e" . -1153) ((marker) . -1) ((marker) . -1) ("r" . -1154) ((marker) . -1) ((marker) . -1) ("t" . -1155) ((marker) . -1) ((marker) . -1) ("s" . -1156) ((marker) . -1) ((marker) . -1) ("/" . -1157) ((marker) . -1) 1158 nil ("c" . -1034) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("e" . -1035) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("r" . -1036) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("t" . -1037) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("s" . -1038) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) ((marker) . -1) ("/" . -1039) ((marker . 1) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker . 3674) . -1) ((marker) . -1) 1040 (t 24631 33309 0 0) nil (1032 . 1033) nil ("r" . 1032) nil ("e" . 1032) nil ("y" . 1032) nil ("i" . 1032) nil ("s" . 1032) nil ("/" . 1032) nil ("e" . 1032) nil ("m" . 1032) nil ("o" . 1032) nil ("h" . 1032) nil ("/" . 1032) nil (1166 . 1167) nil ("r" . 1166) nil ("e" . 1166) nil ("y" . 1166) nil ("i" . 1166) ((marker . 778) . -1) ((marker . 778) . -1) ((marker . 778) . -1) nil ("s" . 1166) nil ("/" . 1166) nil ("e" . 1166) nil ("m" . 1166) nil ("o" . 1166) nil ("h" . 1166) nil ("/" . 1166) nil (1298 . 1299)) (emacs-undo-equiv-table (9 . -1) (-84 . -86) (-95 . -97) (-101 . -107) (-102 . -106) (-103 . -105) (-107 . -109) (-122 . -126) (-123 . -125) (-121 . -127)))