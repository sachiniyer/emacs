((buffer-size . 903) (buffer-checksum . "139e81b0db8f2e9a00e339e724478914bb9d5c5b"))
((emacs-buffer-undo-list (903 . 904) 459 nil ("
int main() {
  Noble art(\"King Arthur\");
  Noble lance(\"Lancelot du Lac\");
  Noble jim(\"Jim\");
	Noble linus(\"Linus Torvalds\");
	Noble billie(\"Bill Gates\");

	Warrior cheetah(\"Tarzan\", 10);
	Warrior wizard(\"Merlin\", 15);
	Warrior theGovernator(\"Conan\", 12);
	Warrior nimoy(\"Spock\", 15);
	Warrior lawless(\"Xena\", 20);
	Warrior mrGreen(\"Hulk\", 8);
	Warrior dylan(\"Hercules\", 3);

	jim.hire(nimoy);
	lance.hire(theGovernator);
	art.hire(wizard);
	lance.hire(dylan);
	linus.hire(lawless);
	billie.hire(mrGreen);
	art.hire(cheetah);

	cout << \"================ Initial Status ===============\" << endl;
	cout << jim << endl;
	cout << lance << endl;
	cout << art << endl;
	cout << linus << endl;
	cout << billie;
	cout << \"===============================================\\n\\n\";

	cheetah.runaway();
	cout << art << endl;

	art.battle(lance);
	jim.battle(lance);
	linus.battle(billie);
	billie.battle(lance);

	cout << \"\\n================ Final Status ===============\" << endl;
	cout << jim << endl;
	cout << lance << endl;
	cout << art << endl;
	cout << linus << endl;
	cout << billie << endl;
	// Tarzan should be unemployed
	cout << \"Tarzan's Hire Status: \" << boolalpha << cheetah.isHired() << endl;
	cout << \"===============================================\\n\\n\";
}
" . 903) ((marker . 459) . -1261) ((marker . 1) . -221) ((marker . 458) . -1261) ((marker . 501) . -1261) ((marker . 903) . -1261) ((marker* . 904) . 1261) ((marker . 903) . -1261) ((marker) . -1261) ((marker) . -1261) ((marker . 903) . -317) ((marker . 903) . -339) ((marker . 903) . -834) ((marker . 903) . -839) ((marker) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker . 903) . -1261) ((marker) . -1261) 2164 nil (979 . 981) ("	" . -979) (945 . 947) ("	" . 945) (917 . 919) ("	" . 917) (879 . 881) ("    " . 879) (855 . 857) ("    " . 855) (829 . 831) ("    " . 829) (808 . 810) ("    " . 808) (786 . 788) ("    " . 786) (762 . 764) ("    " . 762) (730 . 732) ("    " . 730) (696 . 698) ("    " . 696) (662 . 664) ("    " . 662) (636 . 638) ("    " . 636) (610 . 612) ("    " . 610) (547 . 549) ("    " . 547) (524 . 526) ("    " . 524) (501 . 503) ("    " . 501) (458 . 460) ("    " . 458) (414 . 416) ("    " . 414) (390 . 392) ("    " . 390) (370 . 372) ("    " . 370) (348 . 350) ("    " . 348) (285 . 287) ("    " . 285) (266 . 268) ("    " . 266) (243 . 245) ("    " . 243) (207 . 209) ("    " . 207) (188 . 190) ("    " . 188) 175 nil (nil rear-nonsticky nil 950 . 951) (nil fontified nil 175 . 951) (175 . 951) (t 24702 33835 260567 77000)) (emacs-pending-undo-list (463 . 467) nil ("N" . -463) ((marker) . -1) ((marker) . -1) ("o" . -464) ((marker) . -1) ((marker) . -1) ("b" . -465) ((marker) . -1) ((marker) . -1) ("l" . -466) ((marker) . -1) ((marker) . -1) ("e" . -467) ((marker) . -1) 468 (t 24702 34363 204440 692000) nil ("e" . 1182) (t 24702 34274 427865 551000) (1183 . 1184) 1182 (t 24702 34274 427865 551000) nil (1242 . 1244) nil (1241 . 1242) nil (1085 . 1087) nil (1084 . 1085) (t 24702 34148 14872 920000) nil (953 . 954) nil ("
    " . 979) ((marker) . -5) ((marker) . -5) ((marker) . -1) nil (980 . 984) nil ("    " . -980) ((marker) . -4) ((marker) . -4) 984 nil (979 . 984) 953 nil ("v" . 953) (t 24702 34148 14872 920000) nil (793 . 799) (t 24702 33835 260567 77000)) (emacs-undo-equiv-table (-10 . -12) (-9 . -13) (-8 . -14)))