((buffer-size . 10044) (buffer-checksum . "36a5792f593fb9e17fe11b06ea3a27af93d7f370"))
((emacs-buffer-undo-list nil ("    
" . 9245) ((marker . 9246) . -1) ((marker . 9245) . -5) ((marker . 9247) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -5) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) 9246 nil ("    
" . 9250) ((marker . 9246) . -1) ((marker . 9245) . -5) ((marker . 9247) . -5) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) ((marker . 9245) . -1) 9251 nil (nil rear-nonsticky nil 9255 . 9256) (nil fontified nil 7837 . 9256) (7837 . 9256) nil ("    " . -7837) ((marker . 9246) . -4) 7841 nil (7836 . 7841) 7836 nil ("    " . -7836) ((marker . 9246) . -4) 7840 nil (7835 . 7840) 7792 nil (nil rear-nonsticky nil 6757 . 6758) (nil fontified nil 5867 . 6758) (nil fontified nil 5866 . 5867) (nil fontified nil 5801 . 5866) (nil fontified nil 5800 . 5801) (nil fontified nil 5489 . 5800) (nil fontified nil 5488 . 5489) (nil fontified nil 5425 . 5488) (nil fontified nil 5424 . 5425) (nil fontified nil 4582 . 5424) (4582 . 6758) 5331 ("MainComponent::MainComponent()
{
    // Make sure you set the size of the component after
    // you add any child components.
    setSize (800, 600);

    // Some platforms require permissions to open input channels so request that here
    if (juce::RuntimePermissions::isRequired (juce::RuntimePermissions::recordAudio)
        && ! juce::RuntimePermissions::isGranted (juce::RuntimePermissions::recordAudio))
    {
        juce::RuntimePermissions::request (juce::RuntimePermissions::recordAudio,
                                           [&] (bool granted) { setAudioChannels (granted ? 2 : 0, 2); });
    }
    else
    {
        // Specify the number of input and output channels that we want to open
        setAudioChannels (2, 2);
    }
}" . 4582) ((marker . 7837) . -748) ((marker . 4582) . -748) 5331 nil (nil rear-nonsticky nil 4580 . 4581) (nil fontified nil 4581 . 4582) (nil fontified nil 4474 . 4581) (nil fontified nil 4473 . 4474) (nil fontified nil 4408 . 4473) (nil fontified nil 4407 . 4408) (nil fontified nil 3588 . 4407) (nil fontified nil 3587 . 3588) (nil fontified nil 3582 . 3587) (nil fontified nil 3581 . 3582) (nil fontified nil 2543 . 3581) (nil fontified nil 2542 . 2543) (nil fontified nil 2535 . 2542) (nil fontified nil 2534 . 2535) (nil fontified nil 1634 . 2534) (nil fontified nil 1633 . 1634) (nil fontified nil 1619 . 1633) (nil fontified nil 1618 . 1619) (nil fontified nil 1214 . 1618) (nil fontified nil 1213 . 1214) (nil fontified nil 1147 . 1213) (nil fontified nil 1146 . 1147) (nil fontified nil 1020 . 1146) (nil fontified nil 1019 . 1020) (nil fontified nil 954 . 1019) (nil fontified nil 953 . 954) (nil fontified nil 196 . 953) (195 . 4581) nil (194 . 195) 194 nil (193 . 194) 110 nil (nil rear-nonsticky nil 109 . 110) ("
" . -193) (109 . 194) 29 (t 25194 11632 540134 707000)) (emacs-pending-undo-list (4580 . 6756) nil ("MainComponent::MainComponent()
{
    
    client.init_protocols();
    control_channel_id = client.add_control_channel(corelink::core::network::constants::protocols::tcp
                                                    , \"corelink.hpc.nyu.edu\"
                                                    ,
                                                    20010,
                                                    \"\",
                                                    on_error,
                                                    on_channel_init,
                                                    on_channel_uninit
                                                    );
    
    client.request(
                   control_channel_id,
                   corelink::client::corelink_functions::authenticate,
                   std::make_shared<corelink::client::request_response::authenticate_client_request>
                   (
                    \"Testuser\",
                    \"Testpassword\"
                    ),
                   [self = this](corelink::core::network::channel_id_type control_channel_id,
                                 In(std::string) msg,
                                 In(std::shared_ptr<corelink::client::request_response::corelink_server_response_base>) response){
                                     self->create_receiver(control_channel_id, msg, response);
                                 }
                   );
    
    // Make sure you set the size of the component after
    // you add any child components.
    setSize (800, 600);
    
    // Some platforms require permissions to open input channels so request that here
    if (juce::RuntimePermissions::isRequired (juce::RuntimePermissions::recordAudio)
        && ! juce::RuntimePermissions::isGranted (juce::RuntimePermissions::recordAudio))
    {
        juce::RuntimePermissions::request (juce::RuntimePermissions::recordAudio,
                                           [&] (bool granted) { setAudioChannels (granted ? 2 : 0, 2); });
    }
    else
    {
        // Specify the number of input and output channels that we want to open
        setAudioChannels (2, 2);
    }
}
" . 4580) ((marker . 9269) . -1664) ((marker . 9269) . -2175) ((marker . 7851) . -2175) ((marker) . -31) ((marker) . -2175) (t 25194 12362 276195 657000) nil (113 . 4499) nil ("void on_channel_init(corelink::core::network::channel_id_type host_id)
{
    std::cout << \"Host id: \" << host_id << \" connected\\n\";
    print_delim;
}

void on_channel_uninit(corelink::core::network::channel_id_type host_id)
{
    std::cout << \"Host id: \" << host_id << \" disconnected\\n\";
    print_delim;
}

void on_error(
              corelink::core::network::channel_id_type host_id,
              In(std::string)err)
{
    std::cerr << \"Error in host id: \" << host_id << \"\\n\" << err << \"\\n\";
    print_delim;
}

void MainComponent::create_receiver(
                                    corelink::core::network::channel_id_type control_channel_id,
                                    In(std::string),
                                    In(std::shared_ptr<corelink::client::request_response::corelink_server_response_base>) response
                                    )
{
    // we are creating a TCP sender
    auto request =
    std::make_shared<corelink::client::request_response::modify_receiver_stream_request>(
                                                                                         corelink::core::network::constants::protocols::udp);
    // only websockets
    // request->client_certificate_path = \"/Users/sarthaktickoo/Work/hsrn/corelink/repos/corelink/config/ca-crt.pem\";
    request->alert = true;
    request->echo = true;
    request->workspace = \"Holodeck\";
    request->stream_type = \"['sarthak_test_1']\\n\";
    request->meta = \"Sachin is going to send us some data apparently....\";
    request->on_init = [](corelink::core::network::channel_id_type host_id)
    {
        std::cout << \"Receiver init\\n\";
        print_delim;
    };
    request->on_uninit = [](corelink::core::network::channel_id_type host_id)
    {
        std::cout << \"Receiver uninit\\n\";
        print_delim;
    };
    request->on_error = [](corelink::core::network::channel_id_type host_id, In(std::string)err)
    {
        std::cerr << \"Error while receiving data on the data channel: \" << err << \"\\n\";
        print_delim;
    };
    request->on_receive = [&](corelink::core::network::channel_id_type host_id,
                              In(corelink::client::constants::corelink_stream_id_type)stream_id,
                              In(corelink::utils::rapid_json_shim)headers,
                              In(std::vector<uint8_t>)corelink_data)
    {
        /// TODO: FIGURE OUT JUCE STUFF
        const uint8_t* data_ptr = corelink_data.data();
        
        const auto num_channels = corelink_data[0];
        const auto num_bytes = corelink_data.size() - 1;
        const auto data_per_channel = num_bytes/num_channels;
        
        auto* device = deviceManager.getCurrentAudioDevice();
        auto activeInputChannels  = device->getActiveInputChannels();
        auto activeOutputChannels = device->getActiveOutputChannels();
        
        auto maxInputChannels  = activeInputChannels.getHighestBit() + 1;
        auto maxOutputChannels = activeOutputChannels.getHighestBit() + 1;
        // |-----|-----|-----|---------------|
        //  # of channels - channel 1 data - channel 2 data
        // get amount of channels
        // throw error if amount of channels is not equal to maxOutputChannels
        // channelsize = rest of data / # of channels2
        for (auto channel = 0; channel < maxOutputChannels; ++channel){
            std::vector<float> channel_data;
            for(size_t idx = (channel* data_per_channel) + 1; idx < ((channel*data_per_channel) + data_per_channel) + 1; idx+=4)
                channel_data[idx] = corelink_data[idx] | (corelink_data[idx+1] << 8) | (corelink_data[idx+2] << 16) | (corelink_data[idx+3] << 24);

            // shift by channelsize and then dump into the data_ptr you have
            outputBuffer.copyFromWithRamp(channel, 0, channel_data.data(), (int)data_per_channel, 0.1f, 0.1f);
        }
        
        
    };
    
    client.request(control_channel_id,
                   corelink::client::corelink_functions::create_receiver,
                   request,
                   [&](corelink::core::network::channel_id_type host_id,
                       In(std::string)msg,
                       In(std::shared_ptr<corelink::client::request_response::corelink_server_response_base>)response)
                   {
        std::cout << \"Created Receiver\\n\";
        print_delim;
    });
}

" . 113) ((marker . 9269) . -4385) ((marker . 7362) . -2527) ((marker) . -4385) ((marker) . -4386) ((marker . 9269) . -4385) ((marker . 9269) . -4385) ((marker) . -4385) 4498 (t 25194 12362 276195 657000) nil (29 . 113) nil ("#define print_delim std::cout << \"----------------------------------------------\\n\"
" . 29) ((marker) . -84) ((marker . 112) . -83) (t 25194 12362 276195 657000)) (emacs-undo-equiv-table (-1 . -3) (-5 . t) (-3 . -5)))