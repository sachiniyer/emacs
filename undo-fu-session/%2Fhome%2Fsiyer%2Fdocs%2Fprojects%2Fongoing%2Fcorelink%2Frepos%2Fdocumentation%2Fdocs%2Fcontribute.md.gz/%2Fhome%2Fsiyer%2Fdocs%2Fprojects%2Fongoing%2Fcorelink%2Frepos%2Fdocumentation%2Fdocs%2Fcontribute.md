((buffer-size . 299) (buffer-checksum . "a86b77782ba1cb62f19ff10f4b388d0b0b48a0ec"))
((emacs-buffer-undo-list nil (164 . 184) (163 . 165) nil (nil rear-nonsticky nil 162 . 163) (nil fontified nil 162 . 163) (162 . 163) 161 nil ("]" . 156) ((marker* . 184) . 1) ((marker*) . 1) ((marker) . -1) nil (155 . 157) nil (144 . 161) nil ("o" . -144) ((marker . 234) . -1) 145 nil (139 . 145) nil (129 . 139) nil ("4" . 179) (180 . 181) 179 nil ("3" . 130) (131 . 132) 130 nil (127 . 129) nil ("4" . -127) ((marker . 234) . -1) ("." . -128) ((marker . 234) . -1) 129 nil (127 . 129) nil (126 . 127) (t 25285 23797 250858 518000) 85 nil (nil rear-nonsticky nil 239 . 240) (nil fontified nil 239 . 240) (239 . 240) nil (")" . 219) nil (218 . 220) nil ("-" . -218) (" " . -219) 220 nil (221 . 240) nil (217 . 221) nil (165 . 174) nil ("." . -165) 166 nil ("m" . -166) 167 nil (155 . 167) nil ("m" . -155) 156 nil (155 . 156) (154 . 156) nil (nil rear-nonsticky nil 153 . 154) (nil fontified nil 153 . 154) (153 . 154) nil ("]" . 140) nil (139 . 141) nil (111 . 125) nil ("b" . -111) 112 nil (106 . 112) (105 . 107) ("]" . -104) (104 . 105) ("]" . -104) (104 . 105) nil ("[" . -104) ("]" . 105) nil (99 . 106) (98 . 100) nil ("I" . -98) ("s" . -99) ("s" . -100) ("u" . -101) ("e" . -102) 103 (t 25285 23684 773652 445000) nil ("## Create an Issue

1.  Create an issue ![](issue-1.png)
2.  Select a Template ![](issue-2.png)
3.  Fill out issue (including labels), and submit ![](issue-3.png)

## Create a Merge Request

1.  Create a fork ![](merge-1.png)
2. Create the new repository ![](merge-2.png)
3.  Commit your changes/do your development ![](merge-3.png)
4.  Create a merge request ![](merge-4.png)
5.  Compare changes ![](merge-5.png)
6.  Submit Merge Request ![](merge-6.png)
7.  Wait for approval ![](merge-7.png)

## How to get Approved
" . 172) 691 nil (20 . 21) 20 nil (153 . 170) nil (132 . 153) nil ("i" . -132) ("n" . -133) ("t" . -134) ("e" . -135) 136 nil (132 . 136) nil ("i" . -132) ("n" . -133) ("t" . -134) ("e" . -135) 136 nil (132 . 136) nil (129 . 132) nil (128 . 129) nil (123 . 128) nil ("u" . -123) ("e" . -124) 125 nil (123 . 125) nil ("u" . -123) 124 nil (115 . 124) nil ("m" . -115) ("e" . -116) ("r" . -117) ("g" . -118) ("e" . -119) 120 nil (103 . 120) nil (102 . 103) 102 nil (84 . 102) nil (83 . 84) 83 nil (72 . 82) nil ("e" . -72) 73 nil (63 . 73) nil ("u" . -63) ("b" . -64) 65 nil (60 . 65) nil ("n" . -60) 61 nil (58 . 61) (57 . 59) ("]" . -56) (56 . 57) ("]" . -56) (45 . 57) nil (41 . 45) nil ("i" . -41) ("t" . -42) ("y" . -43) (" " . -44) 45 nil (36 . 45) (35 . 37) nil ("[" . -35) ("]" . 36) nil (35 . 37) nil ("j" . -35) 36 nil (35 . 36) nil (21 . 35) nil ("
" . -21) 22 nil (21 . 22) 21 nil (1 . 22) nil ("# How to Contribute

" . 1) 21 nil ("Our community guidelines 
" . 21) nil ("## Follow Community Guidelines
" . 21) nil ("
" . 21) nil ("j" . -78) ("j" . -79) 80 nil (78 . 80) nil (74 . 78) nil (53 . 74) nil (52 . 53) 22 nil ("
" . 217) nil (199 . 200) nil ("
" . -199) 200 nil ("
" . 200) nil ("
" . 150) nil (132 . 133) nil ("
" . -132) 133 nil ("
" . 133) nil ("
" . 111) nil (93 . 94) nil ("
" . -93) 94 nil ("
" . 94) (t 25285 23367 959414 352000) nil ("
" . 555) nil (537 . 538) nil ("
" . -537) 538 nil ("
" . 538) nil ("
" . 516) nil (498 . 499) nil ("
" . -498) 499 nil ("
" . 499) nil ("
" . 474) nil (456 . 457) nil ("
" . -456) 457 nil ("
" . 457) nil (419 . 420) nil ("
" . -419) ("
" . -420) 421 nil (420 . 421) nil (375 . 376) nil ("
" . -375) 376 nil ("
" . 286) nil (268 . 269) nil ("
" . -268) 269 nil (315 . 316) nil (288 . 290) nil (" " . -288) 289 nil (288 . 289) nil ("." . -288) (" " . -289) (" " . -290) 291 nil ("
" . -316) 317 nil (316 . 317) nil ("
" . -316) 317 nil ("
" . 334) nil ("
" . 396) nil ("
" . 441) nil ("
" . 424) nil ("
" . 379) nil ("
" . 317) nil ("
" . 269) (t 25285 23066 885731 480000) nil ("
" . 570) (t 25285 23063 252273 410000) nil (556 . 562) nil (516 . 521) nil ("g" . -516) ("e" . -517) ("r" . -518) ("g" . -519) ("e" . -520) 521 nil (515 . 521) nil (471 . 477) nil (432 . 438) nil (386 . 392) nil (323 . 329) nil (" " . 280) nil (" " . 279) nil (274 . 282) nil ("
" . 73) nil ("### How to create an issue
" . 74) nil ("
" . 278) nil ("### How to submit a merge request
" . 279) nil (277 . 278) 254 nil (278 . 280) nil (nil rear-nonsticky nil 586 . 587) (nil fontified nil 278 . 587) (278 . 587) nil (277 . 278) 262 nil (242 . 243) nil (237 . 242) nil (170 . 174) nil ("u" . -170) ("e" . -171) 172 nil (168 . 172) nil (131 . 133) nil (127 . 131) nil (259 . 260) 259 nil (32 . 52) nil ("c" . -32) ("C" . -33) 34 nil (33 . 34) nil ("o" . -33) ("m" . -34) 35 nil (25 . 35) nil ("C" . -25) 26 nil (22 . 26) nil (21 . 22) nil (20 . 21) 1 nil (40 . 41) 25 nil (42 . 44) nil (nil rear-nonsticky nil 196 . 197) (nil fontified nil 41 . 197) (41 . 197) nil (40 . 41) 22 nil (88 . 91) nil ("c" . -88) ("c" . -89) ("e" . -90) 91 nil (79 . 91) nil ("G" . -79) 80 nil (76 . 80) nil (69 . 76) nil (67 . 69) nil (66 . 67) nil (45 . 66) nil ("C" . -45) 46 nil (43 . 46) nil (42 . 43) nil (nil rear-nonsticky nil 41 . 42) ("
" . -42) (41 . 43) nil ("
" . 22) nil (42 . 43) 42 nil ("#" . 25) nil ("## External Developers
" . 22) 41 nil (46 . 65) nil (45 . 46) nil (44 . 45) nil (" " . -44) 45 nil (43 . 45) nil (22 . 43) nil (21 . 22) nil ("
" . -21) 22 nil (21 . 22) nil (20 . 21) 20 nil (3 . 20) nil ("external contribution stuff here" . 3) (t 25278 31943 427876 905000) nil 35) (emacs-pending-undo-list (101 . 109)) (emacs-undo-equiv-table (73 . 75)))