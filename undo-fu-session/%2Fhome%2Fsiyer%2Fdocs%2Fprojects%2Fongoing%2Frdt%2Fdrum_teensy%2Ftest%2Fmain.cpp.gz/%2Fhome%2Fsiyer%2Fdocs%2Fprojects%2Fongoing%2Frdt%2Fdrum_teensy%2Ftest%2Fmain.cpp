((buffer-size . 319) (buffer-checksum . "25664ab9a18c58b48cef454f73f54446e16307d3"))
((emacs-buffer-undo-list nil ("#include<Servo.h>
#include \"PID.h\"
" . 21) ((marker . 153) . -2) ((marker . 192) . -18) ((marker . 21) . -17) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) ((marker . 21) . -2) 23 nil ("  //set_intervals(); // uncomment to start adjusting motor speeds dynamically
" . 264) ((marker . 192) . -78) ((marker* . 229) . 78) nil ("  if (Serial1.available() > 0) {
    val = Serial1.read();
    if (val != 0) {
      left_interval = val * 100; // this is baseline guess for first interval that will be adjusted later
      right_interval = val * 100; // this is baseline guess for first interval that will be adjusted later
    }
  }
 " . 264) ((marker . 153) . -302) ((marker . 153) . -302) ((marker . 229) . -302) ((marker . 229) . -302) ((marker) . -302) 566 nil ("  Serial1.begin(115200);
" . 126) ((marker . 153) . -2) ((marker . 192) . -25) 128 nil ("  right_wheel.attach(RIGHT_PIN);
" . 175) ((marker . 153) . -2) ((marker . 192) . -33) 177 nil ("  left_wheel.attach(LEFT_PIN);
" . 175) ((marker . 192) . -31) nil ("const int RIGHT_PIN  = 20;
" . 56) ((marker . 192) . -27) nil ("const int LEFT_PIN = 16;
" . 56) ((marker . 153) . -25) ((marker . 192) . -25) nil ("int val =  10; //0 - 100
int left_interval = 5000;
int right_interval = 5000;
int left_pastread = 0;
int right_pastread = 0;
int left_speed = val;
int right_speed = val;
bool setleft = false;
bool setright = false;
int difference = 0; // positive if left is ahead.
int magnum = 4; // magnets at 0, 90, 180, 270
int adjustmenttime = 300; // in milliseconds
float weightdiff = 0.7;
float weightinterval = 0.3;
float circum = 15.75 * 3.141592653;

float Kp = 1;
float Ki = 0.01;
float Kd = 0.01;
PID drum_pid(1,0.1,0.1,0.7,0.3);
Servo left_wheel;
Servo right_wheel;
" . 163) ((marker . 153) . -69) ((marker . 192) . -25) ((marker . 229) . -562) ((marker . 229) . -562) ((marker) . -562) nil ("  // run_cw(val);
" . 1349) ((marker . 153) . -18) ((marker . 192) . -18) nil (apply -3 1349 1367 undo--wrap-and-run-primitive-undo 1349 1367 ((1351 . 1354) 1349)) nil ("
// mapping values for actually turning the wheel
int getForward(int val)
{
  return map(val, -100, 100, 1000, 2000);
}
int getBackward(int val)
{
  return map(-val, -100, 100, 1000, 2000);
}

// lag of the magnets
void set_difference() {
  difference = left_pastread - right_pastread;
}

void set_intervals() {
  int current = millis();

  // Only set past_read and interval if larger than .8 of previous interval - don't set during streak of LOW or false LOW in the middle
  if (digitalRead(LEFT_SENSOR) == HIGH && (((float) (current - left_pastread) / left_interval ) > (0.8 / magnum)))  {
    // Only set interval when it's below 1.7x of the previous interval - i.e we didn't miss an interval
    if (((float) (current - left_pastread) / left_interval ) < (1.7 / magnum)) {
      left_interval = (current - left_pastread) * magnum;
      Serial.print(\"Left Update: \");
      // Serial.println(((float) left_interval) / 100);
    }
    // Record the past_read anyway to set the next interval
    left_pastread = current;
    setleft = true;
  }

  if (digitalRead(RIGHT_SENSOR) == HIGH && (((float) (current - right_pastread) / right_interval ) > (0.8 / magnum))) {
    if (((float) (current - right_pastread) / right_interval ) < (1.7 / magnum)) {
      right_interval = (current - right_pastread) * magnum;
      Serial.print(\"Right Update: \");
      // Serial.println(((float) right_interval / 100));
    }
    right_pastread = current;
    setright = true;
  }
  if (setright && setleft) {
    Serial.println(\"Updated\");
    set_difference();
    setleft = false;
    setright = false;
  }
}

// reduce errors for both speed and positioning of magnets and adjust weights of each error
// we could make a pid controller, but it may be too much for the teensy (need to keep lots of points in memory)
// it would be nice to make a switching pid controller based on both of these errors
void setspeeds() {
  // adjust based on difference in magnet positioning
  float speed_decrease = drum_pid.update(difference, (right_interval - left_interval));
  if (speed_decrease > 0) {
    left_speed -= (int) speed_decrease;
  }
  else {
    right_speed += (int) speed_decrease;
  }
  /*
  Serial.print(\"speed_decrease: \");
  Serial.println(speed_decrease);
  Serial.print(\"pos_difference: \");
  Serial.println(difference);
  Serial.println(\"speed_difference \");
  Serial.println(right_interval - left_interval);
  */
}

// wheels running function
void run_cw(int val)
{
  setspeeds();
  left_wheel.writeMicroseconds(getForward(left_speed));
  right_wheel.writeMicroseconds(getBackward(right_speed));
}
void run_ccw(int val)
{
  setspeeds();
  left_wheel.writeMicroseconds(getBackward(left_speed));
  right_wheel.writeMicroseconds(getForward(right_speed));
}

" . 933) ((marker . 192) . -1) ((marker . 229) . -2753) ((marker . 229) . -2753) ((marker) . -2753) (t 24694 26329 801916 646000) nil (21 . 3687) nil ("#include<Servo.h>
#include \"PID.h\"
const int LEFT_PIN = 16;
const int RIGHT_PIN  = 20;
const int LEFT_SENSOR = 6;
const int RIGHT_SENSOR = 5;
int val =  10; //0 - 100
int left_interval = 5000;
int right_interval = 5000;
int left_pastread = 0;
int right_pastread = 0;
int left_speed = val;
int right_speed = val;
bool setleft = false;
bool setright = false;
int difference = 0; // positive if left is ahead.
int magnum = 4; // magnets at 0, 90, 180, 270
int adjustmenttime = 300; // in milliseconds
float weightdiff = 0.7;
float weightinterval = 0.3;
float circum = 15.75 * 3.141592653;

float Kp = 1;
float Ki = 0.01;
float Kd = 0.01;
PID drum_pid(1,0.1,0.1,0.7,0.3);
Servo left_wheel;
Servo right_wheel;
void setup() {
  Serial1.begin(115200);
  Serial.begin(115200);
  left_wheel.attach(LEFT_PIN);
  right_wheel.attach(RIGHT_PIN);
  pinMode(LEFT_SENSOR, INPUT_PULLUP);
  pinMode(RIGHT_SENSOR, INPUT_PULLUP);
}

// mapping values for actually turning the wheel
int getForward(int val)
{
  return map(val, -100, 100, 1000, 2000);
}
int getBackward(int val)
{
  return map(-val, -100, 100, 1000, 2000);
}

// lag of the magnets
void set_difference() {
  difference = left_pastread - right_pastread;
}

void set_intervals() {
  int current = millis();

  // Only set past_read and interval if larger than .8 of previous interval - don't set during streak of LOW or false LOW in the middle
  if (digitalRead(LEFT_SENSOR) == HIGH && (((float) (current - left_pastread) / left_interval ) > (0.8 / magnum)))  {
    // Only set interval when it's below 1.7x of the previous interval - i.e we didn't miss an interval
    if (((float) (current - left_pastread) / left_interval ) < (1.7 / magnum)) {
      left_interval = (current - left_pastread) * magnum;
      Serial.print(\"Left Update: \");
      // Serial.println(((float) left_interval) / 100);
    }
    // Record the past_read anyway to set the next interval
    left_pastread = current;
    setleft = true;
  }

  if (digitalRead(RIGHT_SENSOR) == HIGH && (((float) (current - right_pastread) / right_interval ) > (0.8 / magnum))) {
    if (((float) (current - right_pastread) / right_interval ) < (1.7 / magnum)) {
      right_interval = (current - right_pastread) * magnum;
      Serial.print(\"Right Update: \");
      // Serial.println(((float) right_interval / 100));
    }
    right_pastread = current;
    setright = true;
  }
  if (setright && setleft) {
    Serial.println(\"Updated\");
    set_difference();
    setleft = false;
    setright = false;
  }
}

// reduce errors for both speed and positioning of magnets and adjust weights of each error
// we could make a pid controller, but it may be too much for the teensy (need to keep lots of points in memory)
// it would be nice to make a switching pid controller based on both of these errors
void setspeeds() {
  // adjust based on difference in magnet positioning
  float speed_decrease = drum_pid.update(difference, (right_interval - left_interval));
  if (speed_decrease > 0) {
    left_speed -= (int) speed_decrease;
  }
  else {
    right_speed += (int) speed_decrease;
  }
  /*
  Serial.print(\"speed_decrease: \");
  Serial.println(speed_decrease);
  Serial.print(\"pos_difference: \");
  Serial.println(difference);
  Serial.println(\"speed_difference \");
  Serial.println(right_interval - left_interval);
  */
}

// wheels running function
void run_cw(int val)
{
  setspeeds();
  left_wheel.writeMicroseconds(getForward(left_speed));
  right_wheel.writeMicroseconds(getBackward(right_speed));
}
void run_ccw(int val)
{
  setspeeds();
  left_wheel.writeMicroseconds(getBackward(left_speed));
  right_wheel.writeMicroseconds(getForward(right_speed));
}

" . 21) ((marker . 153) . -3392) ((marker . 153) . -3665) ((marker . 1) . -3044) ((marker . 153) . -3665) ((marker . 192) . -3666) ((marker . 229) . -3665) ((marker . 229) . -3665) ((marker) . -3665) 3686 (t 24694 26329 801916 646000)) (emacs-pending-undo-list . t) (emacs-undo-equiv-table (13 . t)))