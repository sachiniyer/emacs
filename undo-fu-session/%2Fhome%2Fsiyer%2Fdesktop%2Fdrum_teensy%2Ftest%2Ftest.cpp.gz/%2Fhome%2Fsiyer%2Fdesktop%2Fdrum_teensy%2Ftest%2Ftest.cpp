((buffer-size . 2161) (buffer-checksum . "f5e863d87d53f6a015006104635fc7d3489316b4"))
((emacs-buffer-undo-list nil ("
" . 21) ((marker . 21) . -1) ((marker . 65) . -1) nil (19 . 20) nil (10 . 19) nil (9 . 10) nil (2 . 9) nil (1 . 2) nil (1 . 3) (t 24685 9493 334259 304000)) (emacs-pending-undo-list (18287 . 19284) ("(custom-set-faces
 ;; custom-set-faces was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(highlight-indentation-face ((t nil)))
 '(telephone-line-evil-emacs ((t (:inherit telephone-line-evil :background \"#6B134F\"))))
 '(telephone-line-evil-god ((t (:inherit telephone-line-evil :background \"#275791\"))))
 '(telephone-line-evil-insert ((t (:inherit telephone-line-evil :background \"#3F5F3F\"))))
 '(telephone-line-evil-motion ((t (:inherit telephone-line-evil :background \"#366060\"))))
 '(telephone-line-evil-normal ((t (:inherit telephone-line-evil :background \"#7C4343\"))))
 '(telephone-line-evil-operator ((t (:inherit telephone-line-evil :background \"#8A690B\"))))
 '(telephone-line-evil-replace ((t (:inherit telephone-line-evil :background \"#656555\"))))
 '(telephone-line-evil-visual ((t (:inherit telephone-line-evil :background \"#A1501B\")))))" . -18287) (18243 . 18286) (18222 . 18225) (18199 . 18202) (18176 . 18179) (18153 . 18156) (18130 . 18133) (18107 . 18110) (18084 . 18087) (18061 . 18064) (18038 . 18041) (18015 . 18018) (17992 . 17995) (17969 . 17972) (17946 . 17949) (17923 . 17926) (17901 . 17904) (17879 . 17882) (17857 . 17860) ("
" . -18192) (18172 . 18174) (18152 . 18154) (18132 . 18134) (18112 . 18114) (18092 . 18094) (18072 . 18074) (18052 . 18054) (18032 . 18034) (18012 . 18014) (17992 . 17994) (17972 . 17974) (17952 . 17954) (17932 . 17934) (17912 . 17914) (17893 . 17895) (17874 . 17876) (17855 . 17857) (18158 . 18159) (18139 . 18140) ("
" . 18139) (18139 . 18140) (" " . -18139) (18121 . 18122) ("
" . 18121) (18121 . 18122) (" " . -18121) (18103 . 18104) ("
" . 18103) (18103 . 18104) (" " . -18103) (18085 . 18086) ("
" . 18085) (18085 . 18086) (" " . -18085) (18067 . 18068) ("
" . 18067) (18067 . 18068) (" " . -18067) (18049 . 18050) ("
" . 18049) (18049 . 18050) (" " . -18049) (18031 . 18032) ("
" . 18031) (18031 . 18032) (" " . -18031) (18013 . 18014) ("
" . 18013) (18013 . 18014) (" " . -18013) (17995 . 17996) ("
" . 17995) (17995 . 17996) (" " . -17995) (17977 . 17978) ("
" . 17977) (17977 . 17978) (" " . -17977) (17959 . 17960) ("
" . 17959) (17959 . 17960) (" " . -17959) (17941 . 17942) ("
" . 17941) (17941 . 17942) (" " . -17941) (17923 . 17924) ("
" . 17923) (17923 . 17924) (" " . -17923) (17905 . 17906) ("
" . 17905) (17905 . 17906) (" " . -17905) (17888 . 17889) ("
" . 17888) (17888 . 17889) (" " . -17888) (17871 . 17872) ("
" . 17871) (17871 . 17872) (" " . -17871) (17854 . 17855) ("
" . 17854) (17854 . 17855) (" " . -17854) (17832 . 18158) (" " . 17832) (17211 . 17833) ("
" . -17211) (5306 . 17212) (" " . 5306) (4957 . 5307) ("
" . -4957) (4873 . 4958) (" " . 4873) (4686 . 4874) ("
" . -4686) (4600 . 4687) (" " . 4600) (4575 . 4601) (4562 . 4565) (4515 . 4518) (4504 . 4507) (4483 . 4486) (4458 . 4461) (4447 . 4450) (4434 . 4437) (4415 . 4418) (4404 . 4407) (4353 . 4356) ("
" . -4545) (4532 . 4535) (4488 . 4491) (4481 . 4483) (4462 . 4465) (4440 . 4443) (4433 . 4435) (4422 . 4425) (4406 . 4409) (4399 . 4401) (4351 . 4353) (4519 . 4520) (4508 . 4509) (" " . -4508) (4467 . 4468) (" " . 4467) (4462 . 4463) ("
" . 4462) (4462 . 4463) (" " . -4462) (4446 . 4447) (" " . -4446) (4427 . 4428) (" " . 4427) (4422 . 4423) ("
" . 4422) (4422 . 4423) (" " . -4422) (4414 . 4415) (" " . -4414) (4401 . 4402) (" " . 4401) (4396 . 4397) ("
" . 4396) (4396 . 4397) (" " . -4396) (4350 . 4351) ("
" . 4350) (4350 . 4351) (" " . -4350) (4308 . 4519) (" " . 4308) (4283 . 4309) (4235 . 4238) (4188 . 4191) (4137 . 4140) ("
" . -4274) (4227 . 4229) (4183 . 4185) (4135 . 4137) (4268 . 4269) (4222 . 4223) ("
" . 4222) (4222 . 4223) (" " . -4222) (4180 . 4181) ("
" . 4180) (4180 . 4181) (" " . -4180) (4134 . 4135) ("
" . 4134) (4134 . 4135) (" " . -4134) (4085 . 4268) (" " . 4085) (4058 . 4086) ("
" . -4058) (3959 . 4059) (" " . 3959) (3837 . 3960) (3786 . 3789) (3715 . 3718) (3647 . 3650) (3557 . 3560) (3492 . 3495) (3418 . 3421) (3319 . 3322) ("
" . -3816) (3766 . 3768) (3698 . 3700) (3633 . 3635) (3546 . 3548) (3484 . 3486) (3413 . 3415) (3317 . 3319) (3802 . 3803) (3753 . 3754) ("
" . 3753) (3753 . 3754) (" " . -3753) (3687 . 3688) ("
" . 3687) (3687 . 3688) (" " . -3687) (3624 . 3625) ("
" . 3624) (3624 . 3625) (" " . -3624) (3539 . 3540) ("
" . 3539) (3539 . 3540) (" " . -3539) (3479 . 3480) ("
" . 3479) (3479 . 3480) (" " . -3479) (3410 . 3411) ("
" . 3410) (3410 . 3411) (" " . -3410) (3316 . 3317) ("
" . 3316) (3316 . 3317) (" " . -3316) (3236 . 3802) (" " . 3236) (3203 . 3237) (3141 . 3144) (3035 . 3038) ("
" . -3197) (3136 . 3138) (3033 . 3035) (3193 . 3194) (3133 . 3134) ("
" . 3133) (3133 . 3134) (" " . -3133) (3032 . 3033) ("
" . 3032) (3032 . 3033) (" " . -3032) (2938 . 3193) (" " . 2938) (2097 . 2939) ("
" . -2097) (1884 . 2098) (" " . 1884) (1783 . 1885) (1739 . 1742) (1722 . 1725) (1711 . 1714) (1689 . 1692) (1615 . 1618) ("
" . -1768) (1724 . 1727) (1710 . 1713) (1701 . 1705) (1682 . 1686) (1612 . 1615) (1751 . 1752) (1709 . 1710) (" " . 1709) (1698 . 1699) (" " . -1698) (1693 . 1694) (" " . -1693) (1678 . 1679) (" " . 1678) (1611 . 1612) (" " . 1611) (1594 . 1751) (" " . 1594) (1517 . 1595) ("
" . -1517) (900 . 1518) (" " . 900) (569 . 901) ("
" . -569) (484 . 570) (" " . 484) (456 . 485) ("
" . -456) (388 . 457) (" " . 388) (117 . 389) ("(custom-set-variables
 ;; custom-set-variables was added by Custom.
 ;; If you edit it by hand, you could mess it up, so be careful.
 ;; Your init file should contain only one such instance.
 ;; If there is more than one, they won't work right.
 '(ansi-color-faces-vector
   [default default default italic underline success warning error])
 '(ansi-color-names-vector
   [\"#212526\" \"#ff4b4b\" \"#b4fa70\" \"#fce94f\" \"#729fcf\" \"#e090d7\" \"#8cc4ff\" \"#eeeeec\"])
 '(async-shell-command-buffer 'new-buffer)
 '(company-quickhelp-color-background \"#4F4F4F\")
 '(company-quickhelp-color-foreground \"#DCDCCC\")
 '(confirm-kill-emacs 'yes-or-no-p)
 '(cua-highlight-region-shift-only t)

 '(cua-remap-control-v nil)
 '(cua-remap-control-z nil)
 '(custom-enabled-themes '(zenburn))
 '(custom-safe-themes
   '(\"a27c00821ccfd5a78b01e4f35dc056706dd9ede09a8b90c6955ae6a390eb1c1e\" \"13bfd13e75a5f873db41919fa793c5422bfcd5e1cd78587158c06acbe8e49789\" \"fa2b58bb98b62c3b8cf3b6f02f058ef7827a8e497125de0254f56e373abee088\" \"bffa9739ce0752a37d9b1eee78fc00ba159748f50dc328af4be661484848e476\" \"2074a98e21377af1c50897d4330caca2b719542bcdf9618ed3c1575c99b41363\" \"6343f4d41b209fe8990e3c5f4d2040b359612ef9cd8682f1e1e2a836beba8107\" \"4e5e58e42f6f37920b95a8502f488928b3dab9b6cc03d864e38101ce36ecb968\" \"4639288d273cbd3dc880992e6032f9c817f17c4a91f00f3872009a099f5b3f84\" \"3a58d06b485e0dda454dac9f40884b2677fe9582f34b3f5587b7d75505aa4d09\" default))
 '(custom-theme-directory \"~/.emacs.d/themes\")
 '(display-time-string-forms
   '((propertize
      (concat dayname \" \" day \" \" monthname \" \" 12-hours \":\" minutes \" \"
	      (upcase am-pm)
	      \" \")
      'help-echo
      (format-time-string \"%a, %b %e %Y\" now))))
 '(eclim-executable \"/home/siyer/eclipse/java-2020-12/eclipse/plugins/\")
 '(ede-project-directories
   '(\"/home/siyer/docs/projects/Arduino/Electric_Trombone/Code_2\" \"/home/siyer/docs/projects/Arduino/foot_pedal/code_1\" \"/home/siyer/docs/coding/Python/env/projects/web_automation/delivery-service\" \"/home/siyer\"))
 '(eimp-mogrify-program \"/usr/bin/mogrify\")
 '(ein:jupyter-default-notebook-directory \"~/docs/coding/Python/env\")
 '(ein:jupyter-default-server-command \"~/docs/coding/Python/env/bin/jupyter\")
 '(ein:jupyter-server-command \"~/docs/coding/Python/env/bin/jupyter\")
 '(elpy-rpc-python-command \"~/docs/coding/Python/env/bin/python\")
 '(elpy-rpc-virtualenv-path \"~/docs/coding/Python/env2/\")
 '(evil-move-cursor-back nil)
 '(evil-undo-system 'undo-fu)
 '(evil-want-fine-undo t)
 '(fci-rule-color \"#383838\")
 '(helm-minibuffer-history-key \"M-p\")
 '(inferior-lisp-program \"/usr/local/sbcl\")
 '(initial-major-mode 'org-mode)
 '(js3-auto-indent-p t)
 '(lisp-mode-hook '(slime-lisp-mode-hook))
 '(mailcap-user-mime-data '((\"\" \"image/*;
 open -a Preview %s\" nil)))
 '(message-send-mail-function 'message-send-mail-with-sendmail)
 '(newsticker-url-list
   '((\"newyorktimes\" \"https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml\" nil nil nil)
     (\"fullnyt\" \"https://morss.it/https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml\" nil nil nil)
     (\"the daily\" \"http://rss.art19.com/the-daily\" nil nil nil)))
 '(newsticker-url-list-defaults
   '((\"Debian Security Advisories\" \"http://www.debian.org/security/dsa.en.rdf\")
     (\"Debian Security Advisories - Long format\" \"http://www.debian.org/security/dsa-long.en.rdf\")
     (\"Emacs Wiki\" \"https://www.emacswiki.org/emacs?action=rss\" nil 3600)
     (\"LWN (Linux Weekly News)\" \"https://lwn.net/headlines/rss\")
     (\"Quote of the day\" \"http://feeds.feedburner.com/quotationspage/qotd\" \"07:00\" 86400)
     (\"The Register\" \"https://www.theregister.co.uk/headlines.rss\")
     (\"slashdot\" \"http://rss.slashdot.org/Slashdot/slashdot\" nil 3600)
     (\"Wired News\" \"https://www.wired.com/feed/rss\")))
 '(notmuch-address-internal-completion '(received nil))
 '(notmuch-command \"/usr/bin/notmuch\")
 '(notmuch-hello-sections
   '(notmuch-hello-insert-header notmuch-hello-insert-saved-searches notmuch-hello-insert-alltags))
 '(notmuch-saved-searches
   '((:name \"inbox\" :query \"tag:inbox\" :key \"i\")
     (:name \"unread\" :query \"tag:unread\" :key \"u\")
     (:name \"sent\" :query \"tag:sent\" :key \"t\")
     (:name \"drafts\" :query \"tag:draft\" :key \"d\")))
 '(notmuch-tagging-keys
   '((\"a\" notmuch-archive-tags \"Archive\")
     (\"u\" notmuch-show-mark-read-tags \"Mark read\")
     (\"f\"
      (\"+flagged\")
      \"Flag\")
     (\"s\"
      (\"+spam\" \"-inbox\")
      \"Mark as spam\")
     (\"d\"
      (\"+deleted\" \"-inbox\" \"+trash\" \"-unread\")
      \"Delete\")))
 '(nrepl-message-colors
   '(\"#CC9393\" \"#DFAF8F\" \"#F0DFAF\" \"#7F9F7F\" \"#BFEBBF\" \"#93E0E3\" \"#94BFF3\" \"#DC8CC3\"))
 '(org-agenda-files '(\"~/docs/todo\"))
 '(org-babel-python-command \"python3\")
 '(org-babel-python-mode 'ipython)
 '(org-fontify-whole-heading-line t)
 '(org-html-table-default-attributes
   '(:border \"2\" :cellspacing \"2\" :cellpadding \"6\" :rules \"groups\" :frame \"border\"))
 '(org-indent-indentation-per-level 4)
 '(org-log-done 'note)
 '(org-log-done-with-time nil)
 '(org-pandoc-command \"/usr/bin/pandoc\")
 '(org-startup-align-all-tables t)
 '(org-startup-folded 'content)
 '(org-support-shift-select 'always)
 '(org-trello-current-prefix-keybinding \"C-c o\")
 '(package-check-signature nil)
 '(package-selected-packages
   '(arch-packer arduino-cli-mode aurel aws-ec2 aws-snippets awscli-capf axe cpu-sos edit-color-stamp function-args geoip geolocation git-commit gnomenm hackernews howdoyou mw-thesaurus nnreddit nntwitter pacmacs shrink-path slack sudo-edit sudo-ext sudo-utils twittering-mode ytdl dashboard-hackernews all-the-icons all-the-icons-dired all-the-icons-gnus all-the-icons-ibuffer all-the-icons-ivy all-the-icons-ivy-rich messages-are-flowing undo-fu undo-fu-session undo-propose undohist undo-tree treemacs-evil powerline-evil evil-org evil-tex thingopt emms xkcd telephone-line pdf-view-restore symon npm-mode goto-line-preview color-identifiers-mode dashboard page-break-lines fish-completion fish-mode volume indium manage-minor-mode elpy python-mode pyvenv dired-git-info define-word sclang-extensions sclang-snippets apples-mode applescript-mode eimp vimish-fold aggressive-indent flycheck-swiftx ob-swift swift-helpful swift-mode swift-playground-mode swift3-mode multi-vterm typit springboard ## rainbow-mode railscasts-reloaded-theme railscasts-theme xref-js2 js-format js-react-redux-yasnippets js2-closure js2-highlight-vars js2-mode json js2-refactor ido-at-point ido-better-flex ido-clever-match ido-complete-space-or-hyphen ido-completing-read+ ido-describe-bindings ido-exit-target ido-flex-with-migemo ido-gnus ido-grid-mode ido-hacks ido-load-library ido-migemo ido-occasional ido-occur ido-select-window ido-skk ido-sort-mtime ido-ubiquitous ido-vertical-mode ido-yes-or-no idomenu ibuffer-git ibuffer-project ibuffer-projectile ibuffer-rcirc ibuffer-sidebar ibuffer-tramp ibuffer-vc vterm vterm-toggle vlf bash-completion conda copyit copyit-pandoc crux dired-atool dired-collapse dired-dups dired-efap dired-explorer dired-filetype-face dired-filter dired-git dired-hacks-utils dired-imenu dired-k dired-launch dired-nav-enhance dired-open dired-quick-sort dired-rainbow dired-recent dired-rmjunk dired-rsync dired-sidebar dired-single dired-subtree dired-toggle dired-toggle-sudo diredfl diredful direnv dirtree dotenv-mode drag-stuff egg ein-mumamo elpygen buffer-flip buffer-manage buffer-move buffer-sets buffer-utils ein mew pandoc pandoc-mode helm-bibtex helm-fd helm-zhihu-daily xwidgete company-anaconda company-ansible company-arduino company-auctex company-axiom company-bibtex company-c-headers company-cabal company-childframe company-coq company-dcd company-dict company-distel company-ebdb company-edbi company-emacs-eclim company-emoji company-erlang company-flow company-flx company-fuzzy company-ghc company-ghci company-glsl company-go company-inf-ruby company-irony company-irony-c-headers company-jedi company-lean company-lsp company-lua company-math company-nand2tetris company-nginx company-ngram company-nixos-options company-php company-phpactor company-plsense company-pollen company-posframe company-prescient company-qml company-quickhelp company-racer company-reftex company-restclient company-rtags company-shell company-solidity company-sourcekit company-statistics company-suggest company-tabnine company-tern company-terraform company-try-hard company-web company-ycm company-ycmd gradle-mode ag cider clojure-mode counsel less-css-mode bongo emms-soundcloud flycheck-ameba flycheck-apertium flycheck-ats2 flycheck-bashate flycheck-cask flycheck-checkbashisms flycheck-checkpatch flycheck-clang-analyzer flycheck-clang-tidy flycheck-clangcheck flycheck-clj-kondo flycheck-clojure flycheck-clolyze flycheck-color-mode-line flycheck-coverity flycheck-credo flycheck-crystal flycheck-css-colorguard flycheck-cstyle flycheck-cython flycheck-d-unittest flycheck-dedukti flycheck-demjsonlint flycheck-dialyxir flycheck-dialyzer flycheck-dogma flycheck-dtrace flycheck-elixir flycheck-elm flycheck-elsa flycheck-ensime flycheck-flawfinder flycheck-flow flycheck-ghcmod flycheck-golangci-lint flycheck-gometalinter flycheck-gradle flycheck-grammalecte flycheck-haskell flycheck-hdevtools flycheck-indicator flycheck-ini-pyinilint flycheck-inline flycheck-irony flycheck-jest flycheck-joker flycheck-julia flycheck-kotlin flycheck-ledger flycheck-lilypond flycheck-liquidhs flycheck-mercury flycheck-mix flycheck-mmark flycheck-mypy flycheck-nim flycheck-nimsuggest flycheck-objc-clang flycheck-ocaml flycheck-package flycheck-pact flycheck-perl6 flycheck-phpstan flycheck-pkg-config flycheck-plantuml flycheck-pony flycheck-popup-tip flycheck-pos-tip flycheck-posframe flycheck-prospector flycheck-purescript flycheck-pycheckers flycheck-pyflakes flycheck-pyre flycheck-rebar3 flycheck-rtags flycheck-rust flycheck-soar flycheck-stack flycheck-status-emoji flycheck-swift flycheck-swift3 flycheck-swiftlint flycheck-tcl flycheck-tip flycheck-title flycheck-vale flycheck-vdm flycheck-xcode flycheck-yamllint flycheck-yang flycheck-ycmd git-auto-commit-mode git-command git-io git-lens git-link git-messenger git-timemachine gitconfig gitconfig-mode github-browse-file github-clone github-elpa github-explorer github-issues github-modern-theme github-notifier github-pullrequest github-review github-search github-stars gitignore-mode gitignore-templates gitlab gitlab-ci-mode gitlab-ci-mode-flycheck gitolite-clone helm helm-R helm-ack helm-ad helm-addressbook helm-ag helm-ag-r helm-aws helm-backup helm-bbdb helm-bibtexkey helm-bind-key helm-bitbucket helm-bm helm-books helm-bundle-show helm-c-moccur helm-c-yasnippet helm-catkin helm-charinfo helm-chrome helm-chrome-control helm-chrome-history helm-chronos helm-cider helm-cider-history helm-circe helm-clojuredocs helm-cmd-t helm-codesearch helm-commandlinefu helm-company helm-core helm-cscope helm-css-scss helm-ctest helm-dash helm-descbinds helm-describe-modes helm-dictionary helm-directory helm-dired-history helm-dired-recent-dirs helm-dirset helm-elscreen helm-emmet helm-emms helm-esa helm-etags-plus helm-evil-markers helm-eww helm-ext helm-exwm helm-file-preview helm-filesets helm-firefox helm-flx helm-flycheck helm-flymake helm-flyspell helm-frame helm-fuz helm-fuzzier helm-fuzzy helm-fuzzy-find helm-ghc helm-ghq helm-ghs helm-git helm-git-files helm-git-grep helm-github-stars helm-gitignore helm-gitlab helm-go-package helm-google helm-grepint helm-growthforecast helm-gtags helm-hatena-bookmark helm-hayoo helm-helm-commands helm-hoogle helm-hunks helm-idris helm-img helm-img-tiqav helm-itunes helm-j-cheatsheet helm-jira helm-js-codemod helm-jstack helm-kythe helm-lastpass helm-lean helm-lib-babel helm-lines helm-lobsters helm-ls-git helm-ls-hg helm-ls-svn helm-lxc helm-make helm-migemo helm-mode-manager helm-mt helm-mu helm-navi helm-nixos-options helm-notmuch helm-open-github helm-org helm-org-rifle helm-orgcard helm-osx-app helm-pages helm-pass helm-perldoc helm-perspeen helm-phpunit helm-posframe helm-proc helm-project-persist helm-projectile helm-prosjekt helm-pt helm-purpose helm-pydoc helm-qiita helm-rage helm-rails helm-rb helm-rdefs helm-recoll helm-rg helm-rhythmbox helm-robe helm-ros helm-rtags helm-rubygems-local helm-rubygems-org helm-safari helm-sage helm-selected helm-sheet helm-slime helm-smex helm-spaces helm-spotify helm-spotify-plus helm-sql-connect helm-swoop helm-system-packages helm-systemd helm-tail helm-taskswitch helm-themes helm-tramp helm-unicode helm-w32-launcher helm-w3m helm-wordnet helm-xcdoc helm-youtube helm-z help-find-org-mode helpful ivy-todo ivy-youtube java-imports jquery-doc js-auto-beautify js-auto-format-mode js-codemod js-import js3-mode jscs json-navigator json-process-client json-reformatter-jq json-rpc json-rpc-server jsonl jsonnet-mode jupyter live-py-mode magit-annex magit-circleci magit-diff-flycheck magit-filenotify magit-find-file magit-gerrit magit-gh-pulls magit-gitflow magit-lfs magit-org-todos magit-p4 magit-rbr magit-reviewboard magit-stgit magit-svn magit-topgit magit-vcsh magithub malinka marcopolo markless markup math-symbols multi multi-compile multi-line multi-project multi-run multi-web-mode multicolumn multifiles multishell neotree oauth oauth2 org-ac org-agenda-property org-alert org-analyzer org-attach-screenshot org-autolist org-beautify-theme org-board org-bookmark-heading org-capture-pop-frame org-cliplink org-clock-convenience org-clock-csv org-clock-today org-commentary org-context org-cua-dwim org-d20 org-dashboard org-doing org-dotemacs org-dp org-drill-table org-dropbox org-easy-img-insert org-edit-latex org-edna org-ehtml org-elisp-help org-emms org-evil org-onenote org-picklink orgalist origami osc osx-browse osx-dictionary osx-lib osx-trash outline-toc outlook outorg ox-asciidoc ox-epub ox-html5slide ox-impress-js ox-ioslide ox-mdx-deck ox-mediawiki ox-minutes ox-nikola ox-pandoc ox-pukiwiki ox-slack ox-slimhtml ox-tufte ox-wk pcmpl-git pcmpl-homebrew pcmpl-pip playerctl poly-org pyenv-mode pyenv-mode-auto pyimport pyimpsort pytest python-cell python-docstring python-environment python-info python-pytest python-switch-quotes python-test python-x scheme-complete search-web sound-wav soundcloud soundklaus ssh ssh-tunnels travis tree-mode treemacs-icons-dired treemacs-magit treepy xcode-mode xcode-project helm-ispell ac-c-headers ac-capf ac-cider ac-clang ac-dcd ac-emacs-eclim ac-emmet ac-emoji ac-etags ac-geiser ac-helm ac-html ac-html-angular ac-html-bootstrap ac-html-csswatcher ac-inf-ruby ac-ispell ac-js2 ac-math ac-octave ac-php ac-php-core ac-sly ace-flyspell ace-isearch ace-jump-buffer ace-jump-helm-line ace-jump-mode ace-jump-zap ace-link ace-mc ace-popup-menu add-hooks anaconda-mode android-env android-mode angular-mode angular-snippets anki-editor anki-mode auto-package-update web-narrow-mode web-mode-edit-element web-completion-data web-beautify use-package-hydra use-package-ensure-system-package use-package-el-get use-package-chords otama orgtbl-show-header orgtbl-join orgtbl-ascii-plot orgtbl-aggregate orgnav orgbox org2web org2jekyll org2issue org2elcomment org-wunderlist org-web-tools org-wc org-trello org-tree-slide org-transform-tree-table org-tracktable org-toodledo org-timeline org-time-budgets org-themis org-tfl org-table-comment org-sync-snippets org-sync org-sticky-header org-starter-swiper org-sql org-snooze org-shoplist org-send-ebook org-seek org-rtm org-rich-yank org-review org-repo-todo org-redmine org-recur org-randomnote org-random-todo org-radiobutton org-protocol-jekyll org-projectile-helm org-preview-html org-present-remote org-pomodoro org-password-manager org-parser org-page org-outlook org-outline-numbering org-octopress org-notebook org-multiple-keymap org-mobile-sync org-mind-map org-lookup-dnd org-listcruncher org-linkany org-link-travis org-link-minor-mode org-kindle org-journal-list org-iv org-if org-grep org-gnome org-fancy-priorities org-bullets evil-visualstar evil-visual-replace evil-visual-mark-mode evil-vimish-fold evil-tutor-ja evil-traces evil-textobj-syntax evil-textobj-line evil-textobj-entire evil-textobj-column evil-textobj-anyblock evil-text-object-python evil-test-helpers evil-terminal-cursor-changer evil-tabs evil-swap-keys evil-string-inflection evil-space evil-smartparens evil-search-highlight-persist evil-ruby-text-objects evil-rsi evil-replace-with-register evil-replace-with-char evil-rails evil-quickscope evil-python-movement evil-paredit evil-owl evil-opener evil-nl-break-undo evil-nerd-commenter evil-multiedit evil-mu4e evil-mc-extras evil-matchit evil-mark-replace evil-magit evil-lispy evil-lisp-state evil-lion evil-ledger evil-leader evil-indent-textobject evil-indent-plus evil-iedit-state evil-goggles evil-god-state evil-fringe-mark evil-find-char-pinyin evil-extra-operator evil-expat evil-exchange evil-ex-shell-command evil-ex-fasd evil-escape evil-embrace evil-ediff evil-easymotion evil-dvorak evil-commentary evil-collection evil-colemak-minimal evil-colemak-basics evil-cleverparens evil-better-visual-line evil-avy evil-args evil-anzu dockerfile-mode docker-compose-mode docker-cli docker-api docker auto-complete-sage auto-complete-rst auto-complete-pcmp auto-complete-nxml auto-complete-exuberant-ctags auto-complete-distel auto-complete-clang-async auto-complete-clang auto-complete-chunk auto-complete-c-headers auto-complete-auctex auto-compile auto-auto-indent))
 '(pandoc-binary \"/usr/bin/pandoc\")
 '(pdf-view-midnight-colors '(\"#DCDCCC\" . \"#383838\"))
 '(python-shell-completion-native-disabled-interpreters '(\"pypy\" \"ipython\" \"python\"))
 '(python-shell-interpreter \"/home/siyer/docs/coding/Python/env/bin/ipython3\")
 '(python-shell-virtualenv-root \"~/docs/coding/Python/env/\")
 '(pyvenv-virtualenvwrapper-python \"~/docs/coding/Python/env/bin/python\")
 '(read-mail-command 'notmuch)
 '(send-mail-function 'mailclient-send-it)
 '(sml/name-width 20)
 '(smtpmail-smtp-server \"smtp.gmail.com\")
 '(smtpmail-smtp-service 587)
 '(vc-annotate-background \"#2B2B2B\")
 '(vc-annotate-color-map
   '((20 . \"#BC8383\")
     (40 . \"#CC9393\")
     (60 . \"#DFAF8F\")
     (80 . \"#D0BF8F\")
     (100 . \"#E0CF9F\")
     (120 . \"#F0DFAF\")
     (140 . \"#5F7F5F\")
     (160 . \"#7F9F7F\")
     (180 . \"#8FB28F\")
     (200 . \"#9FC59F\")
     (220 . \"#AFD8AF\")
     (240 . \"#BFEBBF\")
     (260 . \"#93E0E3\")
     (280 . \"#6CA0A3\")
     (300 . \"#7CB8BB\")
     (320 . \"#8CD0D3\")
     (340 . \"#94BFF3\")
     (360 . \"#DC8CC3\")))
 '(vc-annotate-very-old-color \"#DC8CC3\"))" . -117) nil (apply 2 25716 25732 undo--wrap-and-run-primitive-undo 25716 25732 ((";;" . -25716) 25725)) nil (25734 . 25746) ("


;;haskell" . 25734) nil (apply 2 25599 25715 undo--wrap-and-run-primitive-undo 25599 25715 ((";;" . -25599) ((marker . 25781) . -2) ((marker . 25781) . -2) ((marker . 25648) . -2) 25696)) nil (apply 2 25501 25598 undo--wrap-and-run-primitive-undo 25501 25598 ((";;" . -25501) 25600)) nil (25701 . 25704) nil ("6" . -25701) ("." . -25702) ("1" . -25703) 25704 nil (25689 . 25692) nil ("6" . -25689) ("." . -25690) ("1" . -25691) 25692 nil ("
" . 25719) nil (25719 . 25720) 25692 nil (25584 . 25587) nil ("6" . -25584) ("." . -25585) ("1" . -25586) 25587 nil (25572 . 25575) nil ("6" . -25572) ("." . -25573) ("1" . -25574) 25575 (t 24658 44694 820000 483000) nil ("
" . 44170) nil (44170 . 44171) nil (786 . 787) (t 24658 49297 289510 840000)) (emacs-undo-equiv-table))