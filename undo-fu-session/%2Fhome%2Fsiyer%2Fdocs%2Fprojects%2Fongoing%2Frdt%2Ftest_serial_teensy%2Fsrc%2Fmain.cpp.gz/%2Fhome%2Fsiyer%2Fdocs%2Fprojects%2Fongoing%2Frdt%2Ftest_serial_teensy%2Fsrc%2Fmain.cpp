((buffer-size . 318) (buffer-checksum . "ea7e4a7cadb2caeda8286370300567c58382ff0f"))
((emacs-buffer-undo-list nil ("    lastCmdTime = millis();
" . 204) ((marker . 208) . -18) ((marker . 237) . -28) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) ((marker . 204) . -18) 222 (t 24700 50795 639566 726000) nil (318 . 323) nil ("Q" . -318) ((marker . 208) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker . 290) . -1) ((marker) . -1) 319 nil (311 . 319) nil ("." . -311) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker* . 295) . 1) ((marker . 208) . -1) ((marker . 208) . -1) ("w" . -312) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("r" . -313) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("i" . -314) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("t" . -315) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("e" . -316) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) 317 nil ("S" . -311) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("e" . -312) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("r" . -313) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("i" . -314) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("a" . -315) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) ("l" . -316) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 283) . -1) ((marker . 208) . -1) 317 (t 24700 50735 922960 529000) nil (155 . 156) 154 nil ("/*
 * drive_teensy.ino
 *
 * Code for the controller in the locomotion subsystem, particularly the Teensyduino. Takes in
 * a robot speed and offset byte and writes the command to the motors. Also handles special
 * drive modes such as turning in place and changing the digging drum elevation.
 *
 * See README for descriptions on the format of the command messages.
 *
 * TODO:
 * - Implement handlers for drive modes
 */
" . 1) ((marker . 283) . -422) ((marker . 283) . -422) ((marker . 208) . -121) ((marker . 208) . -422) ((marker . 204) . -419) ((marker . 237) . -423) ((marker) . -422) 423 nil (757 . 761) ("   " . 757) 761 nil (727 . 733) ("     " . -727) (687 . 691) ("   " . 687) ((marker . 208) . -1) 688 nil ("  " . 764) ((marker . 208) . -2) ((marker . 208) . -2) (766 . 767) ("}" . -766) (766 . 767) nil (763 . 766) 762 nil ("   
" . 760) ((marker* . 295) . 4) ((marker . 208) . -3) ((marker . 237) . -4) 763 nil ("
" . 760) ((marker* . 295) . 1) ((marker . 237) . -1) nil ("   " . -760) ((marker . 208) . -3) 763 nil (759 . 763) 759 nil ("    " . -577) (575 . 576) nil (")" . -574) (574 . 575) (")" . -574) (574 . 575) nil ("_" . -574) ((marker . 208) . -1) ((marker . 208) . -1) 575 nil (574 . 575) nil (567 . 574) nil (566 . 567) nil (564 . 566) nil (563 . 565) nil ("9" . -563) ((marker . 208) . -1) ((marker . 208) . -1) 564 nil (557 . 564) (558 . 562) (556 . 557) nil ("    " . -557) ("j" . -556) ((marker . 208) . -1) ("j" . -557) ((marker . 208) . -1) 558 nil (557 . 558) (558 . 562) (556 . 557) nil ("    " . -557) ("P" . -556) ((marker . 208) . -1) ((marker . 208) . -1) ("i" . -557) ((marker . 208) . -1) ((marker . 208) . -1) ("n" . -558) ((marker . 208) . -1) ((marker . 208) . -1) ("M" . -559) ((marker . 208) . -1) ((marker . 208) . -1) ("o" . -560) ((marker . 208) . -1) ("d" . -561) ((marker . 208) . -1) ("e" . -562) ((marker . 208) . -1) (" " . -563) ((marker . 208) . -1) 564 nil (557 . 564) (558 . 562) (556 . 557) nil ("    " . -557) ("P" . -556) ((marker . 208) . -1) 557 nil (558 . 562) (556 . 557) nil (553 . 556) 511 nil ("
" . 555) ((marker . 208) . -1) ((marker . 204) . -1) nil ("o" . 556) ((marker . 208) . -1) nil (556 . 557) nil (555 . 556) 555 nil (732 . 735) ("       " . -732) (730 . 731) nil (")" . -729) (729 . 730) (")" . -729) (729 . 730) nil (724 . 729) nil (723 . 724) nil (721 . 723) nil (720 . 722) nil (716 . 720) nil ("i" . -716) ((marker . 208) . -1) 717 nil (709 . 717) (710 . 717) ("   " . -710) ((marker* . 296) . 3) (708 . 709) nil (702 . 708) 667 nil (708 . 711) nil (709 . 711) ("}
" . 708) ((marker . 237) . -2) ((marker*) . 2) ((marker) . -1) nil ("  }
" . 708) ((marker . 208) . -2) ((marker . 237) . -4) ((marker*) . 2) ((marker) . -3) 710 nil ("  " . -712) ("     forward(100, 100);
" . 708) ((marker . 208) . -5) ((marker . 237) . -24) 713 nil (732 . 734) ("   " . -732) ("   else if (millis() - lastCmdTime >= CMD_RECV_TIMEOUT) {
" . 708) ((marker . 237) . -58) nil (790 . 793) ("    " . 790) (766 . 771) ("      " . 766) (708 . 711) ("    " . -708) ("     while(!(Serial1.available())){}
     int inByte2 = Serial1.read();
     while(!(Serial1.available())){}
     int inByte3= Serial1.read();
      forward(inByte2, inByte3);

      // read from Serial1, write to Serial, might be wrong
      Serial.write(255); // ackowledgement byte
      // don't need loop because this is in loop()
 " . 703) ((marker . 208) . -336) ((marker . 204) . -336) ((marker . 283) . -336) ((marker . 283) . -336) ((marker) . -336) 1039 nil (812 . 817) ("      " . -812) (775 . 780) ("      " . 775) (740 . 745) ("      " . -740) (703 . 708) ("      " . -703) ("//    Serial.println(\"received\");
//    Serial.println(inByte);
 " . 664) ((marker . 208) . -64) ((marker . 204) . -64) ((marker . 283) . -64) ((marker . 283) . -64) ((marker) . -64) 728 nil ("
/*  reset()
 *   This function resets all motor speeds to neutral(not moving)
 */
void reset() {
  Brown.writeMicroseconds(1500);
  Pink.writeMicroseconds(1500);
  Blue.writeMicroseconds(1500);
  Orange.writeMicroseconds(1500);
  FrontArm.writeMicroseconds(1500);
  BackArm.writeMicroseconds(1500);
}

/*  forward()
 *   This function spins all motors so robot moves in the forward direction
 */
void forward(int val, int offset) {
  float valForward = map(val,0,200,1000,2000);
 // float offset = map(turn,0,200,1000,2000);
  float valBackward = map(val,0,200,2000,1000);
  int i;
  Serial.println(\"test\");
  Serial.println(valForward);
  Serial.println(valBackward);
  if(offset < 100) {
  float leftRatio = (offset/200);
  float rightRatio = (offset)/200;

  Brown.writeMicroseconds(valForward);
  Pink.writeMicroseconds(valForward);
  Blue.writeMicroseconds(valBackward*leftRatio);
  Orange.writeMicroseconds(valBackward*leftRatio);
  }

  if(offset > 100) {
  float leftRatio = (offset/200);
  float rightRatio = (offset)/200;

  Brown.writeMicroseconds(valForward*leftRatio);
  Pink.writeMicroseconds(valForward*leftRatio);
  Blue.writeMicroseconds(valBackward);
  Orange.writeMicroseconds(valBackward);
  }
  if (offset == 100){

  float leftRatio = (offset/200);
  float rightRatio = (offset)/200;

  Brown.writeMicroseconds(valForward);
  Pink.writeMicroseconds(valForward);
  Blue.writeMicroseconds(valBackward);
  Orange.writeMicroseconds(valBackward);
    }


}
/*  backward()
 *   This function spins all motors so robot moves in the backward direction
 */
void backward(int val) {
  float valForward = map(val,0,200,1000,2000);
  float valBackward = map(val,0,200,2000,1000);
  Serial.println(\"test\");
  Serial.println(valForward);
  Serial.println(valBackward);
  Brown.writeMicroseconds(valBackward);
  Pink.writeMicroseconds(valBackward);
  Blue.writeMicroseconds(valForward);
  Orange.writeMicroseconds(valForward);
}
/*  turnLeft()
 *   This function spins all motors so robot turns Left
 */
void turnLeft(int val) {
  int valForward = map(val,0,200,1000,2000);
  int valBackward = map(val,0,200,2000,1000);
  Brown.writeMicroseconds(valBackward);
  Pink.writeMicroseconds(valBackward);
  Blue.writeMicroseconds(valBackward);
  Orange.writeMicroseconds(valBackward);
}
/*  turnRight()
 *   This function spins all motors so robot turns Right
 */
void turnRight(int val) {
  int valForward = map(val,0,200,1000,2000);
  int valBackward = map(val,0,200,2000,1000);
  Brown.writeMicroseconds(valForward);
  Pink.writeMicroseconds(valForward);
  Blue.writeMicroseconds(valForward);
  Orange.writeMicroseconds(valForward);
}
/*  armsUp()
 *   This function spins falcon motors so robot's arm goes up
 *
 *   Update -
 *      Wheels should turn as the arms are going up
 *      - Tested(In progress)
 */
void armsUp() {
  int valForward = map(TEST_MOTOR_SPEED,-100,100,1000,2000);
  int valBackward = map(-TEST_MOTOR_SPEED,-100,100,1000,2000);
  Brown.writeMicroseconds(valForward);
  Pink.writeMicroseconds(valBackward);
  Blue.writeMicroseconds(valForward);
  Orange.writeMicroseconds(valBackward);
  FrontArm.writeMicroseconds(valBackward);
  BackArm.writeMicroseconds(valBackward);
}
/*  armsDown()
 *   This function spins all motors so robot turns Right
 *
 *   Update -
 *      Wheels should turn as the arms are going down
 *      - Tested(In progress)
 */
void armsDown() {
  int valForward = map(TEST_MOTOR_SPEED,-100,100,1000,2000);
  int valBackward = map(-TEST_MOTOR_SPEED,-100,100,1000,2000);
  Brown.writeMicroseconds(valBackward);
  Pink.writeMicroseconds(valForward);
  Blue.writeMicroseconds(valBackward);
  Orange.writeMicroseconds(valForward);
  FrontArm.writeMicroseconds(valForward);
  BackArm.writeMicroseconds(valForward);
}
void brown() {
  int valForward = map(TEST_MOTOR_SPEED, -100,100,1000,2000);
  Brown.writeMicroseconds(valForward);
  }
void pink(){
  int valForward = map(TEST_MOTOR_SPEED,-100,100,1000,2000);
  Pink.writeMicroseconds(valForward);
  }
void orange(){
  int valBackward = map(-TEST_MOTOR_SPEED,-100,100,1000,2000);
  Orange.writeMicroseconds(valBackward);
  }
void blue(){
  int valBackward = map(-TEST_MOTOR_SPEED,-100,100,1000,2000);
  Blue.writeMicroseconds(valBackward);
  }
/*  Incoming byte
 *   0 - Wheels(0) / Wheels(1)                      Toggle
 *   1 - Arms(0) / Arms(1)                          Toggle
 *   2 - Wheels Backward(0) / Wheels Forward(1)
 *   3 - Arms Down(0) / Arms Up(1)
 *   4 -
 *   5 -
 *   6 -
 *   7 -
 */
" . 556) ((marker . 208) . -4499) ((marker . 1) . -3995) ((marker . 204) . -4496) ((marker . 237) . -4500) ((marker . 283) . -4499) ((marker . 283) . -4499) ((marker) . -4499) 5055 nil ("
  // Attach motors and arms
  Brown.attach(3);
  Pink.attach(4);
  Blue.attach(6);
  Orange.attach(5);
  FrontArm.attach(9);
  BackArm.attach(10);
  // Hardcode function calling
  /*  forward();
   *  backward();
   *  turnLeft();
   *  turnRight();
   *  armsUp();
   *  armsDown();
   */
" . 554) ((marker . 208) . -290) ((marker . 204) . -285) ((marker . 237) . -291) ((marker . 283) . -290) ((marker . 283) . -290) ((marker) . -290) 844 nil ("
#define TEST_MOTOR_SPEED 70
#define CMD_RECV_TIMEOUT 100

// Wheels
Servo Brown;
Servo Pink;
Servo Blue;
Servo Orange;

// Arms
Servo FrontArm;
Servo BackArm;

// Time the last command was received
long lastCmdTime;

" . 445) ((marker . 208) . -217) ((marker . 204) . -217) ((marker . 237) . -218) ((marker . 1) . -1) ((marker . 21) . -28) ((marker . 283) . -217) ((marker . 283) . -217) ((marker) . -217) 662 nil ("#include <Servo.h>
" . 445) ((marker . 208) . -19) ((marker . 237) . -19) (t 24700 50550 356482 86000)) (emacs-pending-undo-list (732 . 735) ("       " . -732) (730 . 731) nil (")" . -729) (729 . 730) (")" . -729) (729 . 730) nil (724 . 729) nil (723 . 724) nil (721 . 723) nil (720 . 722) nil (716 . 720) nil ("i" . -716) ((marker . 208) . -1) 717 nil (709 . 717) (710 . 717) ("   " . -710) ((marker* . 296) . 3) (708 . 709) nil (702 . 708) 667 nil (708 . 711) nil (709 . 711) ("}
" . 708) ((marker . 237) . -2) ((marker*) . 2) ((marker) . -1) nil ("  }
" . 708) ((marker . 208) . -2) ((marker . 237) . -4) ((marker*) . 2) ((marker) . -3) 710 nil ("  " . -712) ("     forward(100, 100);
" . 708) ((marker . 208) . -5) ((marker . 237) . -24) 713 nil (732 . 734) ("   " . -732) ("   else if (millis() - lastCmdTime >= CMD_RECV_TIMEOUT) {
" . 708) ((marker . 237) . -58) nil (790 . 793) ("    " . 790) (766 . 771) ("      " . 766) (708 . 711) ("    " . -708) ("     while(!(Serial1.available())){}
     int inByte2 = Serial1.read();
     while(!(Serial1.available())){}
     int inByte3= Serial1.read();
      forward(inByte2, inByte3);

      // read from Serial1, write to Serial, might be wrong
      Serial.write(255); // ackowledgement byte
      // don't need loop because this is in loop()
 " . 703) ((marker . 208) . -336) ((marker . 204) . -336) ((marker . 283) . -336) ((marker . 283) . -336) ((marker) . -336) 1039 nil (812 . 817) ("      " . -812) (775 . 780) ("      " . 775) (740 . 745) ("      " . -740) (703 . 708) ("      " . -703) ("//    Serial.println(\"received\");
//    Serial.println(inByte);
 " . 664) ((marker . 208) . -64) ((marker . 204) . -64) ((marker . 283) . -64) ((marker . 283) . -64) ((marker) . -64) 728 nil ("
/*  reset()
 *   This function resets all motor speeds to neutral(not moving)
 */
void reset() {
  Brown.writeMicroseconds(1500);
  Pink.writeMicroseconds(1500);
  Blue.writeMicroseconds(1500);
  Orange.writeMicroseconds(1500);
  FrontArm.writeMicroseconds(1500);
  BackArm.writeMicroseconds(1500);
}

/*  forward()
 *   This function spins all motors so robot moves in the forward direction
 */
void forward(int val, int offset) {
  float valForward = map(val,0,200,1000,2000);
 // float offset = map(turn,0,200,1000,2000);
  float valBackward = map(val,0,200,2000,1000);
  int i;
  Serial.println(\"test\");
  Serial.println(valForward);
  Serial.println(valBackward);
  if(offset < 100) {
  float leftRatio = (offset/200);
  float rightRatio = (offset)/200;

  Brown.writeMicroseconds(valForward);
  Pink.writeMicroseconds(valForward);
  Blue.writeMicroseconds(valBackward*leftRatio);
  Orange.writeMicroseconds(valBackward*leftRatio);
  }

  if(offset > 100) {
  float leftRatio = (offset/200);
  float rightRatio = (offset)/200;

  Brown.writeMicroseconds(valForward*leftRatio);
  Pink.writeMicroseconds(valForward*leftRatio);
  Blue.writeMicroseconds(valBackward);
  Orange.writeMicroseconds(valBackward);
  }
  if (offset == 100){

  float leftRatio = (offset/200);
  float rightRatio = (offset)/200;

  Brown.writeMicroseconds(valForward);
  Pink.writeMicroseconds(valForward);
  Blue.writeMicroseconds(valBackward);
  Orange.writeMicroseconds(valBackward);
    }


}
/*  backward()
 *   This function spins all motors so robot moves in the backward direction
 */
void backward(int val) {
  float valForward = map(val,0,200,1000,2000);
  float valBackward = map(val,0,200,2000,1000);
  Serial.println(\"test\");
  Serial.println(valForward);
  Serial.println(valBackward);
  Brown.writeMicroseconds(valBackward);
  Pink.writeMicroseconds(valBackward);
  Blue.writeMicroseconds(valForward);
  Orange.writeMicroseconds(valForward);
}
/*  turnLeft()
 *   This function spins all motors so robot turns Left
 */
void turnLeft(int val) {
  int valForward = map(val,0,200,1000,2000);
  int valBackward = map(val,0,200,2000,1000);
  Brown.writeMicroseconds(valBackward);
  Pink.writeMicroseconds(valBackward);
  Blue.writeMicroseconds(valBackward);
  Orange.writeMicroseconds(valBackward);
}
/*  turnRight()
 *   This function spins all motors so robot turns Right
 */
void turnRight(int val) {
  int valForward = map(val,0,200,1000,2000);
  int valBackward = map(val,0,200,2000,1000);
  Brown.writeMicroseconds(valForward);
  Pink.writeMicroseconds(valForward);
  Blue.writeMicroseconds(valForward);
  Orange.writeMicroseconds(valForward);
}
/*  armsUp()
 *   This function spins falcon motors so robot's arm goes up
 *
 *   Update -
 *      Wheels should turn as the arms are going up
 *      - Tested(In progress)
 */
void armsUp() {
  int valForward = map(TEST_MOTOR_SPEED,-100,100,1000,2000);
  int valBackward = map(-TEST_MOTOR_SPEED,-100,100,1000,2000);
  Brown.writeMicroseconds(valForward);
  Pink.writeMicroseconds(valBackward);
  Blue.writeMicroseconds(valForward);
  Orange.writeMicroseconds(valBackward);
  FrontArm.writeMicroseconds(valBackward);
  BackArm.writeMicroseconds(valBackward);
}
/*  armsDown()
 *   This function spins all motors so robot turns Right
 *
 *   Update -
 *      Wheels should turn as the arms are going down
 *      - Tested(In progress)
 */
void armsDown() {
  int valForward = map(TEST_MOTOR_SPEED,-100,100,1000,2000);
  int valBackward = map(-TEST_MOTOR_SPEED,-100,100,1000,2000);
  Brown.writeMicroseconds(valBackward);
  Pink.writeMicroseconds(valForward);
  Blue.writeMicroseconds(valBackward);
  Orange.writeMicroseconds(valForward);
  FrontArm.writeMicroseconds(valForward);
  BackArm.writeMicroseconds(valForward);
}
void brown() {
  int valForward = map(TEST_MOTOR_SPEED, -100,100,1000,2000);
  Brown.writeMicroseconds(valForward);
  }
void pink(){
  int valForward = map(TEST_MOTOR_SPEED,-100,100,1000,2000);
  Pink.writeMicroseconds(valForward);
  }
void orange(){
  int valBackward = map(-TEST_MOTOR_SPEED,-100,100,1000,2000);
  Orange.writeMicroseconds(valBackward);
  }
void blue(){
  int valBackward = map(-TEST_MOTOR_SPEED,-100,100,1000,2000);
  Blue.writeMicroseconds(valBackward);
  }
/*  Incoming byte
 *   0 - Wheels(0) / Wheels(1)                      Toggle
 *   1 - Arms(0) / Arms(1)                          Toggle
 *   2 - Wheels Backward(0) / Wheels Forward(1)
 *   3 - Arms Down(0) / Arms Up(1)
 *   4 -
 *   5 -
 *   6 -
 *   7 -
 */
" . 556) ((marker . 208) . -4499) ((marker . 1) . -3995) ((marker . 204) . -4496) ((marker . 237) . -4500) ((marker . 283) . -4499) ((marker . 283) . -4499) ((marker) . -4499) 5055 nil ("
  // Attach motors and arms
  Brown.attach(3);
  Pink.attach(4);
  Blue.attach(6);
  Orange.attach(5);
  FrontArm.attach(9);
  BackArm.attach(10);
  // Hardcode function calling
  /*  forward();
   *  backward();
   *  turnLeft();
   *  turnRight();
   *  armsUp();
   *  armsDown();
   */
" . 554) ((marker . 208) . -290) ((marker . 204) . -285) ((marker . 237) . -291) ((marker . 283) . -290) ((marker . 283) . -290) ((marker) . -290) 844 nil ("
#define TEST_MOTOR_SPEED 70
#define CMD_RECV_TIMEOUT 100

// Wheels
Servo Brown;
Servo Pink;
Servo Blue;
Servo Orange;

// Arms
Servo FrontArm;
Servo BackArm;

// Time the last command was received
long lastCmdTime;

" . 445) ((marker . 208) . -217) ((marker . 204) . -217) ((marker . 237) . -218) ((marker . 1) . -1) ((marker . 21) . -28) ((marker . 283) . -217) ((marker . 283) . -217) ((marker) . -217) 662 nil ("#include <Servo.h>
" . 445) ((marker . 208) . -19) ((marker . 237) . -19) (t 24700 50550 356482 86000)) (emacs-undo-equiv-table (34 . -1) (35 . 37)))