((buffer-size . 742) (buffer-checksum . "c0e5a706cb67e32cceb202eecd82204d624e9daa"))
((emacs-buffer-undo-list nil (nil rear-nonsticky nil 734 . 735) (nil fontified nil 734 . 735) (734 . 735) nil ("  " . -734) ((marker . 735) . -2) ((marker . 735) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker . 734) . -2) ((marker) . -2) 736 nil (733 . 736) 733 nil (729 . 731) (185 . 189) ("  " . 185) (165 . 167) ("}" . 164) ((marker* . 735) . 1) ((marker* . 164) . 1) ((marker* . 164) . 1) ((marker* . 164) . 1) ((marker* . 164) . 1) ((marker*) . 1) ((marker) . -1) nil (163 . 165) nil (161 . 163) nil (158 . 161) nil (" " . -158) ((marker . 735) . -1) ((marker . 735) . -1) 159 nil (140 . 159) nil (139 . 140) (t 24673 9912 850749 554000) 139 nil (704 . 709) nil (703 . 704) nil ("  " . 700) nil (705 . 706) 705 nil (126 . 139) nil (121 . 126) nil (120 . 121) nil (119 . 120) 119 nil (110 . 119) nil ("F" . -110) ((marker . 742) . -1) ((marker . 735) . -1) ((marker . 735) . -1) ("I" . -111) ((marker . 742) . -1) ((marker . 735) . -1) ((marker . 735) . -1) 112 nil (109 . 112) nil (101 . 109) nil (100 . 101) nil (99 . 100) (t 24672 54416 141408 784000) 99 nil (31 . 40) (31 . 32) (nil syntax-table nil 31 . 32) (nil syntax-table (1) 30 . 31) (30 . 31) ("\"" . -30) (nil syntax-table nil 31 . 32) (nil syntax-table (1) 30 . 31) (30 . 31) nil ("s" . -30) ("t" . -31) ("u" . -32) 33 nil (28 . 33) nil (" " . -28) ("s" . -29) 30 nil (22 . 30) nil (21 . 22) nil (20 . 21) nil ("\"" . -19) (nil syntax-table nil 21 . 22) (nil syntax-table (1) 20 . 21) (19 . 20) ("\"" . -19) (nil syntax-table nil 21 . 22) (nil syntax-table (1) 20 . 21) (11 . 20) (11 . 12) (nil syntax-table nil 11 . 12) (nil syntax-table (1) 10 . 11) (10 . 11) ("\"" . -10) (nil syntax-table nil 11 . 12) (nil syntax-table (1) 10 . 11) (10 . 11) nil (2 . 10) nil (1 . 2) nil (1 . 2) nil (1 . 2) nil ("class Student;
" . 58) (t 24672 54356 219333 838000) nil ("
" . 58) nil ("
" . 58) nil (nil rear-nonsticky nil 57 . 58) (nil fontified nil 57 . 58) (nil fontified nil 40 . 57) (nil fontified nil 39 . 40) (nil fontified nil 22 . 39) (nil fontified nil 21 . 22) (nil fontified nil 2 . 21) (nil fontified nil 1 . 2) (1 . 58) 2 nil (1 . 3) (t 24672 54339 818770 858000) nil ("

" . 15) (16 . 17) (nil rear-nonsticky t 15 . 16) nil (nil rear-nonsticky nil 15 . 16) ("
" . -16) (15 . 17) 1 (t 24672 54339 818770 858000) nil ("#include <iostream>
#include <string>
#include <vector>

" . 1) 57 nil ("
class Course {
    friend std::ostream& operator<<(std::ostream& os, const Course& rhs);
  public:
    // Course methods needed by Registrar
    Course(const std::string& courseName);
    const std::string& getName() const;
    bool addStudent(Student*);
    void removeStudentsFromCourse();

  private:
  std::string name;
  std::vector<Student*> students;
  };

  class Student {
    friend std::ostream& operator<<(std::ostream& os, const Student& rhs);
  public:
    // Student methods needed by Registrar
    Student(const std::string& thename);
    const std::string& getName() const;
    bool addCourse(Course*);

    // Student method needed by Course
    void removedFromCourse(Course*);

  private:
    std::string name;
    std::vector<Course*> courses;
  };

" . 73) 844 nil (863 . 865) ("    " . -863) ("  " . 845) nil ("  " . 58) (t 24672 52922 241133 670000) nil ("
" . 1416) nil ("}" . 1416) nil (380 . 382) ("    " . 380) (402 . 404) ("    " . -402) ("  " . -76) ("namespace BrooklynPoly {
" . 58) (t 24672 52414 959762 481000) nil ("    " . 1371) ("    " . 1260) ("  " . 877) ("    " . 804) ("    " . 727) ("  " . 470) ("    " . 395) (1472 . 1473) nil (1466 . 1468) ("	" . -1466) (1430 . 1434) ("	  " . 1430) nil (1391 . 1395) nil (1392 . 1396) ("	  " . -1392) (1342 . 1346) ("	  " . 1342) nil (1292 . 1296) ("	  " . 1292) nil (1276 . 1280) nil (1277 . 1279) ("	" . -1277) (1258 . 1262) ("	  " . 1258) 1274 nil (1204 . 1208) ("	  " . -1204) (1162 . 1172) ("				     " . 1162) nil (1099 . 1103) ("	  " . -1099) (1058 . 1062) ("	  " . 1058) nil (1018 . 1022) ("	  " . -1018) (1001 . 1005) ("	  " . 1001) nil (991 . 993) ("	" . -991) (914 . 918) ("	  " . 914) nil (891 . 893) nil (892 . 894) ("	" . -892) (886 . 888) ("	" . 886) nil (852 . 856) ("	  " . -852) (830 . 834) ("	  " . 830) nil (814 . 818) nil (815 . 817) ("	" . -815) (777 . 781) ("	  " . 777) nil (738 . 742) ("	  " . -738) (733 . 737) nil (704 . 708) ("	  " . -704) (664 . 668) ("	  " . 664) nil (623 . 627) ("	  " . -623) (580 . 584) ("	  " . 580) nil (570 . 572) ("	" . -570) 499 nil (495 . 499) ("	  " . 495) nil (411 . 415) ("	  " . 411) nil (476 . 478) ("	" . -476) 475 nil (473 . 475) nil (468 . 470) ("	" . -468) (432 . 436) ("	  " . 432) nil (395 . 399) nil (396 . 398) ("	" . -396) 362 nil (358 . 362) ("	  " . 358) nil (327 . 331) ("	  " . -327) (287 . 291) ("	  " . 287) nil (244 . 248) ("	  " . 244) 245 nil (202 . 206) ("	  " . -202) (192 . 194) ("	" . -192) 193 nil (118 . 122) ("	  " . -118) (101 . 103) ("	" . 101) nil ("u" . -58) ("s" . -59) ("i" . -60) ("n" . -61) ("g" . -62) (88 . 90) ("	" . -88) (" " . -63) 64 nil (1411 . 1412) ("}" . -1411) (1411 . 1412) nil (1407 . 1408) ("  " . 1407) (1372 . 1375) ("    " . 1372) (1339 . 1342) ("    " . 1339) (1290 . 1293) ("    " . 1290) (1241 . 1244) ("    " . 1241) (1231 . 1232) ("  " . 1231) (1213 . 1216) ("    " . 1213) (1160 . 1163) ("    " . 1160) (1119 . 1128) ("			       " . 1119) (1057 . 1060) ("    " . 1057) (1017 . 1020) ("    " . 1017) (978 . 981) ("    " . 978) (962 . 965) ("    " . 962) (953 . 954) ("  " . 953) (877 . 880) ("    " . 877) (858 . 859) ("  " . 858) (853 . 854) ("  " . 853) (820 . 823) ("    " . 820) (799 . 802) ("    " . 799) (789 . 790) ("  " . 789) (752 . 755) ("    " . 752) (714 . 717) ("    " . 714) (685 . 688) ("    " . 685) (646 . 649) ("    " . 646) (606 . 609) ("    " . 606) (564 . 567) ("    " . 564) (555 . 556) ("  " . 555) (481 . 484) ("    " . 481) (464 . 465) ("  " . 464) (459 . 460) ("  " . 459) (424 . 427) ("    " . 424) (403 . 406) ("    " . 403) (393 . 394) ("  " . 393) (356 . 359) ("    " . 356) (326 . 329) ("    " . 326) (287 . 290) ("    " . 287) (245 . 248) ("    " . 245) (204 . 207) ("  " . 204) (195 . 196) (122 . 125) ("    " . 122) (106 . 107) (89 . 90) ("}" . 88) nil (87 . 89) nil (83 . 87) nil (62 . 83) nil ("t" . -62) (" " . -63) 64 nil (58 . 64) nil (57 . 58) 57 nil (nil face font-lock-string-face 56 . 57) (nil fontified t 56 . 57) (nil c-in-sws t 56 . 57) (56 . 57) (t 24672 52159 390125 757000) 39 nil ("

" . 39) nil (39 . 41) (t 24672 52159 390125 757000)) (emacs-pending-undo-list ("
" . 58) ((marker) . -1) nil (nil rear-nonsticky nil 57 . 58) (nil fontified nil 57 . 58) (nil fontified nil 40 . 57) (nil fontified nil 39 . 40) (nil fontified nil 22 . 39) (nil fontified nil 21 . 22) (nil fontified nil 2 . 21) (nil fontified nil 1 . 2) (1 . 58) 2 nil (319 . 320) (" " . 319) (91 . 92) (" " . 91) (319 . 320) (" " . 319) (91 . 92) (" " . 91) 1 nil (nil rear-nonsticky nil 383 . 384) (nil fontified nil 1 . 384) (1 . 384) (t . -1)) (emacs-undo-equiv-table (42 . 44) (93 . t)))