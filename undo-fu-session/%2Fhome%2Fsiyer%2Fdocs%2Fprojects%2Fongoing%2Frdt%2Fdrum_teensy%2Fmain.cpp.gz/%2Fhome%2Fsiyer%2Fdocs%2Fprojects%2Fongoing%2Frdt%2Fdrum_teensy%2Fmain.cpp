((buffer-size . 4074) (buffer-checksum . "3bc944f0510d38823796adc419c7e09468b2b6bd"))
((emacs-buffer-undo-list nil ("  /
" . 4061) ((marker . 1) . -3) ((marker . 50178) . -2) ((marker . 4075) . -4) ((marker . 4061) . -3) 4063 nil ("
" . -4064) (4060 . 4065) 4017 (t 24710 1304 25636 956000)) (emacs-pending-undo-list) (emacs-undo-equiv-table))